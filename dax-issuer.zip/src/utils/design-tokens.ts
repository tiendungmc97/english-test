export const designTokens = {
  colors: {
    // Core
    primary: "#8249DD",
    primaryHover: "#915EE8",
    primaryActive: "#6B31CE",
    primaryBg: "#F4EDFF",
    primaryBgHover: "#EBE0FF",
    primaryBorder: "#C8A9F5",
    primaryBorderHover: "#B991F0",
    primaryText: "#8249DD",
    primaryTextHover: "#6B31CE",
    primaryTextActive: "#5A27B5",

    // Semantic
    success: "#10B981",
    successHover: "#34D399",
    successActive: "#059669",
    successBg: "#ECFDF5",
    successBorder: "#A7F3D0",

    warning: "#F59E0B",
    warningHover: "#FDBA74",
    warningActive: "#D97706",
    warningBg: "#FFFBEB",
    warningBorder: "#FDE68A",

    error: "#EF4444",
    errorHover: "#F87171",
    errorActive: "#DC2626",
    errorBg: "#FEF2F2",
    errorBorder: "#FCA5A5",

    info: "#6366F1",
    infoHover: "#818CF8",
    infoActive: "#4F46E5",
    infoBg: "#EEF2FF",
    infoBorder: "#C7D2FE",

    // Neutral & grayscale
    textBase: "#0F172A",
    textSecondary: "#475569",
    textTertiary: "#94A3B8",
    textQuaternary: "#CBD5E1",

    gray50: "#F9FAFB",
    gray100: "#F3F4F6",
    gray200: "#E5E7EB",
    gray300: "#D1D5DB",
    gray400: "#9CA3AF",
    gray500: "#6B7280",
    gray600: "#4B5563",
    gray700: "#374151",
    gray800: "#1F2937",

    // Borders & backgrounds
    border: "#E5E7EB",
    borderSecondary: "#F1F5F9",
    borderLight: "#EDEDED",

    bgBase: "#FFFFFF",
    bgLayout: "#F8FAFC",
    bgHover: "#F9FAFB",

    // Special
    pairSelectorText: "#555555",
    controlOutline: "rgba(130, 73, 221, 0.35)",
  },

  // giữ nguyên ở đây để dùng trong code (không map trực tiếp thành utility Tailwind)
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
  },
  borderRadius: {
    sm: 6,
    md: 8,
    lg: 12,
    xl: 16,
  },
  shadows: {
    sm: "0 1px 2px rgba(0, 0, 0, 0.05)",
    md: "0 1px 3px rgba(0, 0, 0, 0.1), 0 1px 2px rgba(0, 0, 0, 0.06)",
    lg: "0 4px 6px rgba(0, 0, 0, 0.07), 0 2px 4px rgba(0, 0, 0, 0.06)",
    xl: "0 10px 15px rgba(0, 0, 0, 0.1), 0 4px 6px rgba(0, 0, 0, 0.05)",
  },
} as const;
