export function formatCurrency(
  value: number | bigint | null | undefined,
  {
    locale = "vi-VN",
    currency = "VND",
    minimumFractionDigits,
    maximumFractionDigits,
    showSymbol = true,
  }: {
    locale?: string;
    currency?: string;
    minimumFractionDigits?: number;
    maximumFractionDigits?: number;
    showSymbol?: boolean;
  } = {},
) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "";

  // For VND, always show đ symbol when showSymbol is true
  if (currency === "VND" && showSymbol) {
    const fmt = new Intl.NumberFormat(locale, {
      style: "decimal",
      minimumFractionDigits: minimumFractionDigits ?? 0,
      maximumFractionDigits: maximumFractionDigits ?? 0,
    });
    return fmt.format(value as number) + " đ";
  }

  // For other currencies, use standard formatting or number only
  const fmt = new Intl.NumberFormat(locale, {
    style: showSymbol ? "currency" : "decimal",
    currency: showSymbol ? currency : undefined,
    minimumFractionDigits: minimumFractionDigits ?? (currency === "VND" ? 0 : 2),
    maximumFractionDigits: maximumFractionDigits ?? (currency === "VND" ? 0 : 2),
  });
  return fmt.format(value as number);
}
