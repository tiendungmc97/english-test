"use client";
import { Link } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { CookiesStorageKeys } from "@/libs/constants/keys";
import { updateUserInfo } from "@/redux/slice/user.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { ApiStatusCode } from "@/services/api/types";
import { useMutateVerify2FA } from "@/services/hooks/use-auth";
import { setCookie } from "@/utils/cookies";
import { Button, Form, Input } from "antd";
import { useTranslations } from "next-intl";
import { useRef, useState } from "react";

interface VerifyStepProps {
  onSuccess?: () => void;
  type?: "setup" | "verify";
}
export function VerifyStep({ onSuccess, type }: VerifyStepProps) {
  const dispatch = useAppDispatch();
  const [form] = Form.useForm();
  const { mutate: verify2FA, isPending } = useMutateVerify2FA();
  const [errorMessage, setErrorMessage] = useState("");
  const otpRef = useRef<any>(null);
  const t = useTranslations("Setup2FA");
  const user = useAppSelector((state) => state.user.user);

  const onVerify2FA = async (values: { code: string }) => {
    if (!user.validate2FaKey) return;
    setErrorMessage("");
    const verifyData = {
      code: values.code,
      validate2FaKey: user.validate2FaKey,
    };
    verify2FA(verifyData, {
      onSuccess: async (res) => {
        if (res.meta.code === ApiStatusCode.SUCCESS) {
          const accessToken = res.data.access_token;
          setCookie(CookiesStorageKeys.ACCESS_TOKEN, accessToken);
          dispatch(updateUserInfo({ accessToken: accessToken }));
          onSuccess?.();
        } else {
          setErrorMessage(t("otpInvalid"));
          form.setFieldsValue({ code: "" });
          setTimeout(() => {
            otpRef.current?.focus();
          }, 100);
        }
      },
      onError: () => {
        setErrorMessage(t("verificationFailed"));
        form.setFieldsValue({ code: "" });
        setTimeout(() => {
          otpRef.current?.focus();
        }, 100);
      },
    });
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      {type === "verify" && (
        <>
          <p className="relative pt-10 pb-6 text-2xl font-bold uppercase">{t("title")}</p>
          <p className="pb-4 text-sm text-gray-600">{t("description")}</p>
        </>
      )}

      {errorMessage && (
        <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-600">{errorMessage}</div>
      )}
      <Form
        form={form}
        onFinish={onVerify2FA}
        disabled={isPending}
        className="space-y-4"
        layout="vertical"
      >
        <div className="flex w-full justify-center">
          <Form.Item
            name="code"
            label=""
            rules={[
              { required: true, message: t("codeRequired") },
              { len: 6, message: t("codeLength") },
              { pattern: /^\d{6}$/, message: t("codeNumeric") },
            ]}
          >
            <Input.OTP
              ref={otpRef}
              length={6}
              formatter={(str) => str.replace(/\D/g, "")}
              size="large"
              className="!text-center"
              autoFocus
            />
          </Form.Item>
        </div>
        <div
          className={`h-full w-full rounded-sm bg-[url('/images/login/bg-button.svg')] bg-cover bg-center bg-no-repeat p-1 shadow ${
            type === "verify" ? "md:mt-16" : ""
          }`}
        >
          <Button
            type="text"
            htmlType="submit"
            className="w-full rounded-sm !border-[1px] !border-white !px-2 !py-6 !shadow-md"
            loading={isPending}
          >
            {type === "setup" && (
              <span className="text-lg font-bold text-black uppercase">{isPending ? t("settingUp") : t("enable")}</span>
            )}
            {type === "verify" && (
              <span className="text-lg font-bold text-black uppercase">{isPending ? t("verifying") : t("verify")}</span>
            )}
          </Button>
        </div>
      </Form>
      <Link
        href={ROUTERS.AUTH.LOGIN}
        className="text-primary text-purple z-50 pt-2 font-bold hover:underline"
      >
        {t("loginWithAnotherAccount")}
      </Link>
    </div>
  );
}
