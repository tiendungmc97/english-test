"use client";

import { useState } from "react";
import { usePathname, useRouter } from "@/i18n/navigation";

interface NavItem {
  key: string;
  label: string;
  href: string;
  icon?: React.ReactNode;
}

const navigationItems: NavItem[] = [
  {
    key: "profile",
    label: "Thông Tin Tổ Chức",
    href: "/dashboard/profile",
  },
  {
    key: "manager-asset",
    label: "Quản Lý Tài Sản",
    href: "/dashboard/manager-asset",
  },
  {
    key: "report",
    label: "Báo Cáo Tài Sản",
    href: "/dashboard/report",
  },
];

export default function DashboardNavbar() {
  const pathname = usePathname();
  const router = useRouter();

  const handleNavigation = (href: string) => {
    router.push(href);
  };

  const isActive = (href: string) => {
    return pathname === href || pathname.startsWith(href + "/");
  };

  return (
    <div className="h-full w-64 border-r border-gray-200 bg-white shadow-sm">
      {/* Header/Logo Section */}
      <div className="border-b border-gray-100 p-6">
        <div className="flex items-center space-x-3">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{ backgroundColor: "#8249DD" }}
          >
            <span className="text-sm font-bold text-white">D</span>
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">Dashboard</h2>
            <p className="text-xs text-gray-500">DAX Issuer</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        <nav className="space-y-2">
          {navigationItems.map((item) => (
            <button
              key={item.key}
              onClick={() => handleNavigation(item.href)}
              className={`w-full rounded-xl px-4 py-3 text-left font-medium shadow-sm transition-all duration-200 ${
                isActive(item.href)
                  ? "scale-[1.02] transform text-white shadow-lg"
                  : "text-gray-700 hover:scale-[1.01] hover:transform hover:bg-purple-50 hover:text-purple-700 hover:shadow-md"
              }`}
              style={
                isActive(item.href)
                  ? {
                      backgroundColor: "#8249DD",
                      boxShadow: "0 4px 20px rgba(130, 73, 221, 0.3)",
                    }
                  : {}
              }
            >
              <div className="flex items-center space-x-3">
                {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                <span>{item.label}</span>
              </div>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
