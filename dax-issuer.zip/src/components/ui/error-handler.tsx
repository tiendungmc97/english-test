"use client";

interface ErrorHandlerProps {
  error: unknown;
  title?: string;
  size?: "sm" | "md" | "lg";
  showRetryButton?: boolean;
  showLoginButton?: boolean;
  onRetry?: () => void;
  onLogin?: () => void;
}

export function ErrorHandler({
  error,
  title = "Đã xảy ra lỗi",
  size = "md",
  showRetryButton = true,
  showLoginButton = true,
  onRetry,
  onLogin,
}: ErrorHandlerProps) {
  // Xử lý error message để tránh [object Object]
  const getErrorMessage = (error: unknown): string => {
    if (error instanceof Error) {
      return error.message;
    }

    if (typeof error === "object" && error !== null) {
      // Kiểm tra nếu là API error với status 401
      if ("status" in error && error.status === 401) {
        return "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.";
      }

      // Kiểm tra nếu có message property
      if ("message" in error && typeof error.message === "string") {
        return error.message;
      }

      // Kiểm tra nếu có data.message
      if ("data" in error && error.data && typeof error.data === "object" && "message" in error.data) {
        return String(error.data.message);
      }

      // Fallback: chuyển object thành string có ý nghĩa
      return "Đã xảy ra lỗi khi tải thông tin. Vui lòng thử lại sau.";
    }

    return String(error);
  };

  const errorMessage = getErrorMessage(error);
  const isUnauthorized = typeof error === "object" && error !== null && "status" in error && error.status === 401;

  // Size variants
  const sizeClasses = {
    sm: "min-h-[120px] gap-3 p-4",
    md: "min-h-[200px] gap-4 p-6",
    lg: "min-h-[calc(100vh-200px)] gap-4 p-6",
  };

  const textClasses = {
    sm: "text-base",
    md: "text-lg",
    lg: "text-lg",
  };

  const buttonClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-2 text-base",
    lg: "px-6 py-2 text-lg",
  };

  return (
    <div className={`flex flex-col items-center justify-center text-center ${sizeClasses[size]}`}>
      {title && <div className={`text-textBase font-medium ${textClasses[size]}`}>{title}</div>}

      <div className={`text-error font-medium ${textClasses[size]}`}>{errorMessage}</div>
    </div>
  );
}

// Convenience components for common use cases
export function ProfileErrorHandler({ error }: { error: unknown }) {
  return (
    <ErrorHandler
      error={error}
      size="sm"
    />
  );
}

export function MessageErrorHandler({ error }: { error: unknown }) {
  return (
    <ErrorHandler
      error={error}
      size="sm"
    />
  );
}

export function NoDataHandler({ message = "Không có dữ liệu", onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div className="flex min-h-[calc(100vh-200px)] flex-col items-center justify-center gap-4 p-6 text-center">
      <div className="text-textSecondary text-lg font-medium">{message}</div>
      <button
        onClick={onRetry || (() => window.location.reload())}
        className="border-border text-textBase hover:bg-bgLayout rounded-lg border px-6 py-2 transition-colors"
      >
        Thử lại
      </button>
    </div>
  );
}
