"use client";

import { useUserInfo } from "@/services/hooks/use-auth";
import { CopyOutlined } from "@ant-design/icons";
import { Input, message, Modal, QRCode, Typography } from "antd";
import { useState } from "react";

const { Title, Text } = Typography;

interface InviteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function InviteModal({ isOpen, onClose }: InviteModalProps) {
  const [copied, setCopied] = useState(false);
  const { data: userData } = useUserInfo();

  // Get referral data from user info
  const referralCode = userData?.data?.referralCode || "";
  const referralLink =
    typeof window !== "undefined" ? `${window.location.origin}/register?referralCode=${referralCode}` : "";

  // Function to truncate referral link with ellipsis in the middle
  const truncateReferralLink = (link: string, maxLength: number = 30) => {
    if (link.length <= maxLength) return link;

    const start = link.substring(0, 12);
    const end = link.substring(link.length - 8);
    return `${start}...${end}`;
  };

  // Get truncated referral link for display
  const displayReferralLink = truncateReferralLink(referralLink);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      setCopied(true);
      message.success("Đã sao chép mã giới thiệu!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      message.error("Không thể sao chép mã giới thiệu");
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      message.success("Đã sao chép liên kết giới thiệu!");
    } catch (err) {
      message.error("Không thể sao chép liên kết giới thiệu");
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Mời bạn tham gia VINDAS",
          text: `Tham gia VINDAS với mã giới thiệu: ${referralCode}`,
          url: referralLink,
        });
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      // Fallback to copying link
      handleCopyLink();
    }
  };

  return (
    <Modal
      open={isOpen}
      onCancel={onClose}
      footer={null}
      centered
      width={480}
      className="invite-modal"
      styles={{
        body: { padding: 0 },
        content: { borderRadius: "12px" },
      }}
    >
      <div className="rounded-xl bg-white p-8 text-center">
        <div className="mb-6">
          <Title
            level={3}
            className="!mb-2 !text-gray-900"
          >
            Mời bạn bè tham gia
          </Title>
          <Text className="text-gray-600">Chia sẻ mã giới thiệu của bạn và nhận thưởng khi bạn bè đăng ký</Text>
        </div>

        <div className="mb-6 flex justify-center">
          <div className="rounded-lg border-2 border-gray-200 p-4">
            <QRCode
              value={referralLink}
              size={120}
              color="#000000"
              bgColor="#ffffff"
              bordered={false}
            />
          </div>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Input
              value={referralCode}
              readOnly
              className="!bg-bgLayout !pl-24 !font-mono !text-sm"
              styles={{
                input: {
                  textAlign: "right",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                },
              }}
              suffix={
                <CopyOutlined
                  className={`cursor-pointer text-gray-500 transition-colors hover:text-blue-500 ${
                    copied ? "text-green-500" : ""
                  }`}
                  onClick={handleCopyCode}
                />
              }
            />
            <div className="bg-bgLayout pointer-events-none absolute top-1/2 left-3 z-10 -translate-y-1/2 px-1 text-sm text-gray-400">
              Mã giới thiệu
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Input
              value={displayReferralLink}
              readOnly
              className="!pl-24 !text-sm"
              style={{
                backgroundColor: "#f8f9fa",
                borderColor: "#e9ecef",
              }}
              styles={{
                input: {
                  textAlign: "right",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                },
              }}
              suffix={
                <CopyOutlined
                  className="cursor-pointer text-gray-500 transition-colors hover:text-blue-500"
                  onClick={handleCopyLink}
                />
              }
              title={referralLink}
            />
            <div className="bg-bgLayout pointer-events-none absolute top-1/2 left-3 z-10 -translate-y-1/2 px-1 text-sm text-gray-400">
              Link giới thiệu
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}
