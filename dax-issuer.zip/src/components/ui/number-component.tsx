"use client";

import { Language } from "@/libs/types/language";
import { Currency } from "@/libs/types/settings";
import React from "react";
import { NumericFormat } from "react-number-format";

export interface PriceDisplayProps {
  value: number | string;
  currency?: Currency;
  className?: string;
  prefix?: string;
  suffix?: string;
  decimalScale?: number;
  disabled?: boolean;
  invalidText?: string;
}

export interface AmountDisplayProps {
  value: number | string | null | undefined;
  className?: string;
  decimalScale?: number;
  token?: string;
  invalidText?: string;
}

export const PriceDisplay: React.FC<PriceDisplayProps> = ({
  value,
  currency = Currency.VND,
  className = "",
  invalidText = "-",
  prefix,
  suffix,
  decimalScale,
}) => {
  const locale = Language.VI;
  const currencySymbols: Record<Currency, string> = {
    [Currency.USD]: "$",
    [Currency.VND]: "₫",
  };
  const finalPrefix = prefix || currencySymbols[currency] || "$";
  const finalDecimalScale = decimalScale !== undefined ? decimalScale : currency === Currency.VND ? 0 : 2;

  if (value === null || value === undefined || isNaN(Number(value))) {
    return <span className={className}> {invalidText} </span>;
  }

  return (
    <NumericFormat
      displayType="text"
      value={value}
      thousandSeparator={locale === Language.VI ? "." : ","}
      decimalSeparator={locale === Language.VI ? "," : "."}
      prefix={prefix}
      suffix={suffix}
      decimalScale={finalDecimalScale}
      className={className}
    />
  );
};

export const AmountDisplay: React.FC<AmountDisplayProps> = ({
  value,
  className = "",
  decimalScale,
  token,
  invalidText,
}) => {
  const locale = Language.VI;
  const finalDecimalScale = decimalScale !== undefined ? decimalScale : 2;
  if (value === null || value === undefined || isNaN(Number(value))) {
    return <span className={className}> {invalidText} </span>;
  }
  return (
    <NumericFormat
      displayType="text"
      value={value}
      thousandSeparator={locale === Language.VI ? "." : ","}
      decimalSeparator={locale === Language.VI ? "," : "."}
      decimalScale={finalDecimalScale}
      className={className}
    />
  );
};
