"use client";

import React from "react";

interface MobileNavigationProps {
  collapsed: boolean;
  onCollapse: (collapsed: boolean) => void;
}

export function MobileNavigation({ collapsed, onCollapse }: MobileNavigationProps) {
  // Mobile navigation is now handled by the header menu
  // This component is kept for compatibility but renders nothing
  return null;
}
