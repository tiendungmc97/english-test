"use client";

import Image from "next/image";
import { QuestionCircleOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { designTokens } from "@/utils/design-tokens";
import { CurrentTime } from "./ui/date-components";

export default function AppFooter({ onHelpClick = () => {}, logoSrc = "/images/vindas.svg" }) {
  const [currentTime, setCurrentTime] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const formattedTime = now.toLocaleString("vi-VN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
      setCurrentTime(formattedTime);
    };

    // Cập nhật thời gian ngay lập tức
    updateTime();

    // Cập nhật thời gian mỗi giây
    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, []);
  return (
    <footer className="fixed right-0 bottom-0 left-0 z-10 z-50 hidden h-[35px] w-full bg-white md:block">
      <div className="flex h-full w-full items-center justify-between px-6">
        {/* logo + text */}
        <div className="text-textSecondary flex items-center gap-2 text-[12px]">
          <Image
            src={logoSrc}
            alt="VinDAS"
            width={16}
            height={16}
          />
          <span>Copyright @ 2025 VinDAS. All rights reserved.</span>
        </div>

        {/* help + time */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onHelpClick}
            aria-label="Help"
            className="bg-border text-textSecondary flex h-7 w-7 items-center justify-center rounded transition-colors"
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = designTokens.colors.textSecondary;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = designTokens.colors.border;
            }}
          >
            <QuestionCircleOutlined className="text-[16px]" />
          </button>
          <CurrentTime
            format="HH:mm:ss DD/MM/YYYY"
            className="text-[12px]"
          />
        </div>
      </div>
    </footer>
  );
}
