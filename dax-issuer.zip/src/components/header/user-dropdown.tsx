"use client";

import React from "react";
import Image from "next/image";
import {
  InfoCircleOutlined,
  SettingOutlined,
  UsergroupAddOutlined,
  LogoutOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import { Tag } from "antd";
import { designTokens } from "@/utils/design-tokens";

interface UserDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onUserDropdownEnter: () => void;
  onUserDropdownLeave: () => void;
  name?: string;
  email?: string;
  userInfo?: {
    isKycCompleted: boolean;
    levelName: string;
  };
  onNavigate: (path: string) => void;
  onLogout: () => void;
  userDropdownRef: React.RefObject<HTMLDivElement | null>;
}

function DropdownItem({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick?: () => void }) {
  return (
    <div
      className="flex cursor-pointer items-center rounded-lg px-3 py-2 transition-colors"
      onClick={onClick}
      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = designTokens.colors.bgLayout)}
      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
    >
      {icon}
      <span className="text-sm">{label}</span>
    </div>
  );
}

export function UserDropdown({
  isOpen,
  onClose,
  onUserDropdownEnter,
  onUserDropdownLeave,
  name,
  email,
  userInfo,
  onNavigate,
  onLogout,
  userDropdownRef,
}: UserDropdownProps) {
  if (!isOpen) return null;

  return (
    <div
      className="border-border absolute top-16 right-0 z-50 hidden w-64 border bg-white shadow-lg md:block"
      ref={userDropdownRef}
      onMouseEnter={onUserDropdownEnter}
      onMouseLeave={onUserDropdownLeave}
    >
      {/* User info header */}
      <div className="bg-white p-4">
        <div className="flex items-center space-x-3">
          <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full">
            <Image
              src="/images/demo/image.png"
              alt={name || "User Avatar"}
              width={40}
              height={40}
              className="h-full w-full object-cover"
            />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-textBase text-sm font-medium">{name}</div>
            <div className="text-textSecondary text-xs">{email}</div>

            {/* KYC Status */}
            {userInfo && (
              <div className="mt-2 flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <CheckCircleOutlined
                    className={`text-xs ${userInfo.isKycCompleted ? "text-green-500" : "text-gray-400"}`}
                  />
                  <span className={`text-xs ${userInfo.isKycCompleted ? "text-green-600" : "text-gray-500"}`}>
                    {userInfo.isKycCompleted ? "Xác minh" : "Chưa xác minh"}
                  </span>
                </div>

                {/* Level Badge */}
                <Tag className="border-primaryBorder !text-primary !bg-primaryBg !rounded-full border !px-2 !py-[1px] !text-[10px] font-semibold">
                  {userInfo.levelName}
                </Tag>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Menu items */}
      <div className="p-2">
        <DropdownItem
          icon={<InfoCircleOutlined className="mr-3 text-xl" />}
          label="Thông tin"
          onClick={() => {
            onClose();
            onNavigate("/profile/general");
          }}
        />
        <DropdownItem
          icon={<UsergroupAddOutlined className="mr-3 text-xl" />}
          label="Giới thiệu"
          onClick={() => {
            onClose();
            onNavigate("/profile/referral");
          }}
        />
        <DropdownItem
          icon={<SettingOutlined className="mr-3 text-xl" />}
          label="Cài đặt"
          onClick={() => {
            onClose();
            onNavigate("/settings/general");
          }}
        />
        <div className="border-border mt-2 border-t pt-2">
          <div
            className="flex cursor-pointer items-center rounded-lg px-3 py-2 transition-colors"
            onClick={onLogout}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = designTokens.colors.errorBg)}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
          >
            <LogoutOutlined className="!text-error mr-3 text-xl" />
            <span className="text-error text-sm">Đăng xuất</span>
          </div>
        </div>
      </div>
    </div>
  );
}
