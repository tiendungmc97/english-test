"use client";

import React, { use } from "react";
import { BellOutlined, CheckCircleOutlined, ExclamationCircleOutlined, InfoCircleOutlined } from "@ant-design/icons";
import { Typography } from "antd";
import { useRouter } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
const { Text, Title } = Typography;

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onNotificationDropdownEnter: () => void;
  onNotificationDropdownLeave: () => void;
  notificationDropdownRef: React.RefObject<HTMLDivElement | null>;
}

interface NotificationItem {
  id: string;
  type: "success" | "warning" | "info" | "error";
  title: string;
  message: string;
  time: string;
  isRead: boolean;
}

function NotificationItem({
  notification,
  onMarkAsRead,
}: {
  notification: NotificationItem;
  onMarkAsRead: (id: string) => void;
}) {
  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircleOutlined className="!text-green-500" />;
      case "warning":
        return <ExclamationCircleOutlined className="!text-yellow-500" />;
      case "error":
        return <ExclamationCircleOutlined className="!text-red-500" />;
      default:
        return <InfoCircleOutlined className="!text-primary" />;
    }
  };

  return (
    <div
      className={`border-l-2 ${
        !notification.isRead ? "bg-primaryBg" : "bg-white"
      } border-border cursor-pointer rounded-sm border p-3 transition-colors hover:bg-gray-50`}
      onClick={() => onMarkAsRead(notification.id)}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5">{getIcon(notification.type)}</div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between">
            <h4 className="truncate text-sm font-medium text-gray-900">{notification.title}</h4>
            {!notification.isRead && <div className="bg-primary h-2 w-2 flex-shrink-0 rounded-full" />}
          </div>
          <p className="mt-1 line-clamp-2 text-xs text-gray-600">{notification.message}</p>
          <p className="mt-1 text-xs text-gray-400">{notification.time}</p>
        </div>
      </div>
    </div>
  );
}

export function NotificationDropdown({
  isOpen,
  onClose,
  onNotificationDropdownEnter,
  onNotificationDropdownLeave,
  notificationDropdownRef,
}: NotificationDropdownProps) {
  const router = useRouter();
  if (!isOpen) return null;

  // Mock notification data
  const notifications: NotificationItem[] = [
    {
      id: "1",
      type: "success",
      title: "Giao dịch thành công",
      message: "Bạn đã nạp 1,000,000 VND vào tài khoản thành công.",
      time: "5 phút trước",
      isRead: false,
    },
    {
      id: "2",
      type: "warning",
      title: "Cảnh báo bảo mật",
      message: "Có hoạt động đăng nhập bất thường từ thiết bị mới.",
      time: "1 giờ trước",
      isRead: false,
    },
    {
      id: "3",
      type: "info",
      title: "Cập nhật hệ thống",
      message: "Hệ thống sẽ được bảo trì từ 2:00 - 4:00 sáng ngày mai.",
      time: "3 giờ trước",
      isRead: true,
    },
    {
      id: "4",
      type: "success",
      title: "Rút tiền hoàn tất",
      message: "Yêu cầu rút 500 USDT đã được xử lý thành công.",
      time: "1 ngày trước",
      isRead: true,
    },
  ];

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkAsRead = (id: string) => {
    console.log(`Marking notification ${id} as read`);
  };

  const handleMarkAllAsRead = () => {
    console.log("Marking all notifications as read");
  };
  const handleSeeAll = () => {
    router.push(ROUTERS.NOTIFICATION.INDEX);
    onClose();
  };

  return (
    <div
      className="border-border absolute top-16 right-0 z-50 hidden w-80 border bg-white shadow-lg md:block"
      ref={notificationDropdownRef}
      onMouseEnter={onNotificationDropdownEnter}
      onMouseLeave={onNotificationDropdownLeave}
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <Title
            level={5}
            className="font-bold text-gray-900 uppercase dark:text-white"
          >
            Thông báo
          </Title>
          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllAsRead}
              className="text-primary hover:text-primaryHover cursor-pointer text-sm"
            >
              Đánh dấu đọc tất cả
            </button>
          )}
        </div>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {notifications.length > 0 ? (
          <div className="space-y-2 p-2">
            {notifications.map((notification) => (
              <NotificationItem
                key={notification.id}
                notification={notification}
                onMarkAsRead={handleMarkAsRead}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-gray-500">
            <BellOutlined className="mb-2 text-4xl" />
            <p className="text-sm">Không có thông báo nào</p>
          </div>
        )}
      </div>

      {notifications.length > 0 && (
        <div className="p-3">
          <button
            onClick={handleSeeAll}
            className="w-full cursor-pointer rounded-sm bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
          >
            Xem tất cả thông báo
          </button>
        </div>
      )}
    </div>
  );
}
