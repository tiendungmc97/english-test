"use client";

import { usePathname } from "@/i18n/navigation";
import { RightOutlined, HomeOutlined } from "@ant-design/icons";
import Link from "next/link";

interface BreadcrumbItem {
  label: string;
  href?: string;
  current?: boolean;
}

const routeLabels: Record<string, string> = {
  dashboard: "Dashboard",
  profile: "Thông Tin Tổ Chức",
  "manager-asset": "Quản Lý Tài Sản",
  report: "Báo Cáo Tài Sản",
};

// Asset names mapping for dynamic routes
const assetNames: Record<string, string> = {
  B001: "Bạc Miếng 999 1 Lượng",
  B002: "Bạc Thỏi 999 10 Lượng",
  B003: "Bạc Thỏi 999 1 Kg",
};

function generateBreadcrumbs(pathname: string): BreadcrumbItem[] {
  const pathSegments = pathname.split("/").filter(Boolean);
  const breadcrumbs: BreadcrumbItem[] = [];

  // Always start with Home/Dashboard
  breadcrumbs.push({
    label: "Dashboard",
    href: "/dashboard",
  });

  // Build breadcrumbs from path segments
  let currentPath = "";
  for (let i = 0; i < pathSegments.length; i++) {
    const segment = pathSegments[i];
    currentPath += `/${segment}`;

    // Skip locale segment
    if (i === 0 && (segment === "en" || segment === "vi")) {
      continue;
    }

    // Skip if it's just "dashboard" since we already added it
    if (segment === "dashboard") {
      continue;
    }

    const isLast = i === pathSegments.length - 1;

    // Check if this is an asset ID (like B001, B002, etc.)
    let label = routeLabels[segment] || segment;
    if (assetNames[segment]) {
      label = assetNames[segment];
    }

    breadcrumbs.push({
      label,
      href: isLast ? undefined : currentPath,
      current: isLast,
    });
  }

  return breadcrumbs;
}

export default function Breadcrumb() {
  const pathname = usePathname();
  const breadcrumbs = generateBreadcrumbs(pathname);

  return (
    <nav
      className="mb-6 flex"
      aria-label="Breadcrumb"
    >
      <ol className="flex items-center space-x-2">
        {breadcrumbs.map((item, index) => (
          <li
            key={index}
            className="flex items-center"
          >
            {index > 0 && <RightOutlined className="mx-2 text-xs text-gray-400" />}

            {index === 0 && <HomeOutlined className="mr-2 text-gray-400" />}

            {item.href && !item.current ? (
              <Link
                href={item.href}
                className="text-sm font-medium text-gray-500 transition-colors duration-200 hover:text-purple-600"
              >
                {item.label}
              </Link>
            ) : (
              <span
                className={`text-sm font-medium ${item.current ? "text-purple-600" : "text-gray-900"}`}
                aria-current={item.current ? "page" : undefined}
              >
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
