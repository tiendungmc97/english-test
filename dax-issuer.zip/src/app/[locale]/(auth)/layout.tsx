"use client";

import Image from "next/image";
import { Carousel } from "antd";
import { useTranslations } from "next-intl";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const t = useTranslations("AuthCarousel");

  const contents = [
    {
      title: t("slide1.title"),
      subtitle: t("slide1.subtitle"),
      description: t("slide1.description"),
      images: "/images/login/bg-image.svg",
    },
    {
      title: t("slide2.title"),
      subtitle: t("slide2.subtitle"),
      description: t("slide2.description"),
      images: "/images/login/bg-image.svg",
    },
    {
      title: t("slide3.title"),
      subtitle: t("slide3.subtitle"),
      description: t("slide3.description"),
      images: "/images/login/bg-image.svg",
    },
    {
      title: t("slide4.title"),
      subtitle: t("slide4.subtitle"),
      description: t("slide4.description"),
      images: "/images/login/bg-image.svg",
    },
    {
      title: t("slide5.title"),
      subtitle: t("slide5.subtitle"),
      description: t("slide5.description"),
      images: "/images/login/bg-image.svg",
    },
  ];
  return (
    <div className="mx-auto">
      <div className="flex h-[100svh] pb-10">
        <div className="relative h-full w-full overflow-hidden overflow-y-scroll p-6 md:px-20 md:pt-10 lg:w-1/2">
          <div
            className="absolute bottom-0 -left-48 hidden h-[400px] w-full lg:block"
            aria-hidden="true"
          >
            <Image
              src="/images/login/bg-triangle-bottom.svg"
              alt=""
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="bg-layout z-50 flex w-full items-center gap-4 bg-none sm:sticky sm:-top-10 md:py-10">
            <Image
              src="/images/vindas.svg"
              alt="vindas-icon"
              priority
              width={55}
              height={55}
            />
            <Image
              src="/images/vindas-text.svg"
              alt="vindas-text"
              priority
              width={140}
              height={40}
            />
          </div>
          <div className="!z-50 mx-auto max-w-[600px] pt-8 sm:pt-0">{children}</div>
        </div>
        <div className="relative top-0 hidden h-full w-1/2 lg:block">
          <Carousel
            autoplay={{ dotDuration: true }}
            autoplaySpeed={5000}
            arrows
            className="h-full w-full rounded-l-2xl"
          >
            {contents.map((content, index) => (
              <div
                key={index}
                className="relative h-full w-full rounded-l-2xl"
              >
                <Image
                  src={content.images}
                  alt={content.title}
                  priority
                  width={640}
                  height={800}
                  className="h-screen w-full object-cover"
                />
                <div className="absolute bottom-20 flex w-full flex-col items-center text-white">
                  <p className="text-center text-2xl font-semibold uppercase">{content.title}</p>
                  <p className="text-center text-2xl font-bold uppercase">{content.subtitle}</p>
                  <p className="text-md max-w-80 pt-4 text-center font-bold">{content.description}</p>
                </div>
              </div>
            ))}
          </Carousel>
        </div>
      </div>
    </div>
  );
}
