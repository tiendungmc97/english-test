"use client";
import { QRCodeStep } from "@/components/setup-2fa/setup-step";
import { VerifyStep } from "@/components/setup-2fa/verify-step";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useRouter } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { useAppSelector } from "@/redux/store";
import { useEffect, useState } from "react";

enum TwoFAStep {
  QRCode = "qrCode",
  Verify = "verify",
}

interface TwoFAQRCodeData {
  qrCodeUrl: string;
  secret: string;
}

export default function Verify2FAPage() {
  const userInfo = useAppSelector((state) => state.user.user);
  const router = useRouter();

  const initialStep = userInfo?.provisioningUri ? TwoFAStep.QRCode : TwoFAStep.Verify;
  const [currentStep, setCurrentStep] = useState<TwoFAStep>(initialStep);
  useEffect(() => {
    setCurrentStep(initialStep);
  }, [initialStep]);

  const qrCodeData: TwoFAQRCodeData = {
    qrCodeUrl: userInfo?.provisioningUri ?? "",
    secret: "",
  };
  const onSuccessVerify = () => {
    router.push(ROUTERS.ISSUER.MANAGER_ASSET);
  };

  if (!userInfo?.validate2FaKey && !userInfo?.provisioningUri) {
    return (
      <div className="flex min-h-[60svh] items-center justify-center bg-gray-50">
        <LoadingSpinner text="Đang tải thông tin..." />
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-md space-y-8 p-6">
        {currentStep === TwoFAStep.QRCode && (
          <QRCodeStep
            qrData={qrCodeData}
            onNext={() => setCurrentStep(TwoFAStep.Verify)}
          />
        )}
        <VerifyStep
          onSuccess={onSuccessVerify}
          type={currentStep === TwoFAStep.QRCode ? "setup" : "verify"}
        />
      </div>
    </div>
  );
}
