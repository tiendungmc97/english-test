"use client";

import { InputPasswordField } from "@/components/ui/form/input-password";
import { InputTextField } from "@/components/ui/form/input-text";
import { Link, useRouter } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { passwordSchema } from "@/libs/validations";
import { clearUserInfo, updateUserInfo } from "@/redux/slice/user.slice";
import { useAppDispatch } from "@/redux/store";
import { useMutationLogin } from "@/services/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button, Form } from "antd";
import { useTranslations } from "next-intl";
import { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";

const createLoginSchema = (t: any) =>
  z.object({
    email: z.string().email({ message: t("email.required") }),
    password: passwordSchema(t),
    turnstile: z.string().optional(),
  });

export function LoginForm() {
  const [form] = Form.useForm();
  const t = useTranslations("AuthPage");
  const tValidate = useTranslations("Validation");
  const schema = createLoginSchema(tValidate);
  const router = useRouter();
  const dispatch = useAppDispatch();

  const [error, setError] = useState<string | null>(null);
  const { mutate: login, isPending: isLogin } = useMutationLogin();
  const methods = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    resolver: zodResolver(schema),
    defaultValues: {
      email: "taidang0818@yopmail.com",
      password: "Tai123@123a",
      turnstile: "",
    },
  });

  useEffect(() => {
    dispatch(clearUserInfo());
  }, [dispatch]);

  const onSubmit = async (data: z.infer<typeof schema>) => {
    setError(null);
    const { email, password, turnstile } = data;
    login(
      { login: email, password },
      {
        onSuccess: (data) => {
          router.push(ROUTERS.AUTH.VERIFY_2FA);
          dispatch(updateUserInfo(data.data));
        },
        onError: (error: any) => {
          setError(error?.response?.data?.message || error.message);
        },
      },
    );
  };

  return (
    <div className="space-y-4">
      <p className="relative pt-10 pb-6 text-2xl font-bold uppercase">{t("login")}</p>

      {error && <div className="border-error text-error rounded-md border bg-white p-3 text-sm">{error}</div>}

      <FormProvider {...methods}>
        <Form
          form={form}
          onFinish={methods.handleSubmit(onSubmit)}
          disabled={isLogin}
          className="space-y-4"
          layout="vertical"
        >
          <InputTextField
            name="email"
            label={t("email")}
            placeholder={t("emailPlaceholder")}
            required
            className="!px-5 !py-4"
            autoFocus
          />

          <InputPasswordField
            name="password"
            label={t("password")}
            placeholder={t("passwordPlaceholder")}
            required
            className="!px-5 !py-4"
          />

          <div className="h-full w-full rounded-sm bg-[url('/images/login/bg-button.svg')] bg-cover bg-center bg-no-repeat p-1 shadow md:mt-16">
            <Button
              type="text"
              className="w-full rounded-sm !border-[1px] !border-white !px-2 !py-6 !shadow-md"
              loading={isLogin}
              onClick={form.submit}
              htmlType="submit"
            >
              <span className="text-lg font-bold text-black uppercase">{t("login")}</span>
            </Button>
          </div>
        </Form>
      </FormProvider>
      <div className="mt-8 flex flex-col justify-center">
        <div className="text-md z-10 text-center">
          <span>{t("dontHaveAccount")} </span>
          <Link
            href="/register"
            className="!text-primary font-bold hover:underline"
          >
            {t("register")}
          </Link>
        </div>
        <div className="z-10 text-center">
          <Link
            href={ROUTERS.AUTH.FORGOT_PASSWORD}
            className="!text-primary font-bold hover:underline"
          >
            {t("forgotPassword")}
          </Link>
        </div>
      </div>
    </div>
  );
}
