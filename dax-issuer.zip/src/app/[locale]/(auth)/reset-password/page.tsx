import { ResetPasswordForm } from "./reset-password-form";

export default function ResetPasswordPage() {
  return (
    <div className="flex justify-center">
      <ResetPasswordForm />
    </div>
  );
}
