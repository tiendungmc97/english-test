"use client";

import { InputPasswordField } from "@/components/ui/form/input-password";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button, Form } from "antd";
import { useTranslations } from "next-intl";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";
import { useResetPassword } from "@/services/hooks/use-auth";
import { ResetPasswordData } from "@/services/service/auth-service";
import { useRouter } from "@/i18n/navigation";
import { useSearchParams } from "next/navigation";

export function ResetPasswordForm() {
  const t = useTranslations("AuthPage");
  const tValidate = useTranslations("Validation");
  const router = useRouter();
  const searchParams = useSearchParams();
  const resetKey = searchParams.get("key");
  const { mutate: resetPassword } = useResetPassword();

  const schema = z
    .object({
      password: z.string().min(8, { message: tValidate("password.minLength") }),
      confirmPassword: z.string(),
    })
    .refine((data) => data.password === data.confirmPassword, {
      message: tValidate("confirmPassword.match"),
      path: ["confirmPassword"],
    });

  const [form] = Form.useForm();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const methods = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    resolver: zodResolver(schema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  const { handleSubmit } = methods;

  const onSubmit = async (data: z.infer<typeof schema>) => {
    setIsLoading(true);
    setError(null);
    setSuccess(null);

    const resetBody: ResetPasswordData = {
      resetKey: resetKey ?? "",
      newPassword: data.password,
    };

    resetPassword(resetBody, {
      onSuccess: () => {
        setSuccess(t("passwordResetSuccess"));
        setTimeout(() => router.push("/login"), 2000);
        setIsLoading(false);
      },
      onError: () => {
        setError(t("somethingWentWrong"));
        setIsLoading(false);
      },
    });
  };

  return (
    <div className="w-full max-w-md space-y-4">
      <p className="relative pt-10 pb-6 text-2xl font-bold uppercase">{t("resetPassword")}</p>

      {error && <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-600">{error}</div>}

      {success && (
        <div className="rounded-md border border-green-200 bg-green-50 p-3 text-sm text-green-600">{success}</div>
      )}

      <FormProvider {...methods}>
        <Form
          form={form}
          onFinish={handleSubmit(onSubmit)}
          disabled={isLoading}
          className="space-y-4"
          layout="vertical"
        >
          <InputPasswordField
            name="password"
            label={t("passwordPlaceholder")}
            placeholder={t("passwordPlaceholder")}
            required
            className="!px-5 !py-4"
            autoFocus
          />

          <InputPasswordField
            name="confirmPassword"
            label={t("confirmPassword")}
            placeholder={t("confirmPasswordPlaceholder")}
            required
            className="!px-5 !py-4"
          />

          <div className="h-full w-full rounded-sm bg-[url('/images/login/bg-button.svg')] bg-cover bg-center bg-no-repeat p-1 shadow md:mt-16">
            <Button
              type="text"
              className="w-full rounded-sm !border-[1px] !border-white !px-2 !py-6 !shadow-md"
              loading={isLoading}
              onClick={form.submit}
            >
              <span className="text-lg font-bold text-black uppercase">{t("changePassword")}</span>
            </Button>
          </div>
        </Form>
      </FormProvider>
    </div>
  );
}
