"use client";

import { NotificationList, Notification } from "./notification-list";
import { useNotifications } from "../hooks/useNotifications";

const mockAnnouncementNotifications: Notification[] = [
  {
    id: "1",
    title: "System Maintenance Notice",
    content:
      "Scheduled maintenance will be performed on our trading platform tonight from 2:00 AM to 4:00 AM UTC. Your account security settings have been updated successfully. Two-factor authentication is now enabled for enhanced protection. Some services may be temporarily unavailable during this time.",
    time: "09:15:05",
    isRead: false,
  },
  {
    id: "2",
    title: "New Trading Pairs Available",
    content:
      "We're excited to announce the addition of new cryptocurrency trading pairs. You can now trade BTC/EUR, ETH/GBP, and ADA/USD on our platform.",
    time: "Yesterday 20:42:02",
    isRead: true,
  },
  {
    id: "3",
    title: "Updated Terms of Service",
    content:
      "Our Terms of Service have been updated to provide better clarity on trading policies. Please review the updated terms in your account settings.",
    time: "Yesterday 20:00:14",
    isRead: false,
  },
  {
    id: "4",
    title: "Security Enhancement",
    content:
      "We've implemented additional security measures to protect your account. All users are encouraged to enable two-factor authentication for enhanced security.",
    time: "Yesterday 17:00:00",
    isRead: true,
  },
  {
    id: "5",
    title: "Market Update",
    content:
      "Important market announcements and regulatory updates. Please stay informed about the latest developments in the cryptocurrency market.",
    time: "09/05 14:18:31",
    isRead: true,
  },
  {
    id: "6",
    title: "Platform Upgrade",
    content:
      "Our trading platform has been upgraded with new features including advanced charting tools and improved order execution speed.",
    time: "09/05 14:00:00",
    isRead: true,
  },
  {
    id: "7",
    title: "Fee Structure Update",
    content:
      "We're pleased to announce reduced trading fees for all users. The new fee structure will take effect starting next Monday.",
    time: "09/05 10:00:01",
    isRead: true,
  },
];

export function AnnouncementNotifications() {
  const { notifications, filter, setFilter, markAsRead, markAsUnread, deleteNotification } =
    useNotifications(mockAnnouncementNotifications);

  return (
    <NotificationList
      notifications={notifications}
      filter={filter}
      onFilterChange={setFilter}
      onMarkAsRead={markAsRead}
      onMarkAsUnread={markAsUnread}
      onDeleteNotification={deleteNotification}
      emptyStateMessage="announcement notifications"
    />
  );
}
