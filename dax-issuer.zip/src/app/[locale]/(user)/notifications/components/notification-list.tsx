"use client";

import { Dropdown, List, Typography, Empty } from "antd";
import { MoreOutlined } from "@ant-design/icons";

const { Text, Paragraph } = Typography;

export interface Notification {
  id: string;
  title: string;
  content: string;
  time: string;
  isRead: boolean;
}

export type FilterType = "all" | "unread" | "read";

export interface NotificationListProps {
  notifications: Notification[];
  filter: FilterType;
  onFilterChange: (filter: FilterType) => void;
  onMarkAsRead: (id: string) => void;
  onMarkAsUnread: (id: string) => void;
  onDeleteNotification: (id: string) => void;
  emptyStateMessage?: string;
}

export function NotificationList({
  notifications,
  filter,
  onFilterChange,
  onMarkAsRead,
  onMarkAsUnread,
  onDeleteNotification,
  emptyStateMessage = "No notifications",
}: NotificationListProps) {
  const filteredNotifications = notifications.filter((notification) => {
    if (filter === "unread") return !notification.isRead;
    if (filter === "read") return notification.isRead;
    return true;
  });

  const dropdownItems = (notification: Notification) => [
    {
      key: "read",
      label: notification.isRead ? "Mark as unread" : "Mark as read",
      onClick: () => (notification.isRead ? onMarkAsUnread(notification.id) : onMarkAsRead(notification.id)),
    },
    {
      key: "delete",
      label: "Delete",
      onClick: () => onDeleteNotification(notification.id),
      danger: true,
    },
  ];

  const filterItems = [
    { key: "all", label: "All" },
    { key: "unread", label: "Unread" },
    { key: "read", label: "Read" },
  ];

  const getFilterLabel = () => {
    const item = filterItems.find((item) => item.key === filter);
    return item ? item.label : "All";
  };

  return (
    <div className="w-full px-2 md:px-8">
      <div className="mb-6 flex items-center justify-end">
        <Dropdown
          menu={{
            items: filterItems.map((item) => ({
              key: item.key,
              label: item.label,
              onClick: () => onFilterChange(item.key as FilterType),
            })),
          }}
          trigger={["click"]}
        >
          <Text className="cursor-pointer text-blue-600 hover:text-blue-700">{getFilterLabel()} ▼</Text>
        </Dropdown>
      </div>

      {/* Notifications List */}
      {filteredNotifications.length > 0 ? (
        <List
          className="notification-list"
          dataSource={filteredNotifications}
          renderItem={(notification) => (
            <List.Item
              className={`notification-item cursor-pointer transition-colors hover:bg-gray-50 ${
                !notification.isRead ? "unread" : ""
              }`}
              onClick={() => onMarkAsRead(notification.id)}
            >
              <div className="md-px-6 flex w-full items-start justify-between gap-2 px-2">
                <div className="min-w-0 flex-1">
                  <div className="mb-2 flex items-start justify-between">
                    <Text
                      strong={!notification.isRead}
                      className={`font-semibold ${!notification.isRead ? "text-gray-900" : "text-gray-700"}`}
                    >
                      {notification.title}
                    </Text>
                    <Text className="flex-shrink-0 text-sm whitespace-nowrap text-gray-400">{notification.time}</Text>
                  </div>
                  <Paragraph
                    className={`block ${!notification.isRead ? "text-gray-800" : "text-gray-600"} max-w-[1200px]`}
                    ellipsis={{
                      rows: 1,
                      expandable: false,
                    }}
                  >
                    {notification.content}
                  </Paragraph>
                </div>
                <Dropdown
                  menu={{ items: dropdownItems(notification) }}
                  trigger={["click"]}
                >
                  <MoreOutlined
                    className="mt-1 flex-shrink-0 cursor-pointer text-gray-400 hover:text-gray-600"
                    onClick={(e: React.MouseEvent) => e.stopPropagation()}
                  />
                </Dropdown>
              </div>
            </List.Item>
          )}
        />
      ) : (
        <div className="py-16 text-center">
          <Empty
            description={filter === "all" ? emptyStateMessage : `No ${filter} ${emptyStateMessage.toLowerCase()}`}
            image={Empty.PRESENTED_IMAGE_SIMPLE}
          />
        </div>
      )}
    </div>
  );
}
