"use client";

import { NotificationList, Notification } from "./notification-list";
import { useNotifications } from "../hooks/useNotifications";

const mockAccountNotifications: Notification[] = [
  {
    id: "1",
    title: "Account Security Update",
    content:
      "Your account security settings have been updated successfully. Two-factor authentication is now enabled for enhanced protection. Your account security settings have been updated successfully. Two-factor authentication is now enabled for enhanced protection.",
    time: "09:15:05",
    isRead: false,
  },
  {
    id: "2",
    title: "Profile Verification Complete",
    content:
      "Congratulations! Your identity verification has been completed successfully. You can now access all trading features and higher withdrawal limits.",
    time: "Yesterday 20:42:02",
    isRead: true,
  },
  {
    id: "3",
    title: "Email Address Updated",
    content:
      "Your email address has been successfully changed to your new email. Please check your new email inbox for a confirmation message.",
    time: "Yesterday 20:00:14",
    isRead: true,
  },
  {
    id: "4",
    title: "Password Changed Successfully",
    content:
      "Your account password has been changed successfully. If you didn't make this change, please contact our support team immediately for assistance.",
    time: "Yesterday 17:00:00",
    isRead: true,
  },
  {
    id: "5",
    title: "Account Verification Required",
    content:
      "To ensure account security and compliance, please complete your account verification process. Upload your identification documents in the verification section.",
    time: "09/05 14:18:31",
    isRead: false,
  },
  {
    id: "6",
    title: "New Device Login Alert",
    content:
      "We detected a new login from an unrecognized device. If this wasn't you, please change your password and enable two-factor authentication immediately.",
    time: "09/05 14:00:00",
    isRead: false,
  },
  {
    id: "7",
    title: "Trading Limits Updated",
    content:
      "Your account trading limits have been updated based on your current verification level. Check your account settings for detailed information about your new limits.",
    time: "09/05 10:00:01",
    isRead: true,
  },
];

export function AccountNotifications() {
  const { notifications, filter, setFilter, markAsRead, markAsUnread, deleteNotification } =
    useNotifications(mockAccountNotifications);

  return (
    <NotificationList
      notifications={notifications}
      filter={filter}
      onFilterChange={setFilter}
      onMarkAsRead={markAsRead}
      onMarkAsUnread={markAsUnread}
      onDeleteNotification={deleteNotification}
      emptyStateMessage="account notifications"
    />
  );
}
