"use client";

import { NotificationList, Notification } from "./notification-list";
import { useNotifications } from "../hooks/useNotifications";

const mockTransactionNotifications: Notification[] = [
  {
    id: "1",
    title: "Deposit Confirmed",
    content:
      "Your deposit of 1,000 USDT has been successfully confirmed and credited to your account. Your account security settings have been updated successfully. Two-factor authentication is now enabled for enhanced protection. Transaction ID: TXN123456789",
    time: "09:15:05",
    isRead: false,
  },
  {
    id: "2",
    title: "Withdrawal Processed",
    content:
      "Your withdrawal request of 0.5 BTC has been processed successfully. The funds will be transferred to your wallet within 24 hours.",
    time: "Yesterday 20:42:02",
    isRead: true,
  },
  {
    id: "3",
    title: "Trade Executed",
    content:
      "Your buy order for 2.5 ETH at $2,450 has been successfully executed. The transaction has been completed and your balance updated.",
    time: "Yesterday 20:00:14",
    isRead: true,
  },
  {
    id: "4",
    title: "Stop Loss Triggered",
    content:
      "Your stop loss order for BTC/USDT has been triggered and executed at $42,500. Please review your trading history for details.",
    time: "Yesterday 17:00:00",
    isRead: false,
  },
  {
    id: "5",
    title: "Large Transaction Alert",
    content:
      "A large transaction exceeding $10,000 has been detected on your account. If you didn't authorize this transaction, please contact support immediately.",
    time: "09/05 14:18:31",
    isRead: true,
  },
  {
    id: "6",
    title: "Transaction Failed",
    content:
      "Your recent transaction attempt has failed due to insufficient balance. Please ensure you have adequate funds before retrying the transaction.",
    time: "09/05 14:00:00",
    isRead: true,
  },
  {
    id: "7",
    title: "Margin Call",
    content:
      "Your margin position is approaching liquidation level. Please add more funds or close some positions to maintain your account balance.",
    time: "09/05 10:00:01",
    isRead: true,
  },
];

export function TransactionNotifications() {
  const { notifications, filter, setFilter, markAsRead, markAsUnread, deleteNotification } =
    useNotifications(mockTransactionNotifications);

  return (
    <NotificationList
      notifications={notifications}
      filter={filter}
      onFilterChange={setFilter}
      onMarkAsRead={markAsRead}
      onMarkAsUnread={markAsUnread}
      onDeleteNotification={deleteNotification}
      emptyStateMessage="transaction notifications"
    />
  );
}
