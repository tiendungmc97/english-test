"use client";

import { BellOutlined, SwapOutlined, UserOutlined } from "@ant-design/icons";
import { Card, Tabs, Typography } from "antd";
import { useEffect, useState } from "react";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { AccountNotifications } from "./components/account";
import { AnnouncementNotifications } from "./components/announcement";
import { TransactionNotifications } from "./components/transactions";
const { Title } = Typography;
type TabType = "account" | "announcement" | "transactions";
interface TabItem {
  key: TabType;
  label: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const tabItems: TabItem[] = [
  {
    key: "announcement",
    label: "Thông báo",
    icon: <BellOutlined />,
    children: <AnnouncementNotifications />,
  },
  {
    key: "account",
    label: "Tài khoản",
    icon: <UserOutlined />,
    children: <AccountNotifications />,
  },
  {
    key: "transactions",
    label: "Giao dịch",
    icon: <SwapOutlined />,
    children: <TransactionNotifications />,
  },
];

export default function PortfolioHistoryPage() {
  const [activeTab, setActiveTab] = useState<TabType>("announcement");
  const searchParams = useSearchParams();

  useEffect(() => {
    const tab = searchParams.get("tab") as TabType;
    if (tab && ["account", "announcement", "transactions"].includes(tab)) {
      setActiveTab(tab);
    }
  }, [searchParams]);

  const handleTabChange = (key: string) => {
    setActiveTab(key as TabType);
    const params = new URLSearchParams(searchParams.toString());
    params.set("tab", key);
  };

  return (
    <Card className="!border-none">
      <Title level={3}>Tin nhắn</Title>
      <Tabs
        activeKey={activeTab}
        onChange={handleTabChange}
        items={tabItems}
        size="large"
        className="history-tabs"
      />
    </Card>
  );
}
