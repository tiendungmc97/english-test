"use client";
import Footer from "@/components/footer";
import Header from "@/components/header";
import { AntSideNav } from "@/components/sidenav/ant-sidenav";
import { MobileNavigation } from "@/components/sidenav/mobile-navigation";
import { usePathname, useRouter } from "@/i18n/navigation";
import { getTimezoneValue } from "@/libs/options/timezone";
import { Language } from "@/libs/types/language";
import { setListCurrencyInfo, SettingState, updateSettings } from "@/redux/slice/setting.slice";
import { useAppDispatch } from "@/redux/store";
import { useQueryListCurrency, useQuerySettings } from "@/services/hooks/use-user";
import { useLocale } from "next-intl";
import { ReactNode, useEffect, useState } from "react";
import { Layout } from "antd";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { ApiStatusCode } from "@/services/api/types";

const { Content } = Layout;

interface UserLayoutProps {
  children: ReactNode;
}

const UserLayout = ({ children }: UserLayoutProps) => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const locale = useLocale();
  const pathname = usePathname();
  const { data: dataSettings, isLoading: isLoadingSettings } = useQuerySettings();
  const { data: dataListCurrency, isLoading: isLoadingCurrency } = useQueryListCurrency();
  const [collapsed, setCollapsed] = useState(false);

  // Check if current route is a wallet route
  const isWalletRoute = pathname.startsWith("/wallet");

  // Check if all initial data is loaded
  const isLoading = isLoadingSettings || isLoadingCurrency;

  useEffect(() => {
    if (dataSettings && dataSettings.meta.code === ApiStatusCode.SUCCESS) {
      const valueTimezone = getTimezoneValue(dataSettings.data.timezone);
      const settings: Partial<SettingState> = {
        currency: dataSettings.data.currencyName,
        timezone: valueTimezone,
      };
      const lang = dataSettings.data.lang.split("_")?.[0] || Language.VI;
      // if (dataSettings.data.lang !== locale) {
      //   router.replace(pathname, { locale: lang });
      // }
      dispatch(updateSettings(settings));
    }
  }, [dataSettings, dispatch]);

  useEffect(() => {
    if (dataListCurrency && dataListCurrency.meta.code === 200) {
      dispatch(setListCurrencyInfo(dataListCurrency.data));
    }
  }, [dataListCurrency, dispatch]);

  // Show loading spinner while data is loading
  if (isLoading) {
    return (
      <Layout className="!flex !min-h-screen !flex-col">
        <Header />
        <Layout className="!flex !flex-1">
          <LoadingSpinner
            className="flex-1"
            text="Đang tải thông tin..."
          />
        </Layout>
        <Footer />
      </Layout>
    );
  }

  return (
    <Layout className="!flex !min-h-screen !flex-col">
      {/* <Header /> */}
      <Layout className="!flex !flex-1">
        {!isWalletRoute && (
          <AntSideNav
            collapsed={collapsed}
            onCollapse={setCollapsed}
          />
        )}
        <Layout className="!flex !flex-1">
          <Content className="!bg-white">{children}</Content>
        </Layout>
      </Layout>
      <Footer />

      {/* Mobile Navigation - Bottom Tab Bar + Drawer */}
      {!isWalletRoute && (
        <MobileNavigation
          collapsed={collapsed}
          onCollapse={setCollapsed}
        />
      )}
    </Layout>
  );
};

export default UserLayout;
