"use client";

import { NoDataHandler, ProfileErrorHandler } from "@/components/ui/error-handler";
import { useUserInfo } from "@/services/hooks/use-auth";
import Image from "next/image";
import ReferralHistory from "./referral-history";
import RewardHistory from "./reward-history";

export default function ProfileReferral() {
  const { data: userData, isLoading, error } = useUserInfo();

  if (isLoading) return <Loader />;
  if (error) return <ProfileErrorHandler error={error} />;
  if (!userData || !userData.data) return <NoDataHandler message="Không có dữ liệu người dùng" />;

  const u = userData.data;
  const referralLink =
    typeof window !== "undefined" ? `${window.location.origin}/register?referralCode=${u.referralCode ?? ""}` : "";

  return (
    <div className="min-h-screen bg-white">
      <div className="px-4 py-5 md:px-6 md:py-6">
        <div className="space-y-6">
          <ReferralHistory />
          <RewardHistory />
        </div>
      </div>
    </div>
  );
}

function Loader() {
  return <div className="text-textSecondary flex h-full items-center justify-center p-6">Đang tải thông tin...</div>;
}

function Page({ children }: { children: React.ReactNode }) {
  return <div className="px-4 py-5 md:px-6 md:py-6">{children}</div>;
}
function PageTitle({ children }: { children: React.ReactNode }) {
  return <h1 className="text-textBase text-xl font-bold md:text-2xl">{children}</h1>;
}
function HeaderSection({ children }: { children: React.ReactNode }) {
  return (
    <section className="mt-4 flex flex-col gap-5 rounded-xl border-y border-gray-200 px-4 py-5 md:flex-row md:items-start md:gap-8 md:px-6 md:py-6">
      {children}
    </section>
  );
}
function Avatar({ src, name }: { src?: string | null; name?: string | null }) {
  return (
    <div className="flex shrink-0 items-center justify-center">
      <div className="h-24 w-24 overflow-hidden rounded-full md:h-40 md:w-40">
        <Image
          src={src || "/images/demo/image.png"}
          alt={name || "User Avatar"}
          width={160}
          height={160}
          className="h-full w-full object-cover"
        />
      </div>
    </div>
  );
}
function TitleRow({ children }: { children: React.ReactNode }) {
  return <div className="mb-4 flex flex-col gap-2 md:mb-6 md:flex-row md:items-center md:gap-3">{children}</div>;
}
function TitleText({ children }: { children: React.ReactNode }) {
  return <h3 className="text-textBase min-w-0 flex-1 truncate text-lg font-semibold md:text-[20px]">{children}</h3>;
}
function InfoGrid({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2 md:grid-cols-3">{children}</div>;
}
function InfoItem({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-textSecondary mb-1 text-[12px] uppercase">{label}</div>
      <div className="text-textBase truncate text-base font-medium">{children}</div>
    </div>
  );
}
function Spacer() {
  return <div className="hidden md:block" />;
}
