"use client";

import * as React from "react";
import { Card, Row, Col, Button, Typography } from "antd";
import { ReloadOutlined, UserAddOutlined } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import { MessageErrorHandler } from "@/components/ui/error-handler";
import { CommonTable, INIT_PAGINATION, type IPagination } from "@/components/ui/form/common-table";
import { FormProvider, useForm } from "react-hook-form";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { useReferralHistories } from "@/services/hooks/use-auth";
import { InviteModal } from "@/components/ui/invite-modal";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
const { Title } = Typography;

export type Referral = {
  key?: string;
  id: string | number;
  name?: string | null;
  joinedAt?: string | Date | null;
};

interface ReferralFilter {
  timeRange: [string, string] | null;
}

export default function ReferralHistory() {
  // pagination state (giữ logic)
  const [pagination, setPagination] = React.useState<IPagination>(INIT_PAGINATION);
  const [loading, setLoading] = React.useState(false);
  const [showInviteModal, setShowInviteModal] = React.useState(false);
  const currentPage = pagination.current || 1;
  const pageParam = isNaN(currentPage) ? 0 : Math.max(0, currentPage - 1);

  const methods = useForm<ReferralFilter>({
    defaultValues: {
      timeRange: null,
    },
  });

  const { reset } = methods;

  const {
    data: referralData,
    isLoading,
    error,
  } = useReferralHistories(
    pageParam, // 1-based -> 0-based
    pagination.pageSize,
  );

  // sync pagination từ meta (giữ logic)
  React.useEffect(() => {
    if (referralData?.meta) {
      const newCurrent = (referralData.meta.currentPage || 0) + 1; // 0-based -> 1-based
      setPagination((prev) => ({
        ...prev,
        total: referralData.meta.totalElements || 0,
        current: newCurrent,
      }));
    }
  }, [referralData?.meta]);

  if (isLoading) {
    return (
      <section className="mt-6 flex min-h-[120px] items-center justify-center rounded-xl">
        <LoadingSpinner text="Đang tải lịch sử giới thiệu..." />
      </section>
    );
  }

  if (error) {
    return (
      <section className="mt-6">
        <MessageErrorHandler error={error} />
      </section>
    );
  }

  const referrals = referralData?.data || [];
  const hasData = referrals.length > 0;

  const columns: ColumnsType<Referral> = [
    {
      title: "TÊN NGƯỜI ĐƯỢC GIỚI THIỆU",
      dataIndex: "name",
      key: "name",
      render: (v: React.ReactNode) => <span className="font-medium">{v ?? "-"}</span>,
      ellipsis: true,
    },
    {
      title: "THỜI GIAN THAM GIA",
      dataIndex: "joinedAt",
      key: "joinedAt",
      render: (v: string | Date | null | undefined) => <span>{formatDate(v) || "-"}</span>,
      width: 220,
      ellipsis: true,
    },
  ];

  const handleChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  };

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      timeRange: null,
    });
  };

  const handleInviteClick = () => {
    setShowInviteModal(true);
  };

  return (
    <div>
      <div className="!border-none !bg-white p-6">
        <Title
          level={5}
          className="font-bold text-gray-900 uppercase dark:text-white"
        >
          Lịch sử giới thiệu
        </Title>
      </div>

      <Card className="!border-none">
        {hasData ? (
          <CommonTable<Referral>
            rowKey={(r) => String(r.id)}
            columns={columns}
            dataSource={referrals}
            loading={loading}
            paginationData={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              onChange: handleChange,
            }}
          />
        ) : (
          <div className="border-border rounded-xl border py-8 text-center text-sm text-neutral-500">
            Bạn chưa có lịch sử giới thiệu.
          </div>
        )}
      </Card>

      {/* Invite Button */}
      <div className="mt-4 flex justify-center">
        <Button
          type="primary"
          icon={<UserAddOutlined />}
          onClick={handleInviteClick}
          className="!h-10 !px-8"
        >
          Mời bạn bè
        </Button>
      </div>

      {/* Invite Modal */}
      <InviteModal
        isOpen={showInviteModal}
        onClose={() => setShowInviteModal(false)}
      />
    </div>
  );
}

function EmptyBlock({ text }: { text: string }) {
  return <div className="rounded-xl border py-8 text-center text-sm text-neutral-500">{text}</div>;
}

/* Utils */
function formatDate(d?: string | Date | null) {
  if (!d || d === "-") return "-";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return String(d);
  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
