"use client";

import * as React from "react";
import { Button, Tabs, Card, Row, Col, Typography } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";
import { CommonTable, INIT_PAGINATION, type IPagination } from "@/components/ui/form/common-table";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { InputTextField } from "@/components/ui/form/input-text";
import dayjs from "dayjs";
const { Text, Title } = Typography;

export type Reward = {
  key?: string;
  id: string | number;
  name?: string | null;
  time?: string | Date | null;
  action?: string | null;
  amount?: number | null;
  balanceAfterReward?: number | null;
};

interface RewardFilter {
  timeRange: [string, string] | null;
  keyword: string;
  action: string | undefined;
}

const ACTION_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "register", label: "Đăng ký" },
  { value: "deposit", label: "Nạp tiền" },
  { value: "trade", label: "Giao dịch" },
];

export default function RewardHistory() {
  // pagination state
  const [pagination, setPagination] = React.useState<IPagination>(INIT_PAGINATION);
  const [loading, setLoading] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState<string>("bonus");

  const methods = useForm<RewardFilter>({
    defaultValues: {
      timeRange: null,
      keyword: "",
      action: undefined,
    },
  });

  const { watch, reset } = methods;

  const currentPage = pagination.current || 1;
  const pageParam = isNaN(currentPage) ? 0 : Math.max(0, currentPage - 1);

  // Mock data - replace with actual API call
  const mockRewards: Reward[] = [
    {
      id: 1,
      name: "Ta Thi Tuyet Nhi",
      time: "13/02/2025",
      action: "ĐĂNG KÝ",
      amount: 100000,
      balanceAfterReward: 30000000,
    },
    {
      id: 2,
      name: "Ta Thi Tuyet Nhi",
      time: "13/02/2025",
      action: "ĐĂNG KÝ",
      amount: 100000,
      balanceAfterReward: 30000000,
    },
  ];

  const isLoading = false;
  const error = null;
  const hasData = mockRewards.length > 0;

  const columns: ColumnsType<Reward> = [
    {
      title: "TÊN NGƯỜI ĐƯỢC GIỚI THIỆU",
      dataIndex: "name",
      key: "name",
      render: (v: React.ReactNode) => <span className="font-medium">{v ?? "-"}</span>,
      ellipsis: true,
    },
    {
      title: "THỜI GIAN",
      dataIndex: "time",
      key: "time",
      render: (v: string | Date | null | undefined) => <span className="text-center">{formatDate(v) || "-"}</span>,
      align: "center",
      ellipsis: true,
    },
    {
      title: "HÀNH ĐỘNG",
      dataIndex: "action",
      key: "action",
      render: (v: React.ReactNode) => <span className="text-center">{v ?? "-"}</span>,
      align: "center",
      ellipsis: true,
    },
    {
      title: "SỐ TIỀN",
      dataIndex: "amount",
      key: "amount",
      render: (amount: number | null) => (
        <span className="text-center font-medium text-green-600">{amount ? `+ ${formatCurrency(amount)}` : "-"}</span>
      ),
      align: "center",
      ellipsis: true,
    },
    {
      title: "SỐ DƯ SAU THƯỞNG",
      dataIndex: "balanceAfterReward",
      key: "balanceAfterReward",
      render: (balance: number | null) => (
        <span className="text-right font-medium">{balance ? formatCurrency(balance) : "-"}</span>
      ),
      align: "right",
      ellipsis: true,
    },
  ];

  const handleChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  };

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      timeRange: null,
      keyword: "",
      action: undefined,
    });
  };

  const tabItems = [
    {
      key: "bonus",
      label: "Cộng thưởng",
    },
  ];

  if (loading) {
    return (
      <div className="!border-none !bg-white p-6">
        <div className="flex min-h-[120px] items-center justify-center">
          <span className="text-neutral-500">Đang tải lịch sử phần thưởng...</span>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="!border-none !bg-white p-6">
        <Title
          level={5}
          className="font-bold text-gray-900 uppercase dark:text-white"
        >
          Lịch sử phần thưởng
        </Title>
        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          items={tabItems}
          className="!mt-5"
        />
      </div>

      <Card className="!border-none">
        <FormProvider {...methods}>
          <Row
            gutter={[16, 16]}
            className="!items-center"
          >
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="action"
                label="Hành động"
                placeholder="Chọn hành động"
                options={ACTION_OPTIONS}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <DateRangePickerField
                name="timeRange"
                label="Thời gian"
                placeholder={["Từ ngày", "Đến ngày"]}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <InputTextField
                name="keyword"
                label="Từ khóa"
                placeholder="Tìm kiếm"
              />
            </Col>
            <Col
              flex="auto"
              xs={24}
              className="!flex !justify-end !gap-2"
            >
              <Button onClick={handleReset}>Đặt lại</Button>
              <Button
                type="primary"
                icon={<ReloadOutlined />}
                onClick={handleFilter}
              >
                Tìm kiếm
              </Button>
            </Col>
          </Row>
        </FormProvider>
      </Card>

      <Card className="!border-none">
        {hasData ? (
          <CommonTable<Reward>
            rowKey={(r) => String(r.id)}
            columns={columns}
            dataSource={mockRewards}
            loading={loading}
            paginationData={{
              current: pagination.current,
              pageSize: pagination.pageSize,
              total: pagination.total,
              onChange: handleChange,
            }}
          />
        ) : (
          <div className="border-border rounded-xl border py-8 text-center text-sm text-neutral-500">
            Bạn chưa có lịch sử phần thưởng.
          </div>
        )}
      </Card>
    </div>
  );
}

function EmptyBlock({ text }: { text: string }) {
  return <div className="rounded-xl border py-8 text-center text-sm text-neutral-500">{text}</div>;
}

/* Utils */
function formatDate(d?: string | Date | null) {
  if (!d || d === "-") return "-";
  const date = typeof d === "string" ? new Date(d) : d;
  if (Number.isNaN(date.getTime())) return String(d);
  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("vi-VN", {
    style: "currency",
    currency: "VND",
  }).format(amount);
}
