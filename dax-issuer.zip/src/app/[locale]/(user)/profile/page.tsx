"use client";

import { useRouter } from "@/i18n/navigation";
import { useEffect } from "react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

export default function ProfilePage() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to /profile/general by default
    router.replace("/profile/general");
  }, [router]);

  return (
    <div className="flex min-h-[400px] items-center justify-center">
      <LoadingSpinner text="Đang tải thông tin..." />
    </div>
  );
}
