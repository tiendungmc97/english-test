"use client";

import React, { useState } from "react";
import { Tabs, Typography, type TabsProps } from "antd";
import { formatCurrency } from "@/utils/format-currency";
const { Title } = Typography;

interface IVipVolumeAndHistoryProps {
  levelName: string;
  minDeposit: number;
  maxDeposit: number;
  minWithdraw: number;
  maxWithdraw: number;
}

export default function VipVolumeAndHistory(props: IVipVolumeAndHistoryProps) {
  const [activeTab, setActiveTab] = useState("spot");
  const handleTabChange = (key: string) => {
    setActiveTab(key);
  };
  const { levelName, minDeposit, maxDeposit, minWithdraw, maxWithdraw } = props;
  const pct = Math.min(100, Math.max(0.1, (minDeposit / maxDeposit) * 100));
  const SpotContent = (
    <>
      <div className="grid grid-cols-[1.2fr_1fr] gap-6 text-sm">
        <div className="space-y-1">
          <div className="text-[11px] tracking-wide text-gray-400 uppercase">KL GIAO DỊCH GIAO NGAY TRONG 30 NGÀY</div>
          <div className="font-semibold text-gray-700">10.000.000 VND</div>
        </div>

        <div className="space-y-1">
          <div className="text-[11px] tracking-wide text-gray-400 uppercase">MAKER / TAKER</div>
          <div className="font-semibold text-[#8249DD]">0.0075% / 0.0075%</div>
        </div>
      </div>

      <div className="mt-2 flex h-64 w-full items-center justify-center rounded-md border border-dashed border-gray-300 text-sm tracking-wide text-gray-400 uppercase">
        imple chart later
      </div>
    </>
  );

  const items: TabsProps["items"] = [{ key: "spot", label: "Ví giao ngay", children: SpotContent }];

  return (
    <div className="space-y-6">
      <section className="px-5 py-4">
        <Title
          level={5}
          className="font-bold text-gray-900 uppercase dark:text-white"
        >
          Khối lượng giao dịch
        </Title>
        <div className="mt-6 text-xs text-gray-500">Để nâng cấp độ VIP tiếp theo</div>

        <div className="mt-3 h-[6px] w-full rounded-full bg-gray-200">
          <div
            className={`w-[${pct}%] bg-error h-[6px] rounded-full`}
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="mt-2 text-xs text-red-500">
          {formatCurrency(minDeposit)} / <span className="text-gray-500">{formatCurrency(maxDeposit)}</span>
        </div>
        <div className="mt-1 text-[11px] text-gray-400">Thứ hạng sẽ được cập nhật sau 30/04/2025</div>
      </section>
      <section className="bg-white px-5">
        <Title
          level={5}
          className="font-bold text-gray-900 uppercase dark:text-white"
        >
          Lịch sử thay đổi số dư
        </Title>
        <Tabs
          activeKey={activeTab}
          onChange={handleTabChange}
          items={items}
          size="large"
        />
      </section>
    </div>
  );
}
