"use client";
import React from "react";
import { Row, Col, Descriptions, Typography, Space } from "antd";
import { CheckOutlined } from "@ant-design/icons";

const { Text } = Typography;

export default function KycInfoSection() {
  return (
    <div className="px-2 py-5 md:px-6">
      <Row gutter={[24, 24]}>
        {/* Trái */}
        <Col
          xs={24}
          md={12}
        >
          <Descriptions
            colon={false}
            column={1}
            size="small"
            layout="vertical"
            styles={{
              label: { fontWeight: 600, color: "#595959" },
              content: { color: "#8c8c8c" },
            }}
            items={[
              { label: "Hạn mức tài khoản", children: "Xác minh tài khoản để mở khoá hạn mức giao dịch và rút tiền." },
            ]}
          />
          <div className="bg-gray200 my-3 h-px w-full border-b border-dashed" />
          <Descriptions
            colon={false}
            column={1}
            size="small"
            layout="vertical"
            styles={{
              label: { fontWeight: 600, color: "#595959" },
              content: { color: "#8c8c8c" },
            }}
            items={[
              {
                label: "Thông tin cá nhân",
                children: "Vui lòng xác minh để cập nhật thông tin chính xác và sử dụng đầy đủ tính năng.",
              },
            ]}
          />
        </Col>

        {/* Phải */}
        <Col
          xs={24}
          md={12}
        >
          <Text
            strong
            className="mb-3 block"
          >
            Các cấp độ xác minh
          </Text>

          <Space
            direction="vertical"
            size={16}
            className="w-full text-gray-400"
          >
            <Space align="start">
              <CheckOutlined className="mr-1" />
              <div>
                <Text className="!text-gray-400">Tiêu chuẩn</Text>
                <div>Hạn mức tiền ký quỹ của 5 tỷ VND hàng ngày</div>
              </div>
            </Space>

            <Space align="start">
              <CheckOutlined className="mr-1" />
              <div>
                <Text className="!text-gray-400">Xác minh nâng cao</Text>
                <div>Hạn mức tiền ký quỹ của 10 tỷ VND hàng ngày</div>
              </div>
            </Space>
          </Space>
        </Col>
      </Row>
    </div>
  );
}
