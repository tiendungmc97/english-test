"use client";

import { ProfileErrorHandler } from "@/components/ui/error-handler";
import { useUserInfo } from "@/services/hooks/use-auth";
import { CheckOutlined, CopyOutlined } from "@ant-design/icons";
import { Button, Card, Tag } from "antd";
import Image from "next/image";
import VipVolumeAndHistory from "../level/user-level";
import UserBankAccounts from "./user-bank-accounts";

export default function ProfilePage() {
  const { data: userRes, isLoading, error } = useUserInfo();

  if (isLoading) return <Loader />;
  if (error) return <ProfileErrorHandler error={error} />;
  const userData = userRes?.data;
  return (
    <div className="min-h-screen bg-white p-6">
      <div className="space-y-6">
        <Card className="!border-none">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:gap-8">
            <Avatar
              src={userData?.avatarUrl}
              name={userData?.name}
            />

            <div className="min-w-0 flex-1">
              <div className="flex items-start gap-2">
                <div className="flex-1">
                  <div className="flex">
                    <h3 className="text-xl font-semibold text-gray-900">{userData?.name}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">ID: {userData?.accountId}</span>
                    <Button
                      size="small"
                      type="text"
                      onClick={() => navigator.clipboard?.writeText?.(userData?.accountId ?? "")}
                      icon={<CopyOutlined className="!text-base text-gray-400" />}
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {userData?.isKycCompleted ? (
                  <Tag
                    className="!rounded-sm !border-none !bg-green-200 !px-3 !py-1 !text-[12px] font-semibold !text-green-500"
                    icon={<CheckOutlined className="!text-[12px] !text-green-500" />}
                  >
                    Đã xác minh
                  </Tag>
                ) : (
                  <>
                    <Tag
                      className="!rounded-sm !border-none !bg-gray-200 !px-3 !py-1 !text-[12px] font-semibold !text-gray-500"
                      icon={<CheckOutlined className="!text-[12px] !text-gray-500" />}
                    >
                      Chưa xác minh
                    </Tag>
                    <Button
                      type="primary"
                      className="!h-7 !rounded-sm !px-3 !py-3 !text-[12px] font-semibold"
                    >
                      Xác minh ngay
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-4">
            {/* Labels Column */}
            <div className="space-y-4">
              <div className="text-left text-sm font-medium text-gray-600">Email:</div>
              <div className="text-left text-sm font-medium text-gray-600">Số điện thoại:</div>
              <div className="text-left text-sm font-medium text-gray-600">Mã giới thiệu:</div>
              <div className="text-left text-sm font-medium text-gray-600">Link giới thiệu:</div>
            </div>

            {/* Data Column */}
            <div className="space-y-4">
              <div className="text-right text-sm font-medium text-gray-900">{userData?.email}</div>
              <div className="text-right text-sm font-medium text-gray-900">{userData?.phone || "Chưa cập nhật"}</div>
              <div className="text-right text-sm font-medium text-gray-900">
                <span className="flex items-center justify-end">
                  <span className="truncate font-mono text-sm">{userData?.referralCode || "—"}</span>
                  <Button
                    className="!m-0 !h-5 !min-h-0 !justify-end !p-0 !leading-5 hover:!bg-transparent focus:!bg-transparent active:!bg-transparent"
                    size="small"
                    type="text"
                    onClick={() => navigator.clipboard?.writeText?.(userData?.referralCode ?? "")}
                    icon={<CopyOutlined className="!text-base text-gray-400" />}
                  />
                </span>
              </div>
              <div className="text-right text-sm font-medium text-gray-900">
                <span className="flex items-center justify-end">
                  <span className="truncate text-sm">
                    {typeof window !== "undefined"
                      ? `${window.location.origin}/register?referralCode=${userData?.referralCode ?? ""}`
                      : "—"}
                  </span>
                  <Button
                    className="!m-0 !h-5 !min-h-0 !justify-end !p-0 !leading-5 hover:!bg-transparent focus:!bg-transparent active:!bg-transparent"
                    size="small"
                    type="text"
                    onClick={() =>
                      navigator.clipboard?.writeText?.(
                        typeof window !== "undefined"
                          ? `${window.location.origin}/register?referralCode=${userData?.referralCode ?? ""}`
                          : "",
                      )
                    }
                    icon={<CopyOutlined className="!text-base text-gray-400" />}
                  />
                </span>
              </div>
            </div>
          </div>
        </Card>

        {/* Bank Account Section */}
        <UserBankAccounts />

        {/* Trading Volume Section */}
        <VipVolumeAndHistory
          levelName={userData?.levelName ?? ""}
          minDeposit={userData?.minDeposit ?? 0}
          maxDeposit={userData?.maxDeposit ?? 0}
          minWithdraw={userData?.minWithdraw ?? 0}
          maxWithdraw={userData?.maxWithdraw ?? 0}
        />
      </div>
    </div>
  );
}

// Helper Components
function Loader() {
  return <div className="text-textSecondary flex h-full items-center justify-center p-6">Đang tải thông tin...</div>;
}

function Avatar({ src, name }: { src?: string | null; name?: string | null }) {
  return (
    <div className="flex shrink-0 items-center justify-center">
      <div className="h-16 w-16 overflow-hidden rounded-full md:h-20 md:w-20">
        <Image
          src={src || "/images/demo/image.png"}
          alt={name || "User Avatar"}
          width={80}
          height={80}
          className="h-full w-full object-cover"
        />
      </div>
    </div>
  );
}

function MessageErrorHandler({ error }: { error: any }) {
  return <div className="text-red-500">Lỗi: {error?.message || "Có lỗi xảy ra"}</div>;
}
