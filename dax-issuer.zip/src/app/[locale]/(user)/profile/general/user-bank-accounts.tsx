"use client";

import * as React from "react";
import type { ColumnsType } from "antd/es/table";
import { useUserBankAccounts } from "@/services/hooks/use-auth";
import { UserBankAccount } from "@/services/service/user-service";
import { MessageErrorHandler } from "@/components/ui/error-handler";
import { CommonCardField, CommonCardList } from "@/components/ui/form/card-list";
import { CommonTable, INIT_PAGINATION, IPagination } from "@/components/ui/form/common-table";
import { Typography } from "antd";
const { Title } = Typography;

const columns: ColumnsType<UserBankAccount> = [
  {
    title: "NGÂN HÀNG",
    dataIndex: "bankName",
    key: "bankName",
    render: (bankName: string) => <span className="font-medium">{bankName ?? "-"}</span>,
    ellipsis: true,
  },
  {
    title: "SỐ TÀI KHOẢN",
    dataIndex: "sanitizedAccNumber",
    key: "sanitizedAccNumber",
    render: (t: string) => <span className="tabular-nums">{t ?? "-"}</span>,
    ellipsis: true,
  },
  {
    title: "TÊN TÀI KHOẢN",
    dataIndex: "accHolderName",
    key: "accHolderName",
    render: (t: string) => <span>{t ?? "-"}</span>,
    ellipsis: true,
  },
];

const cardFields: CommonCardField<UserBankAccount>[] = [
  { key: "bankName", label: "Ngân hàng", render: (r) => r.bankName ?? "-" },
  { key: "sanitizedAccNumber", label: "Số tài khoản", render: (r) => r.sanitizedAccNumber ?? "-" },
  { key: "accHolderName", label: "Tên tài khoản", render: (r) => r.accHolderName ?? "-" },
];

export default function UserBankAccounts() {
  const { data: bankAccountsData, isLoading, error } = useUserBankAccounts();
  const bankAccounts: UserBankAccount[] = bankAccountsData?.data || [];
  const [pagination, setPagination] = React.useState<IPagination>(INIT_PAGINATION);

  if (isLoading) {
    return (
      <section className="mt-6 flex min-h-[120px] items-center justify-center rounded-xl">
        <span className="text-neutral-500">Đang tải tài khoản ngân hàng...</span>
      </section>
    );
  }

  if (error) {
    return (
      <section className="mt-6">
        <MessageErrorHandler error={error} />
      </section>
    );
  }

  const handleChange = (current: number, pageSize: number) => {
    setPagination({ current, pageSize, total: bankAccountsData?.data.length });
  };

  return (
    <div className="space-y-6">
      <section className="px-5 py-4">
        <div className="mb-6 flex items-center justify-between px-3 md:px-0">
          <Title
            level={5}
            className="font-bold text-gray-900 uppercase dark:text-white"
          >
            Tài khoản ngân hàng của bạn
          </Title>
        </div>

        {/* Mobile: Card list (reusable) */}
        <div className="md:hidden">
          <CommonCardList<UserBankAccount>
            data={bankAccounts}
            fields={cardFields}
            rowKey={(r: UserBankAccount) => String(r.id)}
            empty={
              <div className="rounded-xl border py-8 text-center text-sm text-neutral-500">
                Bạn chưa có tài khoản ngân hàng nào.
              </div>
            }
          />
        </div>

        {/* Desktop/Tablet: CommonTable (AntD default styles) */}
        <div className="hidden md:block">
          {bankAccounts.length > 0 ? (
            <CommonTable<UserBankAccount>
              rowKey={(r: UserBankAccount) => String(r.id)}
              columns={columns}
              dataSource={bankAccounts}
              paginationData={{
                current: pagination.current,
                pageSize: pagination.pageSize,
                total: bankAccounts.length,
                onChange: handleChange,
              }}
            />
          ) : (
            <div className="border-border rounded-xl border py-8 text-center text-sm text-neutral-500">
              Bạn chưa có tài khoản ngân hàng nào.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
