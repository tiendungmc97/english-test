// src/app/[locale]/(user)/profile/layout.tsx
import * as React from "react";

type Props = {
  children: React.ReactNode;
};

export default function ProfileLayout({ children }: Props) {
  return (
    <div>
      <main role="main bg-white">{children}</main>
    </div>
  );
}
