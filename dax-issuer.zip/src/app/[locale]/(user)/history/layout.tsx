import * as React from "react";

type Props = { children: React.ReactNode };

export default function HistoryLayout({ children }: Props) {
  return (
    <div className="flex min-h-screen bg-white">
      <main
        role="main"
        className="min-w-0 flex-1 overflow-auto"
      >
        <div className="border-border m-10 rounded-sm border bg-white">{children}</div>
      </main>
    </div>
  );
}
