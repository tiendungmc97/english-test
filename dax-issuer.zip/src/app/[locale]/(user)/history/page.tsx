"use client";

import { useRouter } from "@/i18n/navigation";
import { useEffect } from "react";

export default function Withdraw() {
  const router = useRouter();

  useEffect(() => {
    router.replace("/history/fiat");
  }, [router]);

  return (
    <div className="flex min-h-[400px] items-center justify-center">
      <div className="text-center">
        <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-purple-600"></div>
        <p className="text-gray-600">Đang chuyển hướng...</p>
      </div>
    </div>
  );
}
