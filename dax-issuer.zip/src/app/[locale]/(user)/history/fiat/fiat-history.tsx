"use client";

import React, { useState, useEffect, useMemo } from "react";
import { Card, Row, Col, Button, Typography } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import type { ColumnsType } from "antd/es/table";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { useQueryFiatHistory } from "@/services/hooks/use-wallet";
import { AmountDisplay, PriceDisplay } from "@/components/ui/number-component";
import { DateDisplay } from "@/components/ui/date-components";
const { Text, Title } = Typography;

const TRANSACTION_TYPE_MAPPER = {
  deposit: "d",
  withdraw: "w",
  all: undefined,
} as const;

interface WithdrawFilter {
  type: "withdraw" | "deposit" | "all";
  timeRange: [string, string] | null;
  currency?: string | undefined;
  coin?: string | undefined;
  status: string | undefined;
}

interface FiatRecord {
  key: string;
  id: number;
  fundingType: string;
  currencyCd: string;
  amount: number;
  state: string;
  createDate: string;
  acceptDatetime: string | null;
  completedDatetime: string | null;
  writeDate: string;
  method: string;
  fee: number;
  remark: string;
}

interface FiatHistoryProps {
  data?: FiatRecord[];
  isFilter?: boolean;
  defaultType?: string;
}

const CURRENCY_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "VND", label: "VND" },
  { value: "USD", label: "USD" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "new", label: "Ghi nhận" },
  { value: "completed", label: "Thành công" },
  { value: "in-progress", label: "Đang xử lý" },
  { value: "cancel", label: "Đã hủy" },
  { value: "failed", label: "Thất bại" },
];

const columns: ColumnsType<FiatRecord> = [
  {
    title: "Đơn vị tiền tệ",
    dataIndex: "currencyCd",
    key: "currencyCd",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
  {
    title: "Loại giao dịch",
    dataIndex: "fundingType",
    key: "fundingType",
    render: (value: string) => (
      <span
        className={`text-sm ${value === "d" ? "text-green-600" : value === "w" ? "text-red-600" : "text-gray-600"}`}
      >
        {value === "d" ? "Nạp tiền" : value === "w" ? "Rút tiền" : value}
      </span>
    ),
  },
  {
    title: "Khối lượng",
    dataIndex: "amount",
    key: "amount",
    render: (value: number, record: FiatRecord) => (
      <AmountDisplay
        value={value}
        className="text-sm font-medium"
      />
    ),
  },
  {
    title: "Phí",
    dataIndex: "fee",
    key: "fee",
    render: (value: number, record: FiatRecord) => (
      <PriceDisplay
        value={value}
        className="text-sm"
      />
    ),
  },
  {
    title: "Ghi chú",
    dataIndex: "remark",
    key: "remark",
    render: (value: string) => (
      <span className="font-mono text-sm text-gray-600">
        {value ? `${value.slice(0, 8)}...${value.slice(-4)}` : "-"}
      </span>
    ),
  },
  {
    title: "Thời gian",
    dataIndex: "createDate",
    key: "createDate",
    render: (value: string) => (
      <DateDisplay
        date={value}
        className="text-sm text-gray-600"
      />
    ),
  },

  {
    title: "Phương thức",
    dataIndex: "method",
    key: "method",
    render: (value: string) => {
      const methodMap: { [key: string]: string } = {
        bt: "Chuyển khoản ngân hàng",
        cc: "Thẻ",
        it: "Chuyển nội bộ",
        qd: "Nạp nhanh",
      };
      return <span className="text-sm">{methodMap[value] || value}</span>;
    },
  },
  {
    title: "Trạng thái",
    dataIndex: "state",
    key: "state",
    render: (value: string) => {
      const getStatusInfo = (state: string) => {
        switch (state) {
          case "completed":
            return { text: "Thành công", className: "bg-green-50 text-green-700 border-green-200" };
          case "cancel":
            return { text: "Đã hủy", className: "bg-gray-50 text-gray-700 border-gray-200" };
          case "in-progress":
            return { text: "Đang xử lý", className: "bg-yellow-50 text-yellow-700 border-yellow-200" };
          case "new":
            return { text: "Ghi nhận", className: "bg-blue-50 text-blue-700 border-blue-200" };
          case "failed":
          case "error":
            return { text: "Thất bại", className: "bg-red-50 text-red-700 border-red-200" };
          default:
            return { text: state, className: "bg-gray-50 text-gray-700 border-gray-200" };
        }
      };

      const statusInfo = getStatusInfo(value);
      return <span className={`rounded-sm border px-2 py-1 text-sm ${statusInfo.className}`}>{statusInfo.text}</span>;
    },
  },
];

export function FiatHistory({ data, isFilter = true, defaultType }: FiatHistoryProps) {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const methods = useForm<WithdrawFilter>({
    defaultValues: {
      type: (searchParams.get("type") as "withdraw" | "deposit" | "all") || "all",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    },
  });

  const { watch, reset, setValue } = methods;
  const withdrawType = watch("type");

  // Get the current transaction type from form and map to funding type
  const fundingTypeValue = useMemo(() => {
    return TRANSACTION_TYPE_MAPPER[withdrawType as keyof typeof TRANSACTION_TYPE_MAPPER];
  }, [withdrawType]);

  // Memoize query parameters to prevent unnecessary API calls
  const queryParams = useMemo(
    () => ({
      fundingType: defaultType ? defaultType : (fundingTypeValue as any),
      page: pagination.current ? pagination.current - 1 : 0,
      size: pagination.pageSize || 10,
    }),
    [fundingTypeValue, pagination.current, pagination.pageSize, defaultType],
  );

  const {
    data: fiatHistorys,
    isLoading: isFiatHistoryLoading,
    error: fiatHistoryError,
  } = useQueryFiatHistory(queryParams);

  // Set default query parameter when component mounts
  useEffect(() => {
    const urlType = searchParams.get("type");
    if (!urlType) {
      const params = new URLSearchParams(searchParams.toString());
      params.set("type", "all");
      const newUrl = `${pathname}?${params.toString()}`;
      router.replace(newUrl);
    }
  }, []); // Only run once on mount

  // Sync form value with URL parameter
  useEffect(() => {
    const urlType = searchParams.get("type") as "withdraw" | "deposit" | "all";
    if (urlType && urlType !== withdrawType) {
      setValue("type", urlType);
    }
  }, [searchParams, setValue, withdrawType]);

  // Sync pagination with API response
  useEffect(() => {
    if (fiatHistorys?.meta?.totalElements !== undefined) {
      setPagination((prev) => {
        if (prev.total !== fiatHistorys.meta.totalElements) {
          return {
            ...prev,
            total: fiatHistorys.meta.totalElements,
          };
        }
        return prev;
      });
    }
  }, [fiatHistorys?.meta?.totalElements]);

  // Transform data to add key property for table
  const transformedData =
    fiatHistorys?.data?.map((record: FiatRecord) => ({
      ...record,
      key: record.id.toString(),
    })) || [];

  const handleFilter = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      type: "all",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  const handleTypeChange = (value: "withdraw" | "deposit" | "all") => {
    setValue("type", value);
    setValue("currency", undefined);
    setValue("coin", undefined);

    const params = new URLSearchParams(searchParams.toString());
    params.set("type", value);
    const newUrl = `${pathname}?${params.toString()}`;
    router.push(newUrl);
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        {isFilter && (
          <div>
            <Title
              level={4}
              className="!mb-4 font-bold text-gray-900 uppercase dark:text-white"
            >
              Lịch sử Nạp/Rút tiền ký quỹ
            </Title>
            <FormProvider {...methods}>
              <Row
                gutter={[16, 16]}
                className="!items-center"
              >
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="type"
                    label="Loại giao dịch"
                    placeholder="Chọn loại giao dịch"
                    options={[
                      { value: "all", label: "Tất cả" },
                      { value: "deposit", label: "Nạp tiền" },
                      { value: "withdraw", label: "Rút tiền" },
                    ]}
                    onChange={handleTypeChange}
                    className=""
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="currency"
                    label="Đơn vị tiền tệ"
                    placeholder="Chọn tiền tệ"
                    options={CURRENCY_OPTIONS}
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <DateRangePickerField
                    name="timeRange"
                    label="Thời gian"
                    placeholder={["Từ ngày", "Đến ngày"]}
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="status"
                    label="Trạng thái"
                    placeholder="Chọn trạng thái"
                    options={STATUS_OPTIONS}
                  />
                </Col>
                <Col
                  flex="auto"
                  xs={24}
                  className="!flex !justify-end !gap-2"
                >
                  <Button
                    icon={<ReloadOutlined />}
                    onClick={handleReset}
                    className="px-6"
                  >
                    Đặt lại
                  </Button>
                  <Button
                    type="primary"
                    onClick={handleFilter}
                    className="px-6"
                  >
                    Tìm kiếm
                  </Button>
                </Col>
              </Row>
            </FormProvider>
          </div>
        )}
      </Card>

      <Card className="!border-none">
        {fiatHistoryError ? (
          <div className="p-8 text-center text-red-500">Có lỗi xảy ra khi tải dữ liệu. Vui lòng thử lại.</div>
        ) : (
          <CommonTable<FiatRecord>
            columns={columns}
            dataSource={transformedData}
            rowKey="id"
            loading={isFiatHistoryLoading || loading}
            scroll={{ x: 1000 }}
            paginationData={{
              ...pagination,
              total: fiatHistorys?.meta?.totalElements || 0,
              onChange: handlePaginationChange,
            }}
          />
        )}
      </Card>
    </div>
  );
}

export default FiatHistory;
