import FiatHistory from "./fiat-history";

export default function Fiat() {
  return <FiatHistory isFilter={true} />;
}
