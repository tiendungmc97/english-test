"use client";

import React, { useState } from "react";
import { Card, Row, Col, Button } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import type { ColumnsType } from "antd/es/table";

interface TransferFilter {
  from: string | undefined;
  to: string | undefined;
  timeRange: [string, string] | null;
  status: string | undefined;
}

interface TransferRecord {
  key: string;
  id: string;
  from: string;
  to: string;
  amount: string;
  status: string;
  time: string;
  fee: string;
}

const WALLET_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "spot", label: "Ví giao ngay" },
  { value: "funding", label: "Ví cấp vốn" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "success", label: "Thành công" },
  { value: "pending", label: "Đang xử lý" },
  { value: "failed", label: "Thất bại" },
];

const columns: ColumnsType<TransferRecord> = [
  {
    title: "Từ",
    dataIndex: "from",
    key: "from",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Đến",
    dataIndex: "to",
    key: "to",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Số lượng",
    dataIndex: "amount",
    key: "amount",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Trạng thái",
    dataIndex: "status",
    key: "status",
    render: (value: string) => (
      <span
        className={`rounded-full px-2 py-1 text-sm ${
          value === "Thành công"
            ? "bg-green-100 text-green-800"
            : value === "Đang xử lý"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
        }`}
      >
        {value}
      </span>
    ),
  },
  {
    title: "Thời gian",
    dataIndex: "time",
    key: "time",
    render: (value: string) => <span className="text-sm text-gray-600">{value}</span>,
  },
  {
    title: "Phí",
    dataIndex: "fee",
    key: "fee",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
];

// Mock data
const mockData: TransferRecord[] = [
  {
    key: "1",
    id: "1",
    from: "Ví giao ngay",
    to: "Ví cấp vốn",
    amount: "100 FSV",
    status: "Thành công",
    time: "2024-01-15 10:30:00",
    fee: "0 FSV",
  },
  {
    key: "2",
    id: "2",
    from: "Ví cấp vốn",
    to: "Ví giao ngay",
    amount: "50 USDT",
    status: "Đang xử lý",
    time: "2024-01-15 11:15:00",
    fee: "0 USDT",
  },
  {
    key: "3",
    id: "3",
    from: "Ví giao ngay",
    to: "Ví cấp vốn",
    amount: "1,000,000 VND",
    status: "Thành công",
    time: "2024-01-15 12:00:00",
    fee: "0 VND",
  },
];

export function Transfer() {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [loading, setLoading] = useState(false);

  const methods = useForm<TransferFilter>({
    defaultValues: {
      from: undefined,
      to: undefined,
      timeRange: null,
      status: undefined,
    },
  });

  const { watch, reset } = methods;

  const watchedValues = watch();

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      from: undefined,
      to: undefined,
      timeRange: null,
      status: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        <FormProvider {...methods}>
          <Row
            gutter={[16, 16]}
            className="!items-center"
          >
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="from"
                label="Từ"
                placeholder="Chọn ví nguồn"
                options={WALLET_OPTIONS}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="to"
                label="Đến"
                placeholder="Chọn ví đích"
                options={WALLET_OPTIONS}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <DateRangePickerField
                name="timeRange"
                label="Thời gian"
                placeholder={["Từ ngày", "Đến ngày"]}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="status"
                label="Trạng thái"
                placeholder="Chọn trạng thái"
                options={STATUS_OPTIONS}
              />
            </Col>
            <Col
              flex="auto"
              xs={24}
              className="!flex !justify-end !gap-2"
            >
              <Button
                icon={<ReloadOutlined />}
                onClick={handleReset}
              >
                Đặt lại
              </Button>
              <Button
                type="primary"
                onClick={handleFilter}
              >
                Tìm kiếm
              </Button>
            </Col>
          </Row>
        </FormProvider>
      </Card>

      <Card className="!border-none">
        <CommonTable<TransferRecord>
          columns={columns}
          dataSource={mockData}
          rowKey="id"
          loading={loading}
          scroll={{ x: 800 }}
          paginationData={{
            ...pagination,
            total: mockData.length,
            onChange: handlePaginationChange,
          }}
        />
      </Card>
    </div>
  );
}
