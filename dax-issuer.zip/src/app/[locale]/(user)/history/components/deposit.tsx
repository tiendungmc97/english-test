"use client";

import { DateDisplay } from "@/components/ui/date-components";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { SelectField } from "@/components/ui/form/select";
import { AmountDisplay } from "@/components/ui/number-component";
import { useQueryFiatHistory } from "@/services/hooks/use-wallet";
import { ReloadOutlined } from "@ant-design/icons";
import { Button, Card, Col, Row, Tag } from "antd";
import type { ColumnsType } from "antd/es/table";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";

interface DepositFilter {
  type: "fiat" | "crypto";
  timeRange: [string, string] | null;
  currency?: string | undefined;
  coin?: string | undefined;
  status: string | undefined;
}

interface DepositRecord {
  key?: string;
  time: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  status: "success" | "pending" | "failed";
}

const CURRENCY_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "VND", label: "VND" },
  { value: "USD", label: "USD" },
];

const COIN_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "FSV", label: "FSV" },
  { value: "USDT", label: "USDT" },
  { value: "BTC", label: "BTC" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "completed", label: "Hoàn tất" },
  { value: "cancel", label: "Đã hủy" },
  { value: "in-progress", label: "Đang xử lý" },
  { value: "new", label: "Mới" },
];

const FiatMethodText: Record<string, string> = {
  bt: "Chuyển khoản ngân hàng",
  cc: "Thẻ tín dụng/Ghi nợ",
  it: "Chuyển nội bộ",
  qd: "Nạp nhanh",
};
const statusTextMap: Record<string, string> = {
  completed: "Hoàn tất",
  cancel: "Đã hủy",
  "in-progress": "Đang xử lý",
  new: "Mới",
};

const statusColorMap: Record<string, string> = {
  completed: "green",
  cancel: "red",
  "in-progress": "orange",
  new: "blue",
};

function getFiatMethodText(method: string): string {
  return FiatMethodText[method] || method;
}

function getStatusColor(status: string): string {
  return statusColorMap[status] || "default";
}

const columns: ColumnsType<DepositRecord> = [
  { title: "Thời gian", dataIndex: "createDate", render: (value: string) => <DateDisplay date={value} /> },
  {
    title: "Khối lượng",
    dataIndex: "amount",
    render: (a) => <AmountDisplay value={a} />,
  },
  { title: "Đơn vị tiền tệ", dataIndex: "currencyCd" },
  {
    title: "Phương thức thanh toán",
    dataIndex: "method",
    render: (m) => getFiatMethodText(m),
  },
  {
    title: "Trạng thái",
    dataIndex: "state",
    render: (s: string) => <Tag color={getStatusColor(s)}>{statusTextMap[s] || s}</Tag>,
  },
];

export function Deposit() {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [histories, setHistories] = useState([]);
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const { data: fiatHistorys } = useQueryFiatHistory({
    page: 0,
    size: 10,
  });
  const methods = useForm<DepositFilter>({
    defaultValues: {
      type: "fiat",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    },
  });
  const { watch, reset, setValue } = methods;
  const watchedValues = watch();
  const depositType = watch("type");

  useEffect(() => {
    const type = searchParams.get("type");
    if (type && (type === "fiat" || type === "crypto")) {
      setValue("type", type);
    }
  }, [searchParams, setValue]);

  useEffect(() => {
    if (watchedValues && watchedValues.type === "fiat") {
      setHistories(fiatHistorys?.data);
    } else {
      setHistories(fiatHistorys?.data);
    }
  }, [watchedValues]);

  const handleFilter = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      type: "fiat",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  const handleTypeChange = (value: "fiat" | "crypto") => {
    setValue("type", value);
    setValue("currency", undefined);
    setValue("coin", undefined);

    const params = new URLSearchParams(searchParams.toString());
    params.set("type", value);
    const newUrl = `${pathname}?${params.toString()}`;
    router.push(newUrl);
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        <FormProvider {...methods}>
          <Row
            gutter={[16, 16]}
            className="!items-center"
          >
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="type"
                label="Loại nạp tiền"
                placeholder="Chọn loại nạp tiền"
                options={[
                  { value: "fiat", label: "Fiat" },
                  { value: "crypto", label: "Crypto" },
                ]}
                onChange={handleTypeChange}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              {depositType === "fiat" ? (
                <SelectField
                  name="currency"
                  label="Tiền tệ"
                  placeholder="Chọn tiền tệ"
                  options={CURRENCY_OPTIONS}
                />
              ) : (
                <SelectField
                  name="coin"
                  label="Coin"
                  placeholder="Chọn coin"
                  options={COIN_OPTIONS}
                />
              )}
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <DateRangePickerField
                name="timeRange"
                label="Thời gian"
                placeholder={["Từ ngày", "Đến ngày"]}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="status"
                label="Trạng thái"
                placeholder="Chọn trạng thái"
                options={STATUS_OPTIONS}
              />
            </Col>
            <Col
              flex="auto"
              xs={24}
              className="!flex !justify-end !gap-2"
            >
              <Button
                icon={<ReloadOutlined />}
                onClick={handleReset}
                className="px-6"
              >
                Đặt lại
              </Button>
              <Button
                type="primary"
                onClick={handleFilter}
                className="px-6"
              >
                Tìm kiếm
              </Button>
            </Col>
          </Row>
        </FormProvider>
      </Card>

      <Card className="!border-none">
        <CommonTable<DepositRecord>
          columns={columns}
          dataSource={fiatHistorys}
          rowKey={(r) => r.time}
          loading={loading}
          scroll={{ x: 800 }}
          paginationData={{
            ...pagination,
            total: fiatHistorys?.length,
            onChange: handlePaginationChange,
          }}
        />
      </Card>
    </div>
  );
}
