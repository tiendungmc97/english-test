"use client";

import React, { useState } from "react";
import { Card, Row, Col, Button } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import type { ColumnsType } from "antd/es/table";
import { AmountDisplay, PriceDisplay } from "@/components/ui/number-component";
import { DateDisplay } from "@/components/ui/date-components";

interface OverviewFilter {
  timeRange: [string, string] | null;
  coin: string | undefined;
}

interface OverviewRecord {
  key: string;
  id: string;
  type: string;
  coin: string;
  amount: string;
  status: string;
  time: string;
  fee: string;
}

const COIN_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "FSV", label: "FSV" },
  { value: "VND", label: "VND" },
  { value: "USDT", label: "USDT" },
  { value: "BTC", label: "BTC" },
];

const columns: ColumnsType<OverviewRecord> = [
  {
    title: "Loại",
    dataIndex: "type",
    key: "type",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Coin",
    dataIndex: "coin",
    key: "coin",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
  {
    title: "Số lượng",
    dataIndex: "amount",
    key: "amount",
    render: (value: string) => (
      <span className="text-sm font-medium">
        <AmountDisplay value={value} />
      </span>
    ),
  },
  {
    title: "Trạng thái",
    dataIndex: "status",
    key: "status",
    render: (value: string) => (
      <span
        className={`rounded-full px-2 py-1 text-sm ${
          value === "Thành công"
            ? "bg-green-100 text-green-800"
            : value === "Đang xử lý"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
        }`}
      >
        {value}
      </span>
    ),
  },
  {
    title: "Thời gian",
    dataIndex: "time",
    key: "time",
    render: (value: string) => (
      <span className="text-sm text-gray-600">
        <DateDisplay date={value} />
      </span>
    ),
  },
  {
    title: "Phí",
    dataIndex: "fee",
    key: "fee",
    render: (value: string, record: OverviewRecord) => {
      return (
        <span className="text-sm">
          <PriceDisplay
            value={value}
            suffix={record.coin}
          />
        </span>
      );
    },
  },
];

// Mock data
const mockData: OverviewRecord[] = [
  {
    key: "1",
    id: "1",
    type: "Nạp tiền",
    coin: "VND",
    amount: "1,000,000 VND",
    status: "Thành công",
    time: "2024-01-15 10:30:00",
    fee: "0",
  },
  {
    key: "2",
    id: "2",
    type: "Rút tiền",
    coin: "FSV",
    amount: "100 FSV",
    status: "Đang xử lý",
    time: "2024-01-15 11:15:00",
    fee: "0.1",
  },
  {
    key: "3",
    id: "3",
    type: "Chuyển khoản",
    coin: "USDT",
    amount: "50 USDT",
    status: "Thành công",
    time: "2024-01-15 12:00:00",
    fee: "0.5",
  },
];

export function Overview() {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [loading, setLoading] = useState(false);

  const methods = useForm<OverviewFilter>({
    defaultValues: {
      timeRange: null,
      coin: undefined,
    },
  });

  const { watch, reset } = methods;

  const watchedValues = watch();

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      timeRange: null,
      coin: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        <FormProvider {...methods}>
          <Row
            gutter={[16, 16]}
            className="!items-center"
          >
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="coin"
                label="Tiền mã hoá"
                placeholder="Chọn coin"
                options={COIN_OPTIONS}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <DateRangePickerField
                name="timeRange"
                label="Ngày"
                placeholder={["Từ ngày", "Đến ngày"]}
              />
            </Col>
            <Col
              flex="auto"
              xs={24}
              className="!flex !justify-end !gap-2"
            >
              <Button
                type="primary"
                onClick={handleFilter}
              >
                Tìm kiếm
              </Button>
            </Col>
          </Row>
        </FormProvider>
      </Card>

      <Card className="!border-none">
        <CommonTable<OverviewRecord>
          columns={columns}
          dataSource={mockData}
          rowKey="id"
          loading={loading}
          scroll={{ x: 800 }}
          paginationData={{
            ...pagination,
            total: mockData.length,
            onChange: handlePaginationChange,
          }}
        />
      </Card>
    </div>
  );
}
