"use client";

import React, { useState, useEffect } from "react";
import { Card, Row, Col, Button } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import type { ColumnsType } from "antd/es/table";
import { useSearchParams, useRouter, usePathname } from "next/navigation";

interface WithdrawFilter {
  type: "fiat" | "crypto";
  timeRange: [string, string] | null;
  currency?: string | undefined;
  coin?: string | undefined;
  status: string | undefined;
}

interface WithdrawRecord {
  key: string;
  id: string;
  type: string;
  currency: string;
  amount: string;
  status: string;
  time: string;
  method: string;
  fee: string;
  address?: string;
}

const CURRENCY_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "VND", label: "VND" },
  { value: "USD", label: "USD" },
];

const COIN_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "FSV", label: "FSV" },
  { value: "USDT", label: "USDT" },
  { value: "BTC", label: "BTC" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "success", label: "Thành công" },
  { value: "pending", label: "Đang xử lý" },
  { value: "failed", label: "Thất bại" },
];

const columns: ColumnsType<WithdrawRecord> = [
  {
    title: "Loại",
    dataIndex: "type",
    key: "type",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Tiền tệ",
    dataIndex: "currency",
    key: "currency",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
  {
    title: "Số lượng",
    dataIndex: "amount",
    key: "amount",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Trạng thái",
    dataIndex: "status",
    key: "status",
    render: (value: string) => (
      <span
        className={`rounded-full px-2 py-1 text-sm ${
          value === "Thành công"
            ? "bg-green-100 text-green-800"
            : value === "Đang xử lý"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
        }`}
      >
        {value}
      </span>
    ),
  },
  {
    title: "Phương thức",
    dataIndex: "method",
    key: "method",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
  {
    title: "Địa chỉ",
    dataIndex: "address",
    key: "address",
    render: (value: string) => (
      <span className="font-mono text-sm text-gray-600">
        {value ? `${value.slice(0, 6)}...${value.slice(-4)}` : "-"}
      </span>
    ),
  },
  {
    title: "Thời gian",
    dataIndex: "time",
    key: "time",
    render: (value: string) => <span className="text-sm text-gray-600">{value}</span>,
  },
  {
    title: "Phí",
    dataIndex: "fee",
    key: "fee",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
];

// Mock data
const mockData: WithdrawRecord[] = [
  {
    key: "1",
    id: "1",
    type: "Fiat",
    currency: "VND",
    amount: "500,000 VND",
    status: "Thành công",
    time: "2024-01-15 10:30:00",
    method: "Chuyển khoản ngân hàng",
    fee: "5,000 VND",
  },
  {
    key: "2",
    id: "2",
    type: "Crypto",
    currency: "FSV",
    amount: "50 FSV",
    status: "Đang xử lý",
    time: "2024-01-15 11:15:00",
    method: "Blockchain",
    address: "0x1234567890abcdef1234567890abcdef12345678",
    fee: "0.05 FSV",
  },
];

export function Withdraw() {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const methods = useForm<WithdrawFilter>({
    defaultValues: {
      type: "fiat",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    },
  });

  const { watch, reset, setValue } = methods;

  // Handle query parameters
  useEffect(() => {
    const type = searchParams.get("type");
    if (type && (type === "fiat" || type === "crypto")) {
      setValue("type", type);
    }
  }, [searchParams, setValue]);

  const watchedValues = watch();
  const withdrawType = watch("type");

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      type: "fiat",
      timeRange: null,
      currency: undefined,
      coin: undefined,
      status: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  const handleTypeChange = (value: "fiat" | "crypto") => {
    setValue("type", value);
    setValue("currency", undefined);
    setValue("coin", undefined);

    // Update URL with new type parameter
    const params = new URLSearchParams(searchParams.toString());
    params.set("type", value);
    const newUrl = `${pathname}?${params.toString()}`;
    router.push(newUrl);
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        <FormProvider {...methods}>
          <Row
            gutter={[16, 16]}
            className="!items-center"
          >
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="type"
                label="Loại rút tiền"
                placeholder="Chọn loại rút tiền"
                options={[
                  { value: "fiat", label: "Fiat" },
                  { value: "crypto", label: "Crypto" },
                ]}
                onChange={handleTypeChange}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              {withdrawType === "fiat" ? (
                <SelectField
                  name="currency"
                  label="Tiền tệ"
                  placeholder="Chọn tiền tệ"
                  options={CURRENCY_OPTIONS}
                />
              ) : (
                <SelectField
                  name="coin"
                  label="Coin"
                  placeholder="Chọn coin"
                  options={COIN_OPTIONS}
                />
              )}
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <DateRangePickerField
                name="timeRange"
                label="Thời gian"
                placeholder={["Từ ngày", "Đến ngày"]}
              />
            </Col>
            <Col
              flex="220px"
              xs={24}
            >
              <SelectField
                name="status"
                label="Trạng thái"
                placeholder="Chọn trạng thái"
                options={STATUS_OPTIONS}
              />
            </Col>
            <Col
              flex="auto"
              xs={24}
              className="!flex !justify-end !gap-2"
            >
              <Button
                icon={<ReloadOutlined />}
                onClick={handleReset}
                className="px-6"
              >
                Đặt lại
              </Button>
              <Button
                type="primary"
                onClick={handleFilter}
                className="px-6"
              >
                Tìm kiếm
              </Button>
            </Col>
          </Row>
        </FormProvider>
      </Card>

      <Card className="!border-none">
        <CommonTable<WithdrawRecord>
          columns={columns}
          dataSource={mockData}
          rowKey="id"
          loading={loading}
          scroll={{ x: 1000 }}
          paginationData={{
            ...pagination,
            total: mockData.length,
            onChange: handlePaginationChange,
          }}
        />
      </Card>
    </div>
  );
}
