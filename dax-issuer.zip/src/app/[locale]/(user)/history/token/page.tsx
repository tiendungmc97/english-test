import TokenHistory from "./token-history";

export default function Token() {
  return <TokenHistory isFilter={true} />;
}
