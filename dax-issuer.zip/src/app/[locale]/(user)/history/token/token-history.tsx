"use client";

import React, { useState, useEffect } from "react";
import { Card, Row, Col, Button, Typography } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CommonTable, INIT_PAGINATION } from "@/components/ui/form/common-table";
import type { ColumnsType } from "antd/es/table";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { DateDisplay } from "@/components/ui/date-components";
const { Text, Title } = Typography;

interface TokenFilter {
  token: "all" | string;
  timeRange: [string, string] | null;
  status: string | undefined;
}

interface TokenRecord {
  key: string;
  id: string;
  type: string;
  token: string;
  amount: string;
  status: string;
  time: string;
  method: string;
  fee: string;
  address?: string;
}

interface TokenHistoryProps {
  data?: TokenRecord[];
  isFilter?: boolean;
  defaultType?: string;
}

const TOKEN_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "FSV", label: "FSV" },
  { value: "USDT", label: "USDT" },
  { value: "BTC", label: "BTC" },
  { value: "ETH", label: "ETH" },
  { value: "BNB", label: "BNB" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Tất cả" },
  { value: "success", label: "Thành công" },
  { value: "pending", label: "Đang xử lý" },
  { value: "failed", label: "Thất bại" },
];

const columns: ColumnsType<TokenRecord> = [
  {
    title: "Tài sản",
    dataIndex: "token",
    key: "token",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Loại giao dịch",
    dataIndex: "type",
    key: "type",
    render: (value: string) => (
      <span
        className={`text-sm ${
          value === "Nạp tiền" ? "text-green-600" : value === "Rút tiền" ? "text-red-600" : "text-gray-600"
        }`}
      >
        {value}
      </span>
    ),
  },
  {
    title: "Số lượng",
    dataIndex: "amount",
    key: "amount",
    render: (value: string) => <span className="text-sm font-medium">{value}</span>,
  },
  {
    title: "Địa chỉ",
    dataIndex: "address",
    key: "address",
    render: (value: string) => (
      <span className="font-mono text-sm text-gray-600">
        {value ? `${value.slice(0, 6)}...${value.slice(-4)}` : "-"}
      </span>
    ),
  },
  {
    title: "TxID",
    dataIndex: "method",
    key: "method",
    render: (value: string) => <a className="text-sm">{value}</a>,
  },
  {
    title: "Thời gian",
    dataIndex: "time",
    key: "time",
    render: (value: string) => (
      <DateDisplay
        date={value}
        className="text-sm text-gray-600"
      />
    ),
  },
  {
    title: "Phí",
    dataIndex: "fee",
    key: "fee",
    render: (value: string) => <span className="text-sm">{value}</span>,
  },
  {
    title: "Trạng thái",
    dataIndex: "status",
    key: "status",
    render: (value: string) => {
      const getStatusInfo = (status: string) => {
        switch (status) {
          case "Thành công":
            return { text: "Thành công", className: "bg-green-50 text-green-700 border-green-200" };
          case "Đang xử lý":
            return { text: "Đang xử lý", className: "bg-yellow-50 text-yellow-700 border-yellow-200" };
          case "Thất bại":
            return { text: "Thất bại", className: "bg-red-50 text-red-700 border-red-200" };
          default:
            return { text: status, className: "bg-gray-50 text-gray-700 border-gray-200" };
        }
      };

      const statusInfo = getStatusInfo(value);
      return <span className={`rounded-sm border px-2 py-1 text-sm ${statusInfo.className}`}>{statusInfo.text}</span>;
    },
  },
];

export function TokenHistory({ data, isFilter = true, defaultType }: TokenHistoryProps) {
  const [pagination, setPagination] = useState(INIT_PAGINATION);
  const [loading, setLoading] = useState(false);
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const methods = useForm<TokenFilter>({
    defaultValues: {
      token: (searchParams.get("token") as "all" | string) || "all",
      timeRange: null,
      status: undefined,
    },
  });

  const { watch, reset, setValue } = methods;
  const watchedValues = watch();
  const selectedToken = watch("token");

  // Set default query parameter when component mounts
  useEffect(() => {
    const currentToken = searchParams.get("token");
    if (!currentToken) {
      const params = new URLSearchParams(searchParams.toString());
      params.set("token", "all");
      const newUrl = `${pathname}?${params.toString()}`;
      router.replace(newUrl);
    }
  }, [searchParams, pathname, router]);

  // Sync form value with URL parameter
  useEffect(() => {
    const urlToken = searchParams.get("token") as "all" | string;
    if (urlToken && urlToken !== selectedToken) {
      setValue("token", urlToken);
    }
  }, [searchParams, setValue, selectedToken]);

  const handleFilter = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  const handleReset = () => {
    reset({
      token: defaultType ? defaultType : "all",
      timeRange: null,
      status: undefined,
    });
    setPagination(INIT_PAGINATION);
  };

  const handlePaginationChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({
      ...prev,
      current,
      pageSize,
    }));
  };

  const handleTypeChange = (value: "withdraw" | "deposit" | "all") => {
    // setValue("type", value);
    // setValue("currency", undefined);
    // setValue("coin", undefined);

    const params = new URLSearchParams(searchParams.toString());
    params.set("type", value);
    const newUrl = `${pathname}?${params.toString()}`;
    router.push(newUrl);
  };

  const handleTokenChange = (value: "all" | string) => {
    setValue("token", value);

    // Update URL with new token parameter
    const params = new URLSearchParams(searchParams.toString());
    params.set("token", value);
    const newUrl = `${pathname}?${params.toString()}`;
    router.push(newUrl);
  };

  return (
    <div className="space-y-6">
      <Card className="!border-none">
        {isFilter && (
          <div>
            <Title
              level={4}
              className="!mb-4 font-bold text-gray-900 uppercase dark:text-white"
            >
              Lịch sử Nạp/Rút tài sản
            </Title>
            <FormProvider {...methods}>
              <Row
                gutter={[16, 16]}
                className="!items-center"
              >
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="type"
                    label="Loại giao dịch"
                    placeholder="Chọn loại giao dịch"
                    options={[
                      { value: "all", label: "Tất cả" },
                      { value: "deposit", label: "Nạp tiền" },
                      { value: "withdraw", label: "Rút tiền" },
                    ]}
                    onChange={handleTypeChange}
                    className=""
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="token"
                    label="Tên tài sản"
                    placeholder="Chọn tiền mã hoá"
                    options={TOKEN_OPTIONS}
                    onChange={handleTokenChange}
                    className=""
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <DateRangePickerField
                    name="timeRange"
                    label="Thời gian"
                    placeholder={["Từ ngày", "Đến ngày"]}
                  />
                </Col>
                <Col
                  flex="220px"
                  xs={24}
                >
                  <SelectField
                    name="status"
                    label="Trạng thái"
                    placeholder="Chọn trạng thái"
                    options={STATUS_OPTIONS}
                  />
                </Col>
                <Col
                  flex="auto"
                  xs={24}
                  className="!flex !justify-end !gap-2"
                >
                  <Button
                    icon={<ReloadOutlined />}
                    onClick={handleReset}
                    className="px-6"
                  >
                    Đặt lại
                  </Button>
                  <Button
                    type="primary"
                    onClick={handleFilter}
                    className="px-6"
                  >
                    Tìm kiếm
                  </Button>
                </Col>
              </Row>
            </FormProvider>
          </div>
        )}
      </Card>

      <Card className="!border-none">
        <CommonTable<TokenRecord>
          columns={columns}
          dataSource={data}
          rowKey="id"
          loading={loading}
          scroll={{ x: 1000 }}
          paginationData={{
            ...pagination,
            total: data?.length,
            onChange: handlePaginationChange,
          }}
        />
      </Card>
    </div>
  );
}

export default TokenHistory;
