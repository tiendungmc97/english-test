"use client";

import { Button, Card, Form, Select, Tabs, Typography } from "antd";
import { useState } from "react";

const { Text, Title } = Typography;
import { OrderTypeMap, SideMap } from "@/assets/proto/trading_model_pb";

export interface OrderFormData {
  orderType: "LIMIT" | "MARKET";
  side: "buy" | "sell";
  symbol: string;
  livingPlan: string;
  gramFee: string;
  price?: string;
}

export interface OrderPanelProps {
  onSubmitOrder?: (orderData: OrderFormData) => void;
  isLoading?: boolean;
  availableBalance?: string;
  currentSymbol?: string;
  currentPrice?: string;
}
export interface SymbolData {
  code: string;
  name: string;
  currentPrice: string;
}
export function OrderPanel({
  onSubmitOrder,
  isLoading = false,
  availableBalance = "144,124.56",
  currentSymbol = "VND",
  currentPrice = "23,591",
}: OrderPanelProps) {
  const [form] = Form.useForm();
  const [orderType, setOrderType] = useState<"LIMIT" | "MARKET">("LIMIT");

  const handleSubmit = async (values: any) => {};

  const tabItems = [
    {
      key: "LIMIT",
      label: (
        <div className="flex min-w-[80px] items-center justify-center px-6 py-1">
          <span>LIMIT</span>
        </div>
      ),
      children: null,
    },
    {
      key: "MARKET",
      label: (
        <div className="flex min-w-[80px] items-center justify-center px-6 py-1">
          <span>MARKET</span>
        </div>
      ),
      children: null,
    },
  ];

  return (
    <Card>
      <div className="h-full w-full bg-white">
        <div className="mb-0">
          <Title
            level={4}
            className="font-bold text-gray-900 uppercase dark:text-white"
          >
            Order
          </Title>

          <Tabs
            activeKey={orderType}
            onChange={(key) => setOrderType(key as "LIMIT" | "MARKET")}
            items={tabItems}
            centered
            className="order-panel-tabs"
            size="small"
          />
        </div>

        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          className="space-y-4"
        >
          <div className="space-y-2 rounded-lg p-2">
            <div className="mb-4 flex h-64 w-full items-center justify-center rounded-lg bg-gray-200">
              <p>Input Order </p>
            </div>
            <div className="flex items-center justify-between">
              <Text className="text-xs text-gray-500 dark:text-gray-400">Token khả dụng</Text>
              <Text className="text-xs font-medium text-gray-900 dark:text-white">{availableBalance} FSV</Text>
            </div>
            <div className="flex items-center justify-between">
              <Text className="text-xs text-gray-500 dark:text-gray-400">Số tiền đặt cược</Text>
              <Text className="text-xs font-medium text-gray-900 dark:text-white">100,000 VND</Text>
            </div>
            <div className="flex items-center justify-between">
              <Text className="text-xs text-gray-500 dark:text-gray-400">Số tiền đặt cược</Text>
              <Text className="text-xs font-medium text-gray-900 dark:text-white">100,000 VND</Text>
            </div>
          </div>

          <div className="flex space-x-2">
            <Button
              type="primary"
              color="danger"
              className="w-full !bg-red-600 hover:opacity-70"
              loading={isLoading}
            >
              BÁN
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="w-full !bg-green-600 hover:opacity-70"
              loading={isLoading}
            >
              MUA
            </Button>
          </div>
        </Form>
      </div>
    </Card>
  );
}
