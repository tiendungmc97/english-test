import { useState, useEffect, useCallback, useRef } from "react";
import { OrderBookData, OrderBookEntry } from ".";

interface UseOrderBookProps {
  symbolCode: string;
  precision: number;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

export const useOrderBook = ({
  symbolCode,
  precision,
  autoRefresh = true,
  refreshInterval = 2000,
}: UseOrderBookProps) => {
  const [data, setData] = useState<OrderBookData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const generateMockData = useCallback((): OrderBookData => {
    const basePrice = 85650;
    const spread = 0.5;

    const generateEntries = (side: "ask" | "bid", count: number): OrderBookEntry[] => {
      const entries: OrderBookEntry[] = [];
      const isAsk = side === "ask";

      for (let i = 0; i < count; i++) {
        const priceOffset = (i + 1) * precision;
        const price = isAsk ? basePrice + spread / 2 + priceOffset : basePrice - spread / 2 - priceOffset;
        const volume = Math.floor(Math.random() * 20 + 1);
        const total = price * volume;

        entries.push({
          price: price.toFixed(getPrecisionDecimals(precision)),
          volume: volume.toString(),
          total: total.toFixed(2),
          orders: Math.floor(Math.random() * 5 + 1),
        });
      }

      return isAsk ? entries.reverse() : entries;
    };

    return {
      asks: generateEntries("ask", 25),
      bids: generateEntries("bid", 25),
      spread: spread.toFixed(getPrecisionDecimals(precision)),
      spreadPercent: ((spread / basePrice) * 100).toFixed(3) + "%",
      lastUpdate: Date.now(),
    };
  }, [precision]);

  const getPrecisionDecimals = (prec: number): number => {
    if (prec >= 1) return 0;
    if (prec >= 0.1) return 1;
    if (prec >= 0.01) return 2;
    if (prec >= 0.001) return 3;
    return 4;
  };

  // Use ref to store the latest generateMockData function to avoid stale closures
  const generateMockDataRef = useRef(generateMockData);
  generateMockDataRef.current = generateMockData;

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      // In a real implementation, this would be an API call or WebSocket connection
      // For now, we'll simulate with a timeout
      await new Promise((resolve) => setTimeout(resolve, 300));

      const newData = generateMockDataRef.current();
      setData(newData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch order book data");
    } finally {
      setLoading(false);
    }
  }, []); // No dependencies to avoid infinite loops

  const refresh = useCallback(() => {
    fetchData();
  }, [fetchData]);

  // Initial fetch
  useEffect(() => {
    fetchData();
  }, [symbolCode, precision, fetchData]); // Include fetchData but it's stable now

  // Auto refresh
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      if (!loading) {
        // Generate new data using ref to avoid stale closures
        const newData = generateMockDataRef.current();
        setData(newData);
      }
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, loading]); // Remove precision dependency

  return {
    data,
    loading,
    error,
    refresh,
  };
};
