"use client";

import { InfoCircleOutlined } from "@ant-design/icons";
import { App, Button, Card, Table, Typography } from "antd";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import type { ColumnsType } from "antd/es/table";
import { useMemo, useState } from "react";
import { useOrderBook } from "./useOrderBook";
const { Text, Title } = Typography;
export interface OrderBookEntry {
  price: string;
  volume: string;
  total: string;
  orders?: number;
  percentage?: number;
}

export interface OrderBookData {
  asks: OrderBookEntry[];
  bids: OrderBookEntry[];
  spread: string;
  spreadPercent: string;
  lastUpdate?: number;
}

export interface OrderBookProps {
  symbolCode?: string;
  maxDepth?: number;
  precision?: number;
  onOrderClick?: (order: OrderBookEntry, side: "bid" | "ask") => void;
  showDepthChart?: boolean;
  showOrderCount?: boolean;
}

export type PrecisionLevel = 0.1 | 0.01 | 0.001 | 0.0001;

export interface OrderBookSettings {
  precision: PrecisionLevel;
  maxRows: number;
  autoRefresh: boolean;
}

export function OrderBook({ symbolCode = "BTC/USDT", onOrderClick }: OrderBookProps) {
  // Use message directly from antd
  const { message } = App.useApp();

  const [settings, setSettings] = useState<OrderBookSettings>({
    precision: 0.01,
    maxRows: 10,
    autoRefresh: true,
  });

  const {
    data: orderBookData,
    loading,
    error,
    refresh,
  } = useOrderBook({
    symbolCode,
    precision: settings.precision,
    autoRefresh: settings.autoRefresh,
    refreshInterval: 2000,
  });

  // Calculate cumulative volumes for depth visualization
  const processedData = useMemo(() => {
    if (!orderBookData) return null;

    const processEntries = (entries: OrderBookEntry[]) => {
      let cumulative = 0;
      const maxVolume = Math.max(...entries.map((e) => parseFloat(e.volume)));

      return entries.slice(0, settings.maxRows).map((entry) => {
        cumulative += parseFloat(entry.volume);
        return {
          ...entry,
          cumulative: cumulative.toString(),
          percentage: maxVolume > 0 ? (parseFloat(entry.volume) / maxVolume) * 100 : 0,
        };
      });
    };

    return {
      ...orderBookData,
      asks: processEntries(orderBookData.asks),
      bids: processEntries(orderBookData.bids),
    };
  }, [orderBookData, settings.maxRows]);

  const getPrecisionDecimals = (prec: PrecisionLevel): number => {
    switch (prec) {
      case 0.1:
        return 1;
      case 0.01:
        return 2;
      case 0.001:
        return 3;
      case 0.0001:
        return 4;
      default:
        return 2;
    }
  };

  const formatNumber = (value: string, decimals?: number) => {
    const num = parseFloat(value);
    return num.toFixed(decimals ?? getPrecisionDecimals(settings.precision));
  };

  const handleOrderClick = (order: OrderBookEntry, side: "bid" | "ask") => {
    onOrderClick?.(order, side);
    message.info(`Clicked ${side} order at price ${order.price}`);
  };

  const buildColumns = (side: "ask" | "bid"): ColumnsType<OrderBookEntry & { percentage?: number }> => {
    const isAsk = side === "ask";
    const columns: ColumnsType<OrderBookEntry & { percentage?: number }> = [];

    // Price column
    columns.push({
      title: "Price(VND)",
      dataIndex: "price",
      key: "price",
      align: "start",
      render: (value, record) => (
        <Text
          className={`!cursor-pointer !text-start !text-xs !font-bold !transition-colors ${
            isAsk ? "!hover:text-red-600 !text-red-500" : "!text-green-500 hover:!text-green-600"
          }`}
          onClick={() => handleOrderClick(record, side)}
        >
          {formatNumber(value)}
        </Text>
      ),
    });

    // Volume column - second for both asks and bids
    columns.push({
      title: "Volume(FSV)",
      dataIndex: "volume",
      key: "volume",
      align: "center",
      width: "25%",
      render: (value, record) => (
        <div className="relative">
          {record.percentage && (
            <div
              className={`absolute top-0 ${isAsk ? "right-0 bg-red-100" : "left-0 bg-green-100"} h-full opacity-30 w-[${record.percentage}%]`}
            />
          )}
          <Text className="!relative !z-10 !text-xs !font-medium !text-gray-600">{formatNumber(value, 0)}</Text>
        </div>
      ),
    });

    // Total column - third for both asks and bids
    columns.push({
      title: "Total",
      dataIndex: "total",
      key: "total",
      align: "center",
      width: "35%",
      render: (value) => <Text className="!text-xs !text-gray-500">{formatNumber(value)}</Text>,
      onCell: () => ({ style: { whiteSpace: "nowrap", wordBreak: "keep-all" } }),
    });

    return columns;
  };

  if (error) {
    return (
      <Card className="h-full w-full">
        <div className="flex h-96 flex-col items-center justify-center text-center">
          <InfoCircleOutlined className="mb-4 text-4xl text-red-500" />
          <Text className="mb-4 text-red-500">Failed to load order book</Text>
          <Button
            type="primary"
            onClick={refresh}
          >
            Retry
          </Button>
        </div>
      </Card>
    );
  }

  if (loading && !orderBookData) {
    return (
      <Card className="h-full w-full">
        <div className="flex h-96 items-center justify-center">
          <LoadingSpinner text="Đang tải lịch sử..." />
        </div>
      </Card>
    );
  }

  return (
    <Card className="h-full w-full">
      <div className="flex h-full flex-col">
        <div className="flex-1 overflow-hidden">
          <Title
            level={4}
            className="font-bold text-gray-900 uppercase dark:text-white"
          >
            Order book
          </Title>
          {/* Asks (Sell Orders) */}
          <div className="p-3">
            <Table
              key="ask-table"
              columns={buildColumns("ask")}
              dataSource={processedData?.asks}
              pagination={false}
              size="small"
              rowKey={(record) => `ask-${record.price}-${record.volume}`}
              className="order-book-table"
              rowClassName="hover:bg-red-50 cursor-pointer transition-colors"
              loading={loading}
            />
          </div>

          {/* Spread */}
          <div className="p-3">
            <div className="flex items-center justify-between">
              <Text className="text-sm font-extrabold !text-red-600">85650.39</Text>
              <Text className="ml-2 text-xs text-gray-500">
                <span className="pe-1 text-xs font-semibold text-gray-400">VND</span>
                <span>85650.39</span>
              </Text>
            </div>
          </div>

          {/* Bids (Buy Orders) */}
          <div className="p-3">
            <Table
              key="bid-table"
              columns={buildColumns("bid")}
              dataSource={processedData?.bids}
              pagination={false}
              size="small"
              rowKey={(record) => `bid-${record.price}-${record.volume}`}
              className="order-book-table"
              rowClassName="hover:bg-green-50 cursor-pointer transition-colors"
              loading={loading}
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
