import { Card } from "antd";

export function Chart() {
  return (
    <Card className="!flex !h-full !w-full !items-center !justify-center !bg-gray-200">
      <p>View your trading chart here.</p>
    </Card>
  );
}
