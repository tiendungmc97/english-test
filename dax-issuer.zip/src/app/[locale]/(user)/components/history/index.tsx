import { Tabs, Badge, Card } from "antd";
import { useTranslations } from "next-intl";
import { PendingOrderHistory } from "./pending-order";
import { OrderHistory } from "./order";
import { TransactionHistory } from "./transaction";

export function History() {
  const t = useTranslations("HistoryPage");
  const numberPendingOrders = 5;

  const items = [
    {
      key: "pending-orders",
      label:
        numberPendingOrders > 0 ? (
          <Badge
            count={numberPendingOrders}
            size="default"
            offset={[10, 0]}
          >
            <span>{t("pendingOrders")}</span>
          </Badge>
        ) : (
          t("pendingOrders")
        ),
      children: <PendingOrderHistory />,
    },
    {
      key: "order-history",
      label: t("orderHistory"),
      children: <OrderHistory />,
    },
    {
      key: "transaction-history",
      label: t("transactionHistory"),
      children: <TransactionHistory />,
    },
  ];

  return (
    <Card className="h-full w-full">
      <Tabs
        defaultActiveKey="pending-orders"
        items={items}
        className="w-full"
        tabBarStyle={{
          marginBottom: 16,
          paddingLeft: 16,
          paddingRight: 16,
        }}
      />
    </Card>
  );
}
