"use client";

import { Button, Form, Row, Col, Select, DatePicker, Space } from "antd";
import { ColumnsType } from "antd/es/table";
import { useTranslations } from "next-intl";
import { useState, useCallback } from "react";
import { useForm, FormProvider } from "react-hook-form";
import dayjs from "dayjs";
import { CommonTable, INIT_PAGINATION, IPagination } from "@/components/ui/form/common-table";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { DateDisplay } from "@/components/ui/date-components";
import { AmountDisplay, PriceDisplay } from "@/components/ui/number-component";

interface TransactionRecord {
  key?: string;
  id: string;
  tradingPair: string;
  orderSide: "buy" | "sell";
  price: number;
  executedQuantity: number;
  tradingFee: number;
  role: "maker" | "taker";
  total: number;
  executionTime: string;
}

interface FilterForm {
  tradingPair: string;
  orderSide: string;
  dateRange: [string, string] | null;
}

export function TransactionHistory() {
  const t = useTranslations("HistoryPage");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<TransactionRecord[]>([]);
  const [pagination, setPagination] = useState<IPagination>(INIT_PAGINATION);

  const methods = useForm<FilterForm>({
    defaultValues: {
      tradingPair: "all",
      orderSide: "all",
      dateRange: null,
    },
  });

  // Mock data - replace with actual API call
  const mockData: TransactionRecord[] = [
    {
      id: "1",
      tradingPair: "XAG/VND",
      orderSide: "buy",
      price: 17987,
      executedQuantity: 8.479,
      tradingFee: 0.0000001,
      role: "maker",
      total: 10000,
      executionTime: "2025-01-31T15:44:23",
    },
    {
      id: "2",
      tradingPair: "XAG/VND",
      orderSide: "sell",
      price: 10000,
      executedQuantity: 8.48,
      tradingFee: 0.0000001,
      role: "maker",
      total: 10000,
      executionTime: "2025-01-31T15:57:04",
    },
    {
      id: "3",
      tradingPair: "PNJ/VND",
      orderSide: "sell",
      price: 10001,
      executedQuantity: 8.481,
      tradingFee: 0.0000001,
      role: "maker",
      total: 10000,
      executionTime: "2025-01-31T15:57:05",
    },
  ];

  const columns: ColumnsType<TransactionRecord> = [
    {
      title: <span className="font-semibold text-gray-500">{t("tradingPair")}</span>,
      dataIndex: "tradingPair",
      key: "tradingPair",
      width: 120,
    },
    {
      title: <span className="font-semibold text-gray-500">{t("orderSide")}</span>,
      dataIndex: "orderSide",
      key: "orderSide",
      width: 100,
      render: (value: "buy" | "sell") => (
        <span className={value === "buy" ? "text-green-600" : "text-red-600"}>{t(value)}</span>
      ),
    },
    {
      title: <span className="font-semibold text-gray-500">{t("price")}</span>,
      dataIndex: "price",
      key: "price",
      width: 120,
      align: "right",
      render: (value: number) => <PriceDisplay value={value} />,
    },
    {
      title: <span className="font-semibold text-gray-500">{t("executedQuantity")}</span>,
      dataIndex: "executedQuantity",
      key: "executedQuantity",
      width: 150,
      align: "right",
      render: (value: number) => (
        <AmountDisplay
          value={value}
          token="XAG"
          invalidText="-"
          decimalScale={4}
        />
      ),
    },
    {
      title: <span className="font-semibold text-gray-500">{t("tradingFee")}</span>,
      dataIndex: "tradingFee",
      key: "tradingFee",
      width: 150,
      align: "right",
      render: (value: number, record) => (
        <PriceDisplay
          value={value}
          invalidText="-"
          decimalScale={8}
          suffix=" VND"
        />
      ),
    },
    {
      title: <p className="text-center font-semibold text-gray-500">{t("role")}</p>,
      dataIndex: "role",
      key: "role",
      width: 100,
      render: (value: "maker" | "taker") => <p className="text-center capitalize">{t(value)}</p>,
    },
    {
      title: <span className="font-semibold text-gray-500">{t("total")}</span>,
      dataIndex: "total",
      key: "total",
      width: 120,
      align: "right",
      render: (value: number) => (
        <PriceDisplay
          value={value}
          suffix=" VND"
        />
      ),
    },
    {
      title: <span className="font-semibold text-gray-500">{t("executionTime")}</span>,
      dataIndex: "executionTime",
      key: "executionTime",
      width: 180,
      render: (value: string) => <DateDisplay date={value} />,
    },
  ];

  const tradingPairOptions = [
    { label: t("all"), value: "all" },
    { label: "XAG/VND", value: "XAG/VND" },
    { label: "PNJ/VND", value: "PNJ/VND" },
  ];

  const orderSideOptions = [
    { label: t("all"), value: "all" },
    { label: t("buy"), value: "buy" },
    { label: t("sell"), value: "sell" },
  ];

  const handleSearch = useCallback(() => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      const filteredData = mockData.filter((item) => {
        const formValues = methods.getValues();

        if (formValues.tradingPair !== "all" && item.tradingPair !== formValues.tradingPair) {
          return false;
        }

        if (formValues.orderSide !== "all" && item.orderSide !== formValues.orderSide) {
          return false;
        }

        // Add date filtering logic here if needed

        return true;
      });

      setData(filteredData);
      setPagination({ ...INIT_PAGINATION, total: filteredData.length });
      setLoading(false);
    }, 500);
  }, [methods]);

  const handleRefresh = useCallback(() => {
    methods.reset();
    handleSearch();
  }, [methods, handleSearch]);

  const handlePaginationChange = useCallback((current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  }, []);

  // Load initial data
  useState(() => {
    handleSearch();
  });

  return (
    <div className="h-full w-full space-y-4">
      <FormProvider {...methods}>
        <Form layout="vertical">
          <Row
            gutter={[16, 16]}
            align="middle"
          >
            <Col
              xs={24}
              sm={12}
              md={6}
              lg={4}
            >
              <SelectField
                name="tradingPair"
                label={<span className="font-semibold">{t("tradingPair")}</span>}
                options={tradingPairOptions}
                placeholder={t("all")}
              />
            </Col>
            <Col
              xs={24}
              sm={12}
              md={6}
              lg={4}
            >
              <SelectField
                name="orderSide"
                label={<span className="font-semibold">{t("orderSide")}</span>}
                options={orderSideOptions}
                placeholder={t("all")}
              />
            </Col>
            <Col
              xs={24}
              sm={12}
              md={8}
              lg={6}
            >
              <p className="mb-2 font-semibold">
                {t("fromDate")} - {t("toDate")}
              </p>
              <DateRangePickerField
                name="dateRange"
                format="DD/MM/YYYY"
              />
            </Col>
            <Col
              xs={24}
              sm={12}
              md={4}
              lg={4}
            >
              <div className="flex gap-2 pt-2 md:ps-8">
                <Button
                  type="primary"
                  onClick={handleSearch}
                  className="flex-1"
                >
                  {t("search")}
                </Button>
                <Button
                  onClick={handleRefresh}
                  disabled={loading}
                  className="flex-1"
                >
                  {t("refresh")}
                </Button>
              </div>
            </Col>
          </Row>
        </Form>
      </FormProvider>

      <CommonTable<TransactionRecord>
        columns={columns}
        dataSource={data}
        rowKey="id"
        loading={loading}
        scroll={{ x: 1000 }}
        paginationData={{
          ...pagination,
          onChange: handlePaginationChange,
        }}
      />
    </div>
  );
}
