"use client";

import { Button, Form, Row, Col, Select, DatePicker, Space, Tag, Popconfirm } from "antd";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { ColumnsType } from "antd/es/table";
import { useTranslations } from "next-intl";
import { useState, useCallback } from "react";
import { useForm, FormProvider } from "react-hook-form";
import dayjs from "dayjs";
import { CommonTable, INIT_PAGINATION, IPagination } from "@/components/ui/form/common-table";
import { SelectField } from "@/components/ui/form/select";
import { DateRangePickerField } from "@/components/ui/form/date-range-picker";
import { CheckBoxField } from "@/components/ui/form/checkbox";
import { DateDisplay } from "@/components/ui/date-components";
import { AmountDisplay, PriceDisplay } from "@/components/ui/number-component";

interface PendingOrderRecord {
  key?: string;
  orderId: string;
  transactionCode: string;
  orderSide: "buy" | "sell";
  orderStatus: "pending" | "partial" | "filled" | "cancelled";
  orderType: "market" | "limit";
  tradingPair: string;
  quantityPlaced: number;
  remainingQuantity: number;
  matchedQuantity: number | undefined;
  matchPrice: number;
  orderTime: string;
  placePrice: number;
  total?: number;
}

interface FilterForm {
  tradingPair: string;
  orderSide: string;
  orderStatus: string;
  orderType: string;
  buy: boolean;
  sell: boolean;
  dateRange: [string, string] | null;
}

export function PendingOrderHistory() {
  const t = useTranslations("HistoryPage");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<PendingOrderRecord[]>([]);
  const [pagination, setPagination] = useState<IPagination>(INIT_PAGINATION);

  const methods = useForm<FilterForm>({
    defaultValues: {
      tradingPair: "all",
      orderSide: "all",
      orderStatus: "all",
      orderType: "all",
      buy: true,
      sell: true,
      dateRange: null,
    },
  });

  // Mock data - replace with actual API call
  const mockData: PendingOrderRecord[] = [
    {
      orderId: "ORD001",
      transactionCode: "TXN12345",
      orderSide: "buy",
      orderStatus: "pending",
      orderType: "limit",
      tradingPair: "XAG/VND",
      quantityPlaced: 100,
      remainingQuantity: 100,
      matchedQuantity: undefined,
      matchPrice: 17987,
      orderTime: "2025-03-31T15:44:23",
      placePrice: 17987,
    },
    {
      orderId: "ORD002",
      transactionCode: "TXN12346",
      orderSide: "sell",
      orderStatus: "partial",
      orderType: "limit",
      tradingPair: "PNJ/VND",
      quantityPlaced: 50,
      remainingQuantity: 20,
      matchedQuantity: 30,
      matchPrice: 10001,
      orderTime: "2025-05-31T15:57:04",
      placePrice: 10001,
      total: 30600000,
    },
    {
      orderId: "ORD003",
      transactionCode: "TXN12347",
      orderSide: "buy",
      orderStatus: "pending",
      orderType: "market",
      tradingPair: "XAG/VND",
      quantityPlaced: 75,
      remainingQuantity: 75,
      matchedQuantity: undefined,
      matchPrice: 18000,
      orderTime: "2025-03-09T16:00:15",
      placePrice: 18000,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "orange";
      case "partial":
        return "blue";
      case "filled":
        return "green";
      case "cancelled":
        return "red";
      default:
        return "default";
    }
  };

  const handleCancelOrder = useCallback((orderId: string) => {
    setLoading(true);
    // Simulate API call to cancel order
    setTimeout(() => {
      setData((prev) =>
        prev.map((item) => (item.orderId === orderId ? { ...item, orderStatus: "cancelled" as const } : item)),
      );
      setLoading(false);
    }, 500);
  }, []);

  const columns: ColumnsType<PendingOrderRecord> = [
    {
      title: t("orderId"),
      dataIndex: "orderId",
      key: "orderId",
      width: 100,
      fixed: "left",
    },
    {
      title: t("tradingPair"),
      dataIndex: "tradingPair",
      key: "tradingPair",
      width: 100,
    },
    {
      title: t("orderSide"),
      dataIndex: "orderSide",
      key: "orderSide",
      width: 100,
      render: (value: "buy" | "sell") => (
        <span className={value === "buy" ? "font-medium text-green-600" : "font-medium text-red-600"}>{t(value)}</span>
      ),
    },
    {
      title: t("orderType"),
      dataIndex: "orderType",
      key: "orderType",
      width: 100,
      render: (value: string) => {
        const typeMap: Record<string, string> = {
          market: t("market"),
          limit: t("limit"),
        };
        return <span className="capitalize">{typeMap[value] || value}</span>;
      },
    },
    {
      title: t("placePrice"),
      dataIndex: "placePrice",
      key: "placePrice",
      width: 120,
      render: (value: number) => (
        <PriceDisplay
          value={value}
          className="font-medium"
          invalidText="-"
        />
      ),
    },
    {
      title: t("matchedQuantity"),
      dataIndex: "matchedQuantity",
      key: "matchedQuantity",
      width: 120,
      render: (value: number) => (
        <AmountDisplay
          value={value}
          invalidText="-"
        />
      ),
    },
    {
      title: t("total"),
      dataIndex: "total",
      key: "total",
      width: 120,
      render: (value: number) => (
        <AmountDisplay
          value={value}
          invalidText="-"
          className="font-medium"
        />
      ),
    },
    {
      title: (
        <div className="flex flex-col items-center">
          <p>{t("quantityPlaced")} /</p>
          <p>{t("remainingQuantity")}</p>
        </div>
      ),
      key: "quantities",
      width: 180,
      render: (_, record) => (
        <div className="text-center text-sm">
          <AmountDisplay
            value={record.quantityPlaced}
            className="font-medium"
          />
          <span className="font-medium"> / </span>
          <AmountDisplay
            value={record.remainingQuantity}
            className="text-gray-500"
          />
        </div>
      ),
    },
    {
      title: t("orderTime"),
      dataIndex: "orderTime",
      key: "orderTime",
      width: 160,
      render: (value) => <DateDisplay date={value} />,
    },
    {
      title: t("action"),
      width: 160,
      render: (_, record) => (
        <div className="flex gap-2">
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => {}}
            title={t("modify")}
            size="small"
          />
          <Popconfirm
            title={t("cancel")}
            description="Are you sure you want to cancel this order?"
            onConfirm={() => handleCancelOrder(record.orderId)}
            okText="Yes"
            cancelText="No"
          >
            <Button
              type="text"
              icon={<DeleteOutlined />}
              danger
              title={t("cancel")}
              size="small"
            />
          </Popconfirm>
        </div>
      ),
    },
  ];

  const handlePaginationChange = useCallback((current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  }, []);

  const handleSearch = useCallback(async (values: FilterForm) => {
    setLoading(true);
    try {
      // TODO: Replace with actual API call
      console.log("Search values:", values);

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Filter mock data based on search criteria
      let filteredData = [...mockData];

      if (values.tradingPair !== "all") {
        filteredData = filteredData.filter((item) => item.tradingPair === values.tradingPair);
      }

      if (values.orderSide !== "all") {
        filteredData = filteredData.filter((item) => item.orderSide === values.orderSide);
      }

      // Filter by buy/sell checkboxes
      const includesBuy = values.buy;
      const includesSell = values.sell;
      if (!includesBuy || !includesSell) {
        filteredData = filteredData.filter((item) => {
          if (includesBuy && !includesSell) return item.orderSide === "buy";
          if (includesSell && !includesBuy) return item.orderSide === "sell";
          return false; // If both are false, show nothing
        });
      }

      if (values.orderStatus !== "all") {
        filteredData = filteredData.filter((item) => item.orderStatus === values.orderStatus);
      }

      if (values.orderType !== "all") {
        filteredData = filteredData.filter((item) => item.orderType === values.orderType);
      }

      if (values.dateRange && values.dateRange[0] && values.dateRange[1]) {
        const startDate = dayjs(values.dateRange[0]).startOf("day");
        const endDate = dayjs(values.dateRange[1]).endOf("day");
        filteredData = filteredData.filter((item) => {
          const itemDate = dayjs(item.orderTime, "MM/DD/YYYY HH:mm:ss");
          return itemDate.isAfter(startDate) && itemDate.isBefore(endDate);
        });
      }

      setData(filteredData);
      setPagination({ ...INIT_PAGINATION, total: filteredData.length });
    } catch (error) {
      console.error("Search error:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleRefresh = useCallback(() => {
    setLoading(true);
    // TODO: Replace with actual API call
    setTimeout(() => {
      setData([...mockData]);
      setPagination({ ...INIT_PAGINATION, total: mockData.length });
      setLoading(false);
    }, 500);
  }, []);

  // Initialize data on mount
  useState(() => {
    handleRefresh();
  });

  return (
    <div className="h-full w-full">
      <FormProvider {...methods}>
        <Form
          layout="vertical"
          onFinish={methods.handleSubmit(handleSearch)}
          className="mb-4"
        >
          <Row gutter={16}>
            <Col
              xs={16}
              sm={12}
              md={4}
            >
              <SelectField
                name="tradingPair"
                label={<span className="font-semibold">{t("tradingPair")}</span>}
                placeholder={t("tradingPair")}
                options={[
                  { label: t("all"), value: "all" },
                  { label: "XAG/VND", value: "XAG/VND" },
                  { label: "PNJ/VND", value: "PNJ/VND" },
                  { label: "BTC/VND", value: "BTC/VND" },
                ]}
              />
            </Col>
            <Col
              xs={16}
              sm={12}
              md={4}
            >
              <SelectField
                name="orderType"
                label={<span className="font-semibold">{t("orderType")}</span>}
                placeholder={t("orderType")}
                options={[
                  { label: t("all"), value: "all" },
                  { label: t("market"), value: "market" },
                  { label: t("limit"), value: "limit" },
                ]}
              />
            </Col>
            <Col
              xs={16}
              sm={12}
              md={4}
            >
              <div>
                <p className="font-semibold">{t("orderSide")}</p>
                <div className="flex gap-4 md:pt-3">
                  <CheckBoxField
                    name="buy"
                    label={t("buy")}
                  >
                    <span className="font-semibold text-green-600 uppercase">{t("buy")}</span>
                  </CheckBoxField>
                  <CheckBoxField
                    name="sell"
                    label={t("sell")}
                  >
                    <span className="font-semibold text-red-600 uppercase">{t("sell")}</span>
                  </CheckBoxField>
                </div>
              </div>
            </Col>
            <Col
              xs={16}
              sm={12}
              md={4}
            >
              <div className="relative">
                <p className="mb-2 font-semibold">
                  {t("fromDate")} - {t("toDate")}
                </p>
                <DateRangePickerField
                  name="dateRange"
                  placeholder={[t("fromDate"), t("toDate")]}
                />
              </div>
            </Col>
            <Col
              xs={24}
              sm={12}
              md={4}
              className="flex items-end"
            >
              <Button
                className="!px-8 md:ms-6 md:mt-6"
                type="primary"
                htmlType="submit"
              >
                {t("search")}
              </Button>
            </Col>
          </Row>
        </Form>
      </FormProvider>

      <CommonTable<PendingOrderRecord>
        columns={columns}
        dataSource={data}
        loading={loading}
        rowKey="orderId"
        scroll={{ x: 1200 }}
        paginationData={{
          ...pagination,
          onChange: handlePaginationChange,
        }}
      />
    </div>
  );
}
