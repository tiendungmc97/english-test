"use client";

import * as React from "react";
import { Layout } from "antd";
import { WalletSidenav } from "./components/wallet-sidenav";

const { Sider, Content } = Layout;

type Props = { children: React.ReactNode };

export default function WalletLayout({ children }: Props) {
  return (
    <Layout className="min-h-screen">
      <Sider
        width={240}
        className="!hidden !bg-white lg:!block"
      >
        <WalletSidenav />
      </Sider>
      <Content className="!overflow-auto">
        <div className="bg-white p-4 md:p-6">{children}</div>
      </Content>
    </Layout>
  );
}
