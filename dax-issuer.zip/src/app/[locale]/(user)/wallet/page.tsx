"use client";

import { useRouter } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { useEffect } from "react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

export default function WalletPage() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to /wallet/deposit/fiat by default
    router.replace(ROUTERS.WALLET.DEPOSIT_FIAT);
  }, [router]);

  return (
    <div className="flex min-h-[400px] items-center justify-center">
      <LoadingSpinner text="Đang tải thông tin..." />
    </div>
  );
}
