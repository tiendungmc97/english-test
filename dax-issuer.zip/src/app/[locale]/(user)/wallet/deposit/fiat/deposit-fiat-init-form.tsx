"use client";

import { InputNumberField } from "@/components/ui/form/input-number";
import { SelectField } from "@/components/ui/form/select";
import { formatCurrency } from "@/utils/format-currency";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button, Card, Form, Typography } from "antd";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";
const { Title } = Typography;

const createFiatDepositSchema = (min: number, max: number) =>
  z.object({
    currency: z.string().nonempty({ message: "Vui lòng chọn loại tiền tệ" }),
    amount: z
      .number({ invalid_type_error: "Số tiền không hợp lệ", required_error: "Vui lòng nhập số tiền muốn nạp" })
      .min(min, { message: `Số tiền nạp tối thiểu là ${formatCurrency(min)} VND` })
      .max(max, { message: `Số tiền nạp tối đa là ${formatCurrency(max)} VND` }),
  });

export type FiatDepositFormData = z.infer<ReturnType<typeof createFiatDepositSchema>>;

interface FiatDepositInitFormProps {
  isLoading?: boolean;
  minDeposit: number;
  maxDeposit: number;
  onNext: (data: FiatDepositFormData) => void;
}

const currencyOptions = [
  {
    label: "Việt Nam Đồng",
    value: "VND",
    extra: "VND",
  },
];
export function DepositFiatInitForm({ onNext, minDeposit, maxDeposit, isLoading }: FiatDepositInitFormProps) {
  const fiatDepositSchema = createFiatDepositSchema(minDeposit, maxDeposit);
  const methods = useForm<FiatDepositFormData>({
    resolver: zodResolver(fiatDepositSchema),
    defaultValues: {
      currency: "VND",
      amount: undefined,
    },
  });
  const { handleSubmit, watch } = methods;

  const handleFormSubmit = async (data: FiatDepositFormData) => {
    onNext?.(data);
  };

  return (
    <Card className="!border-border">
      <Title
        level={3}
        className="!mt-0"
      >
        Nạp tiền ký quỹ
      </Title>
      <FormProvider {...methods}>
        <Form
          layout="vertical"
          onFinish={handleSubmit(handleFormSubmit)}
          className="!space-y-4 md:!space-y-8 lg:min-w-[380px]"
        >
          <SelectField
            name="currency"
            label="Đơn vị tiền tệ:"
            options={currencyOptions}
            placeholder="Chọn loại tiền tệ"
            disabled
          />

          <InputNumberField
            name="amount"
            label="Số tiền nạp:"
            placeholder="Nhập số tiền muốn nạp"
            step={1000}
            formatter={(value) => (value ? `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "")}
            parser={(value) => value!.replace(/\$\s?|(,*)/g, "")}
            addonAfter="VND"
            autoFocus
          />

          <div className="flex justify-end pt-2 md:pt-16">
            <Button
              type="primary"
              htmlType="submit"
              className="!h-10 !px-8"
              loading={isLoading}
            >
              Tiếp tục
            </Button>
          </div>
        </Form>
      </FormProvider>
    </Card>
  );
}
