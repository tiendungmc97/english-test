"use client";

import { Countdown } from "@/components/ui/date-components";
import { InputFileField } from "@/components/ui/form/input-file";
import { InputNumberField } from "@/components/ui/form/input-number";
import { useCountdown } from "@/hooks/use-dayjs";
import { formatCurrency } from "@/utils/format-currency";
import { CopyOutlined } from "@ant-design/icons";
import { zodResolver } from "@hookform/resolvers/zod";
import { App, Button, Form, QRCode } from "antd";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";

interface TransactionData {
  transactionId: string;
  beneficiaryBankName: string;
  beneficiaryAccountNumber: string;
  beneficiaryAccountName: string;
  transferAmount: number;
  currency: string;
  transferDescription: string;
  qrCode: string;
  expireAt: string;
}

interface DepositFiatConfirmFormProps {
  bankInfo?: TransactionData;
  transactionData?: TransactionData;
  amount?: number;
  isLoading?: boolean;
  onConfirm?: (data: { file: File; amount?: number }) => void;
  onBack?: () => void;
}
// Form validation schema
const formSchema = z.object({
  file: z
    .any()
    .refine((file) => file !== null && file !== undefined, {
      message: "Vui lòng chọn ảnh giao dịch",
    })
    .refine(
      (file) => {
        if (!file?.originFileObj) return false;
        return file.originFileObj.size <= 5 * 1024 * 1024; // 5MB
      },
      {
        message: "Kích thước file không được vượt quá 5MB",
      },
    )
    .refine(
      (file) => {
        if (!file?.originFileObj) return false;
        const allowedTypes = ["image/png", "image/jpg", "image/jpeg"];
        return allowedTypes.includes(file.originFileObj.type);
      },
      {
        message: "Chỉ chấp nhận file PNG, JPG, JPEG",
      },
    ),
  amount: z.number().optional(),
});

type FormData = z.infer<typeof formSchema>;

export function DepositFiatConfirmForm({
  bankInfo,
  transactionData,
  amount,
  isLoading = false,
  onConfirm,
  onBack,
}: DepositFiatConfirmFormProps) {
  const displayAmount = transactionData ? transactionData.transferAmount : amount;
  const { message } = App.useApp();
  const { isExpired, minutes } = useCountdown(bankInfo?.expireAt || "");

  const methods = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      file: null,
      amount: undefined,
    },
  });

  const isTimeRunningLow = minutes && minutes <= 5;

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      message.success("Copied to clipboard");
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  const onSubmit = (data: FormData) => {
    if (onConfirm) {
      onConfirm({
        file: data.file.originFileObj,
        amount: data.amount,
      });
    }
  };

  const handleConfirm = () => {
    methods.handleSubmit(onSubmit)();
  };

  return (
    <div className="h-full w-full">
      <h2 className="text-lg font-bold">Thông tin tài khoản:</h2>
      <p className="mb-8 text-sm text-gray-600">(vui lòng chuyển khoản qua tài khoản sau)</p>

      <div className="">
        <div className="flex items-center justify-start md:h-10">
          <span className="pe-2 text-sm text-gray-600">Ngân hàng thu hưởng: </span>
          <span className="font-bold">{bankInfo?.beneficiaryBankName}</span>
        </div>

        <div className="flex h-10 items-center justify-start">
          <div>
            <span className="pe-2 text-sm text-gray-600">Số tài khoản: </span>
            <span className="font-bold">{bankInfo?.beneficiaryAccountNumber}</span>
          </div>
          <Button
            type="text"
            icon={<CopyOutlined />}
            onClick={() => handleCopy(bankInfo?.beneficiaryAccountNumber || "")}
          />
        </div>

        <div className="flex h-10 items-center justify-start">
          <span className="pe-2 text-sm text-gray-600">Chủ tài khoản: </span>
          <span className="font-bold">{bankInfo?.beneficiaryAccountName}</span>
        </div>

        <div className="flex h-10 items-center justify-start">
          <span className="pe-2 text-sm text-gray-600">Số tiền nạp: </span>
          <span className="font-bold">{formatCurrency(bankInfo?.transferAmount, { showSymbol: true })}</span>
        </div>
        <div className="flex h-10 items-center justify-start">
          <div>
            <span className="pe-2 text-sm text-gray-600">Nội dung chuyển khoản: </span>
            <span className="font-bold">{bankInfo?.transferDescription}</span>
          </div>
          <Button
            type="text"
            icon={<CopyOutlined />}
            onClick={() => handleCopy(bankInfo?.transferDescription || "")}
          />
        </div>
        {bankInfo?.qrCode && (
          <div className="mb-6 flex pt-4 md:gap-10">
            <span className="text-sm text-gray-600">Hoặc quét mã QR:</span>
            <div className="mt-2 flex justify-center">
              <QRCode value={bankInfo.qrCode} />
            </div>
          </div>
        )}
      </div>
      <FormProvider {...methods}>
        <Form
          onFinish={methods.handleSubmit(onSubmit)}
          layout="vertical"
        >
          <InputNumberField
            name="amount"
            label="Số tiền đã giao dịch:"
            placeholder="Số tiền đã nạp thực tế"
            step={1000}
            addonAfter="VND"
            autoFocus
            required
          />
          <InputFileField
            name="file"
            label="Ảnh giao dịch:"
            allowedFormats={[".png", ".jpg", ".jpeg"]}
            maxFiles={1}
            note={<p className="mt-1 text-xs text-gray-500">(Định dạng: PNG/JPG/JPEG, Tối đa: 5MB)</p>}
            required
          >
            Tải ảnh lên
          </InputFileField>
        </Form>
      </FormProvider>

      {displayAmount && (
        <div className="mb-6 rounded bg-gray-50 p-3">
          <span className="text-sm text-gray-600">Số tiền đã giao dịch: </span>
          <span className="text-lg font-bold">
            {new Intl.NumberFormat("vi-VN").format(displayAmount)} {transactionData?.currency || "VND"}
          </span>
        </div>
      )}

      {isTimeRunningLow && (
        <div className="mb-4 rounded border border-yellow-200 bg-yellow-50 p-3">
          <p className="text-sm text-yellow-800">
            ⚠️ Thời gian giao dịch sắp hết! Vui lòng hoàn thành trong{" "}
            <Countdown
              date={bankInfo?.expireAt}
              showMinutes
              showSeconds
            />
            .
          </p>
        </div>
      )}

      {isExpired && (
        <div className="mb-4 rounded border border-red-200 bg-red-50 p-3">
          <p className="text-sm text-red-800">❌ Thời gian giao dịch đã hết. Vui lòng tạo giao dịch mới.</p>
        </div>
      )}

      <div className="flex justify-end gap-3">
        {onBack && (
          <Button
            onClick={onBack}
            className="!h-10 !px-8"
          >
            Quay lại
          </Button>
        )}
        <Button
          type="primary"
          className={`!h-10 !px-8 ${
            isExpired
              ? "cursor-not-allowed border-gray-400 bg-gray-400"
              : isTimeRunningLow
                ? "border-yellow-600 bg-yellow-600 hover:bg-yellow-700"
                : "border-black bg-black hover:bg-gray-800"
          }`}
          loading={isLoading}
          onClick={handleConfirm}
          disabled={isExpired}
        >
          {isExpired ? (
            "Hết thời gian"
          ) : (
            <span>
              Xác nhận (
              <Countdown
                date={bankInfo?.expireAt}
                showSeconds
                className="px-[1px]"
              />
              )
            </span>
          )}
        </Button>
      </div>
    </div>
  );
}

export default DepositFiatConfirmForm;
