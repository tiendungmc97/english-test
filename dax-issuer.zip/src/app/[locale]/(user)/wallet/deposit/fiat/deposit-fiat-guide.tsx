import { Card, Typography } from "antd";
const { Title, Link: A } = Typography;
export function DepositFiatGuide() {
  return (
    <Card className="!border-border h-full w-full">
      <Title
        level={3}
        className="!mt-0"
      >
        Hướng dẫn:
      </Title>
      <ol className="mb-4 max-w-[460px] list-inside list-none">
        <li>
          <span className="font-bold">Bước 1.</span> Phải hoàn thành KYC
        </li>
        <li>
          <span className="font-bold">Bước 2.</span> Chọn đơn vị tiền
        </li>
        <li>
          <span className="font-bold">Bước 3.</span> Nhập số tiền và nhập Tiếp tục
        </li>
        <li>
          <span className="font-bold">Bước 4.</span> Chuyển khoản theo tài khoản ngân hàng hiển thị{" "}
          <span className="font-bold">HOẶC</span> quét mã QR với nội dung chuyển khoản: <br />
          <span className="font-bold">SĐT - UID tài khoản - Mã giao dịch</span>
          <br />
          VD: <span className="text-gray-700">+84 983 981 927 - 89765543 - M9134DY8675</span>
        </li>
        <li>
          <span className="font-bold">Bước 5.</span> Tải ảnh giao dịch thành công và xác nhận hoàn thành giao dịch
        </li>
      </ol>
      <div className="mt-4 border-l-2 border-yellow-400 bg-yellow-50 p-4">
        <span className="font-bold">Lưu ý:</span>
        <br />
        Thời gian tối đa <span className="font-bold">15 phút</span>. Sau 15 phút, nếu khách hàng chưa hoàn thành giao
        dịch, giao dịch sẽ được huỷ.
      </div>
    </Card>
  );
}
