"use client";

import { ErrorModal } from "@/components/ui/error-modal";
import { SuccessModal } from "@/components/ui/success-modal";
import { useUserInfo } from "@/services/hooks/use-auth";
import {
  useMutationDepositFiatConfirm,
  useMutationDepositFiatInit,
  useQueryFiatCurrency,
} from "@/services/hooks/use-wallet";
import { FiatDepositInitRes } from "@/services/service/wallet-service";
import { useState } from "react";
import { DepositFiatConfirmForm } from "./deposit-fiat-confirm-form";
import { DepositFiatGuide } from "./deposit-fiat-guide";
import { DepositFiatInitForm, FiatDepositFormData } from "./deposit-fiat-init-form";
import { DepositFiatTableHistory } from "./deposit-fiat-table-history";
import dayjs from "dayjs";

type DepositStep = "init" | "confirm";

export default function FiatDepositPage() {
  const { data: userInfo } = useUserInfo();
  const { data: fiatCurrencies } = useQueryFiatCurrency();
  const selectedCurrency = "VND";
  const currencyInfo = fiatCurrencies?.find((c) => c.currency === selectedCurrency);

  const [step, setStep] = useState<DepositStep>("init");
  const [fiatDepositData, setFiatDepositData] = useState<FiatDepositInitRes | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const { mutate: depositFiatInit, isPending: isDepositFiatInitPending } = useMutationDepositFiatInit();
  const { mutate: depositFiatConfirm, isPending: isDepositFiatConfirmPending } = useMutationDepositFiatConfirm();

  const handleDepositInit = (data: FiatDepositFormData) => {
    depositFiatInit(data, {
      onSuccess: (res) => {
        setStep("confirm");
        setFiatDepositData(res.data);
      },
      onError: (error) => {
        setErrorMessage((error as any)?.message || "Đã có lỗi xảy ra, vui lòng thử lại sau hoặc liên hệ hỗ trợ.");
        setShowErrorModal(true);
      },
    });
  };

  const handleDepositConfirm = (payload: any) => {
    if (!fiatDepositData?.transactionId) {
      setErrorMessage("Không tìm thấy thông tin giao dịch. Vui lòng thử lại.");
      setShowErrorModal(true);
      return;
    }
    depositFiatConfirm(fiatDepositData.transactionId, {
      onSuccess: () => {
        setShowSuccessModal(true);
      },
      onError: (error) => {
        setErrorMessage((error as any)?.message || "Đã có lỗi xảy ra, vui lòng thử lại sau hoặc liên hệ hỗ trợ.");
        setShowErrorModal(true);
      },
    });
  };

  const handleSuccessModalOk = () => {
    setStep("init");
    setFiatDepositData(null);
  };

  const handleErrorModalOk = () => {
    // Reset error state if needed
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="order-2 xl:order-2 xl:col-span-4">
          <DepositFiatGuide />
        </div>

        <div className="order-1 xl:order-1 xl:col-span-8">
          {step === "init" ? (
            <DepositFiatInitForm
              isLoading={isDepositFiatInitPending}
              onNext={handleDepositInit}
              maxDeposit={userInfo?.data?.maxDeposit ?? 0}
              minDeposit={userInfo?.data?.minDeposit ?? 0}
            />
          ) : (
            <DepositFiatConfirmForm
              isLoading={isDepositFiatConfirmPending}
              bankInfo={fiatDepositData!}
              onBack={() => setStep("init")}
              onConfirm={handleDepositConfirm}
            />
          )}
        </div>
      </div>

      {step === "init" && (
        <div className="order-3">
          <DepositFiatTableHistory />
        </div>
      )}

      <SuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        title="Nạp tiền thành công"
        message="Giao dịch của bạn đang được xử lý. Vui lòng kiểm tra email để xác nhận giao dịch."
        onOk={handleSuccessModalOk}
      />

      <ErrorModal
        isOpen={showErrorModal}
        onClose={() => setShowErrorModal(false)}
        title="Nạp tiền thất bại"
        message={errorMessage}
        onOk={handleErrorModalOk}
      />
    </div>
  );
}
