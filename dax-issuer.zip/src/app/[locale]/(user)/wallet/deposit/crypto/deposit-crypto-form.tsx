"use client";

import React from "react";
import { Card, Form, Button, Divider, Typography, Tooltip } from "antd";
import { ArrowRightOutlined, InfoCircleOutlined, CopyOutlined } from "@ant-design/icons";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { InputNumberField } from "@/components/ui/form/input-number";
import { InputTextField } from "@/components/ui/form/input-text";
import { SelectField } from "@/components/ui/form/select";
import { useTranslations } from "next-intl";
const { Title } = Typography;

export type SelectOption = { label: string; value: string };

type Props = {
  tokens: SelectOption[];
  chains: SelectOption[];
  available: number;
  dailyLimit: number;
  dailyUsed: number;
  fee: number;
  defaultToken?: string;
  defaultChain?: string;
  onSubmit?: (data: FormValues) => void;
};

const schema = z.object({
  token: z.string().min(1, "Vui lòng chọn mã token"),
  chain: z.string().min(1, "Vui lòng chọn mạng nạp"),
  address: z.string().min(6, "Địa chỉ không hợp lệ"),
  amount: z.coerce.number({ invalid_type_error: "Số lượng không hợp lệ" }).min(1, "Tối thiểu 1"),
});
type FormValues = z.infer<typeof schema>;

export default function DepositCryptoForm({
  tokens,
  chains,
  available,
  dailyLimit,
  dailyUsed,
  fee,
  defaultToken = tokens[0]?.value,
  defaultChain = chains[0]?.value,
  onSubmit,
}: Props) {
  const t = useTranslations("WalletPage");
  const tValidate = useTranslations("Validation");
  const methods = useForm<FormValues>({
    mode: "onChange",
    reValidateMode: "onChange",
    resolver: zodResolver(schema),
    defaultValues: {
      token: defaultToken ?? "",
      chain: defaultChain ?? "",
      address: "",
      amount: 0,
    },
  });

  const {
    handleSubmit,
    watch,
    formState: { errors, isValid, isSubmitting },
  } = methods;

  const [form] = Form.useForm();

  const currentToken = watch("token") || defaultToken || "";
  const amount = watch("amount") ?? 0;
  const estimate = Math.max(0, Number(amount || 0) - fee);

  const onFinish = (data: FormValues) => {
    onSubmit?.(data);
  };

  const handleCopyAddress = () => {
    // Mock address for demo
    const mockAddress = "0x742d35Cc6635C0532925a3b8D0F8f9E0C4b5c8b1";
    navigator.clipboard.writeText(mockAddress);
  };

  return (
    <Card className="!border-border">
      <Title
        level={3}
        className="!mt-0"
      >
        Nạp tài sản
      </Title>
      <FormProvider {...methods}>
        <Form
          form={form}
          layout="vertical"
          className="space-y-4"
          onFinish={handleSubmit(onFinish)}
          disabled={isSubmitting}
        >
          <SelectField<FormValues>
            name="token"
            label="Mã tài sản"
            required
            options={tokens}
            className="w-full"
            popupMatchSelectWidth
            allowClear
          />

          <SelectField<FormValues>
            name="chain"
            label="Chọn mạng"
            required
            options={chains}
            className="w-full"
          />

          <InputTextField<FormValues>
            name="address"
            label="Địa chỉ nạp"
            required
            placeholder="Nhập địa chỉ nạp token"
            suffix={
              <Button
                type="text"
                icon={<CopyOutlined />}
                onClick={handleCopyAddress}
                className="!p-1"
              />
            }
          />

          <InputNumberField<FormValues>
            name="amount"
            label="Khối lượng"
            required
            min={0}
            placeholder="Tối thiểu 1"
            addonAfter={currentToken}
          />
          <div className="text-textBase/70 mt-1 text-xs">Tối thiểu 1</div>
          {errors.amount && <div className="text-xs text-red-500">{errors.amount.message}</div>}

          <div className="mt-2 space-y-3">
            <div className="border-border flex items-center justify-between pb-2">
              <div className="text-textBase flex items-center gap-2">
                Số lượng nạp tối thiểu <InfoCircleOutlined className="text-gray-400" />
              </div>
              <div className="font-medium">1 {currentToken}</div>
            </div>
          </div>

          <Divider className="my-5" />

          <div className="flex justify-end">
            <Button
              type="primary"
              htmlType="submit"
              className="!h-10 !px-8"
              onClick={form.submit}
              disabled={!isValid}
              loading={isSubmitting}
            >
              Nạp
            </Button>
          </div>
        </Form>
      </FormProvider>
    </Card>
  );
}
