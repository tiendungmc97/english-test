"use client";

import React from "react";
import { Card, Tag, Typography } from "antd";
import { CommonTable, INIT_PAGINATION, IPagination } from "@/components/ui/form/common-table";
import { ColumnsType } from "antd/es/table";
import { useRouter } from "next/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import TokenHistory from "../../../history/token/token-history";
import { DateDisplay } from "@/components/ui/date-components";

const { Title, Link: A } = Typography;

export type RecentRow = {
  key?: string;
  time: string;
  token: string;
  amount: number;
  txid: string;
  status: "success" | "pending" | "failed";
};

export default function DepositCryptoRecentTable({ rows }: { rows: RecentRow[] }) {
  const [pagination, setPagination] = React.useState<IPagination>(INIT_PAGINATION);
  const router = useRouter();
  const handleChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  };
  const recentColumns: ColumnsType<RecentRow> = [
    { title: "Thời gian", dataIndex: "time", render: (value) => <DateDisplay date={value} /> },
    { title: "Mã token", dataIndex: "token" },
    { title: "Số lượng", dataIndex: "amount" },
    {
      title: "TxID",
      dataIndex: "txid",
      render: (v) => (
        <A
          href="#"
          className="text-primary"
        >
          {v}
        </A>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      render: (s) =>
        s === "success" ? (
          <Tag color="green">Hoàn thành</Tag>
        ) : s === "pending" ? (
          <Tag color="gold">Đang xử lý</Tag>
        ) : (
          <Tag color="red">Thất bại</Tag>
        ),
    },
  ];
  return (
    <Card className="!border-none !bg-white">
      <div className="mb-3 flex items-center justify-between">
        <Title
          level={3}
          className="!m-0"
        >
          Giao dịch nạp token gần đây
        </Title>
        <A
          className="text-primary"
          onClick={() => router.push(`${ROUTERS.HISTORY.TOKEN}?type=deposit`)}
        >
          Xem thêm
        </A>
      </div>

      <TokenHistory
        isFilter={false}
        data={[]}
        defaultType="w"
      />
    </Card>
  );
}
