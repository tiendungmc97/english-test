"use client";

import * as React from "react";
import DepositCryptoRecentTable, { RecentRow } from "./deposit-crypto-table";
import DepositCryptoFaq from "./deposit-crypto-faq";
import DepositCryptoForm from "./deposit-crypto-form";

type SelectOption = { label: string; value: string };

export default function Page() {
  const tokens: SelectOption[] = [{ label: "FSV  •  F-silver", value: "FSV" }];
  const chains: SelectOption[] = [{ label: "BSC  •  BNB Smart Chain (BEP20)", value: "BSC" }];

  const recent: RecentRow[] = [
    { time: "03/09/2025 10:19:00", token: "FSV", amount: 100, txid: "0x2154...32564", status: "success" },
  ];

  const handleSubmit = React.useCallback(() => {
    console.log("submit deposit");
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="order-1 xl:order-2 xl:col-span-4">
          <DepositCryptoFaq />
        </div>

        <div className="order-2 xl:order-1 xl:col-span-8">
          <DepositCryptoForm
            tokens={tokens}
            chains={chains}
            available={100}
            dailyLimit={1000}
            dailyUsed={0}
            fee={0.5}
            onSubmit={handleSubmit}
          />
        </div>
      </div>

      <div className="order-3">
        <DepositCryptoRecentTable rows={recent} />
      </div>
    </div>
  );
}
