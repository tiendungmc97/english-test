"use client";

import React from "react";
import { Card, Typography } from "antd";
import { QuestionCircleOutlined } from "@ant-design/icons";

const { Title, Link: A } = Typography;

export default function WithdrawCryptoFaq() {
  return (
    <Card className="!border-none">
      <Title
        level={3}
        className="!mt-0"
      >
        FAQ
      </Title>

      <ul className="list-none space-y-2">
        <li>
          <A
            href="#"
            className="text-primary"
          >
            Cách rút tiền mã hóa?
          </A>
        </li>
        <li>
          <A
            href="#"
            className="text-primary"
          >
            Hướng dẫn rút tiền mã hóa từng bước?
          </A>
        </li>
        <li>
          <A
            href="#"
            className="text-primary"
          >
            Truy vấn trạng thái nạp và rút tiền mã hóa
          </A>
        </li>
      </ul>

      <div className="border-primary bg-primaryBgHover/40 text-textBase mt-4 border-l-2 p-3 text-sm">
        <QuestionCircleOutlined className="text-textBase/70 mr-2" />
        Chỉ cho phép rút token từ ví Cấp vốn. Đây là số dư khả dụng ở ví Cấp vốn.
      </div>
    </Card>
  );
}
