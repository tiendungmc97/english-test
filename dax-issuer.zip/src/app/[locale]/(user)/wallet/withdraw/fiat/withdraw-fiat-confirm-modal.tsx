"use client";

import { InputTextField } from "@/components/ui/form/input-text";
import { FiatWithdrawResponse } from "@/services/service/wallet-service";
import { Image, Modal } from "antd";
import { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import type { UserBankAccount } from "@/services/service/user-service";
import { formatCurrency } from "@/utils/format-currency";

export interface WithdrawFiatConfirmModalProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  transactionData?: FiatWithdrawResponse;
  bankAccounts: UserBankAccount[];
  onConfirm: () => void;
  isLoading?: boolean;
}

export function WithdrawFiatConfirmModal({
  isOpen,
  setIsOpen,
  transactionData,
  bankAccounts,
  onConfirm,
  isLoading = false,
}: WithdrawFiatConfirmModalProps) {
  const [errorMessage, setErrorMessage] = useState("");
  const methods = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    values: {
      bank: transactionData?.transferBank ?? "",
      accountNumber: transactionData?.transferAccountNo ?? "",
      accountHolder: transactionData?.transferAccountName ?? "",
      withdrawAmount: formatCurrency(transactionData?.transferAmount),
      fee: formatCurrency(transactionData?.fee),
      actualAmount: formatCurrency(transactionData?.actualReceived),
    },
  });

  return (
    <Modal
      centered
      closeIcon
      closable={false}
      okText="Xác nhận"
      cancelText="Hủy bỏ"
      onOk={() => {
        onConfirm();
        setIsOpen(false);
      }}
      onCancel={() => {
        setIsOpen(false);
        setErrorMessage("");
        methods.reset();
      }}
      open={isOpen}
      confirmLoading={isLoading}
      width={480}
      className="withdraw-confirm-modal"
    >
      <div className="mb-6 flex w-full flex-col items-center justify-center">
        <Image
          src="/images/vindas.svg"
          alt="vindas-icon"
          width={50}
          height={30}
        />
        <Image
          src="/images/vindas-text.svg"
          alt="vindas-icon"
          width={80}
          height={40}
        />
      </div>

      <div className="pb-4 text-center">
        <h2 className="text-lg font-semibold">Thông tin giao dịch rút</h2>
        {errorMessage && (
          <div className="mt-2 inline-block rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">
            {errorMessage}
          </div>
        )}
      </div>

      <FormProvider {...methods}>
        <div className="space-y-0">
          <InputTextField
            name="bank"
            label="Ngân hàng nhận"
            disabled
            size="small"
            className="!text-gray-400"
          />

          <InputTextField
            name="accountNumber"
            label="Số tài khoản"
            disabled
            size="small"
            className="!text-gray-400"
          />

          <InputTextField
            name="accountHolder"
            label="Chủ tài khoản"
            disabled
            size="small"
            className="!text-gray-400"
          />
          <InputTextField
            name="withdrawAmount"
            label="Số tiền rút"
            disabled
            size="small"
            className="!text-gray-400"
          />
          <InputTextField
            name="fee"
            label="Phí rút"
            disabled
            size="small"
            className="!text-gray-400"
          />
          <InputTextField
            name="actualAmount"
            label="Số tiền thực rút"
            disabled
            size="small"
            className="!text-gray-400"
          />
        </div>
      </FormProvider>

      <div className="mt-4 rounded border border-yellow-200 bg-yellow-50 p-3 text-sm text-yellow-800">
        <p className="font-medium">Lưu ý:</p>
        <p>Vui lòng kiểm tra kỹ thông tin trước khi xác nhận</p>
        <p>Giao dịch sẽ được xử lý trong vòng 1-3 ngày làm việc</p>
        <p>Không thể hủy bỏ sau khi xác nhận</p>
      </div>
    </Modal>
  );
}

export default WithdrawFiatConfirmModal;
