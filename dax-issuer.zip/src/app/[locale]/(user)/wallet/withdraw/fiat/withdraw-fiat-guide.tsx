import { Card, Typography } from "antd";
const { Title, Link: A } = Typography;

export function WithdrawFiatGuide() {
  return (
    <Card className="!border-border">
      <Title
        level={3}
        className="!mt-0"
      >
        Hướng dẫn:
      </Title>
      <ol className="mb-4 max-w-[460px] list-inside list-none">
        <li>
          <span className="font-bold">Bước 1.</span> Hoàn thành KYC
        </li>
        <li>
          <span className="font-bold">Bước 2.</span> Nhập thông tin ngân hàng muốn nhận tiền và Thiết lập mật khẩu 2 lớp
        </li>
        <li>
          <span className="font-bold">Bước 3.</span> Chọn đơn vị tiền
        </li>
        <li>
          <span className="font-bold">Bước 4.</span> Nhập số tiền và chọn ngân hàng thu hương
        </li>
        <li>
          <span className="font-bold">Bước 5.</span> Nhấn rút tiền
        </li>
        <li>
          <span className="font-bold">Bước 6.</span> Đợi hệ thống thanh toán
        </li>
      </ol>
    </Card>
  );
}
