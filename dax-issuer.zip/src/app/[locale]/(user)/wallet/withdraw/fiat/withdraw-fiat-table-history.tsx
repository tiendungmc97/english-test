"use client";

import React from "react";
import { Card, Typography } from "antd";
import { CommonTable, INIT_PAGINATION, IPagination } from "@/components/ui/form/common-table";
import { ColumnsType } from "antd/es/table";
import { useRouter } from "next/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { FundingType } from "@/libs/types/wallet";
import { useQueryFiatHistory } from "@/services/hooks/use-wallet";
import FiatHistory from "../../../history/fiat/fiat-history";
import { DateDisplay } from "@/components/ui/date-components";

const { Title, Link: A } = Typography;

export interface FiatHistoryRecord {
  key: string;
  id: number;
  fundingType: string;
  currencyCd: string;
  amount: number;
  state: string;
  createDate: string;
  acceptDatetime: string | null;
  completedDatetime: string | null;
  writeDate: string;
  method: string;
  fee: number;
  remark: string;
}

export function WithdrawFiatTableHistory() {
  const [pagination, setPagination] = React.useState<IPagination>(INIT_PAGINATION);
  const router = useRouter();

  const { data: fiatHistorys } = useQueryFiatHistory({
    fundingType: FundingType.WITHDRAW,
    page: 0,
    size: 5,
  });

  const handleChange = (current: number, pageSize: number) => {
    setPagination((prev) => ({ ...prev, current, pageSize }));
  };

  const methodMap: { [key: string]: string } = {
    bt: "Chuyển khoản ngân hàng",
    cc: "Thẻ",
    it: "Chuyển nội bộ",
    qd: "Nạp nhanh",
  };

  const getStatusInfo = (state: string) => {
    switch (state) {
      case "completed":
        return { text: "Thành công", className: "bg-green-50 text-green-700 border-green-200" };
      case "cancel":
        return { text: "Đã hủy", className: "bg-gray-50 text-gray-700 border-gray-200" };
      case "in-progress":
        return { text: "Đang xử lý", className: "bg-yellow-50 text-yellow-700 border-yellow-200" };
      case "new":
        return { text: "Ghi nhận", className: "bg-blue-50 text-blue-700 border-blue-200" };
      case "failed":
      case "error":
        return { text: "Thất bại", className: "bg-red-50 text-red-700 border-red-200" };
      default:
        return { text: state, className: "bg-gray-50 text-gray-700 border-gray-200" };
    }
  };

  const columns: ColumnsType<FiatHistoryRecord> = [
    {
      title: "Loại",
      dataIndex: "fundingType",
      key: "fundingType",
      render: (value: string) => (
        <span
          className={`text-sm ${value === "d" ? "text-green-600" : value === "w" ? "text-red-600" : "text-gray-600"}`}
        >
          {value === "d" ? "Nạp tiền" : value === "w" ? "Rút tiền" : value}
        </span>
      ),
    },
    {
      title: "Tiền tệ",
      dataIndex: "currencyCd",
      key: "currencyCd",
      render: (value: string) => <span className="text-sm">{value}</span>,
    },
    {
      title: "Số tiền",
      dataIndex: "amount",
      key: "amount",
      render: (value: number, record: FiatHistoryRecord) => (
        <span className="text-sm font-medium">
          {value.toLocaleString()} {record.currencyCd}
        </span>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "state",
      key: "state",
      render: (value: string) => {
        const statusInfo = getStatusInfo(value);
        return <span className={`rounded-sm border px-2 py-1 text-sm ${statusInfo.className}`}>{statusInfo.text}</span>;
      },
    },
    {
      title: "Phương thức",
      dataIndex: "method",
      key: "method",
      render: (value: string) => <span className="text-sm">{methodMap[value] || value}</span>,
    },
    {
      title: "Thời gian tạo",
      dataIndex: "createDate",
      key: "createDate",
      render: (value: string) => <DateDisplay date={value} />,
    },
  ];

  // Transform data to add key property for table
  const transformedData =
    fiatHistorys?.data?.map((record: FiatHistoryRecord) => ({
      ...record,
      key: record.id.toString(),
    })) || [];
  return (
    <Card className="!border-none">
      <div className="mb-3 flex items-center justify-between">
        <Title
          level={3}
          className="!m-0"
        >
          Giao dịch rút tiền gần đây
        </Title>
        <A
          className="text-primary"
          onClick={() => router.push(`${ROUTERS.HISTORY.FIAT}?type=withdraw`)}
        >
          Xem thêm
        </A>
      </div>

      <FiatHistory
        data={fiatHistorys}
        isFilter={false}
        defaultType={FundingType.WITHDRAW}
      />
    </Card>
  );
}
