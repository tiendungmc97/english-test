"use client";

import { InputNumberField } from "@/components/ui/form/input-number";
import { InputTextField } from "@/components/ui/form/input-text";
import { SelectField } from "@/components/ui/form/select";
import type { UserBankAccount } from "@/services/service/user-service";
import { formatCurrency } from "@/utils/format-currency";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button, Card, Form, Typography } from "antd";
import { useEffect, useMemo } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";
const { Title } = Typography;

interface FiatWithdrawInitFormProps {
  isLoading?: boolean;
  minWithdraw: number;
  maxWithdraw: number;
  availableBalance: number | undefined;
  dailyLimit: number;
  dailyUsed: number;
  withdrawalFee: number;
  onNext: (data: FiatWithdrawFormData) => void;
  bankAccounts: UserBankAccount[];
}

const createFiatWithdrawSchema = (min: number, max: number) =>
  z.object({
    currency: z.string().nonempty({ message: "Vui lòng chọn loại tiền tệ" }),
    amount: z
      .number({ invalid_type_error: "Số tiền không hợp lệ" })
      .min(min, { message: `Số tiền rút tối thiểu là ${min} VND` })
      .max(max, { message: `Số tiền rút tối đa là ${max} VND` }),
    bankName: z.string().nonempty({ message: "Vui lòng chọn ngân hàng" }),
    accNumber: z.string().nonempty({ message: "Vui lòng nhập số tài khoản" }),
    accHolderName: z.string().nonempty({ message: "Vui lòng nhập tên chủ tài khoản" }),
    fee: z.number().nonnegative(),
  });

export type FiatWithdrawFormData = z.infer<ReturnType<typeof createFiatWithdrawSchema>>;
const currencyOptions = [
  {
    label: "Việt Nam Đồng",
    value: "VND",
    extra: "VND",
  },
];

export function WithdrawFiatInitForm({
  onNext,
  minWithdraw,
  maxWithdraw,
  availableBalance,
  dailyLimit,
  dailyUsed,
  withdrawalFee,
  isLoading,
  bankAccounts,
}: FiatWithdrawInitFormProps) {
  const effectiveMax = availableBalance ?? maxWithdraw;
  const fiatWithdrawSchema = createFiatWithdrawSchema(minWithdraw, effectiveMax);
  const methods = useForm<FiatWithdrawFormData>({
    resolver: zodResolver(fiatWithdrawSchema),
    defaultValues: {
      currency: "VND",
      amount: 0,
      bankName: "",
      accNumber: "",
      accHolderName: "",
      fee: 0,
    },
  });

  const { handleSubmit, watch } = methods;
  const watchedAmount = watch("amount");
  const watchedAccName = watch("bankName");
  const watchedFee = watch("fee");
  useEffect(() => {
    const computedFeeAmount = (watchedAmount ?? 0) * 0.001;
    methods.setValue("fee", computedFeeAmount);
  }, [watchedAmount, methods]);
  const actualWithdrawAmount = (watchedAmount ?? 0) - (watchedFee ?? 0);

  useEffect(() => {
    const selectedAccount = bankAccounts?.find((acc: any) => String(acc.id) === String(watchedAccName));
    if (selectedAccount) {
      methods.setValue("accNumber", selectedAccount.accNumber);
      methods.setValue("accHolderName", selectedAccount.accHolderName);
    } else {
      methods.setValue("accNumber", "");
      methods.setValue("accHolderName", "");
    }
  }, [watchedAccName, bankAccounts, methods]);

  const bankOptions = useMemo(() => {
    if (!bankAccounts) return [];
    const options = bankAccounts.map((account: any) => ({
      label: account.bankName,
      value: String(account.id),
    }));
    return options;
  }, [bankAccounts]);

  const handleFormSubmit = async (data: FiatWithdrawFormData) => {
    onNext?.(data);
  };

  return (
    <Card className="!border-border">
      <Title
        level={3}
        className="!mt-0"
      >
        Rút tiền ký quỹ
      </Title>
      <FormProvider {...methods}>
        <Form
          layout="vertical"
          onFinish={handleSubmit(handleFormSubmit)}
          className="!space-y-4 md:!space-y-8 lg:min-w-[380px]"
        >
          <SelectField
            name="currency"
            label="Đơn vị tiền tệ:"
            options={currencyOptions}
            placeholder="Chọn loại tiền tệ"
            disabled={true}
          />

          <InputNumberField
            name="amount"
            label="Số tiền rút:"
            placeholder={`Tối thiểu ${minWithdraw} VND`}
            min={minWithdraw}
            max={availableBalance}
            step={1000}
            formatter={(value) => (value ? `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "")}
            parser={(value) => value!.replace(/\$\s?|(,*)/g, "")}
            addonAfter="VND"
            autoFocus
          />

          <div className="mt-2 space-y-3">
            <div className="border-border flex items-center justify-between border-b pb-2">
              <div className="text-textBase flex items-center gap-2">Có thể rút</div>
              <div className="font-medium">{formatCurrency(availableBalance)}</div>
            </div>

            <div className="border-border flex items-center justify-between border-b pb-2">
              <div className="text-textBase">Hạn mức còn lại trong 24h</div>
              <div className="font-medium">
                {formatCurrency(dailyLimit - dailyUsed)}
                <span className="text-textBase/60">
                  {" / "}
                  {formatCurrency(dailyLimit)}
                </span>
              </div>
            </div>

            <div className="border-border flex items-center justify-between border-b pb-2">
              <div className="text-textBase">Phí rút tiền</div>
              <div className="font-medium">{formatCurrency(watchedFee ?? 0)}</div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-textBase font-medium">Số tiền thực rút</div>
              <div className="font-bold">{formatCurrency(actualWithdrawAmount)}</div>
            </div>
          </div>

          <SelectField
            name="bankName"
            label="Ngân hàng nhận:"
            options={bankOptions}
            placeholder="Chọn ngân hàng"
            allowClear
          />

          <InputTextField
            name="accNumber"
            label="Số tài khoản:"
            disabled
          />

          <InputTextField
            name="accHolderName"
            label="Chủ tài khoản:"
            disabled
          />

          <div className="flex justify-end pt-2">
            <Button
              type="primary"
              htmlType="submit"
              className="!h-10 !px-8"
              loading={isLoading}
            >
              Rút
            </Button>
          </div>
        </Form>
      </FormProvider>
    </Card>
  );
}
