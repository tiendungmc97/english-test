"use client";

import { InputOTPField } from "@/components/ui/form/input-otp";
import { useUserBankAccounts, useUserInfo } from "@/services/hooks/use-auth";
import { App } from "antd";
import { useRouter } from "@/i18n/navigation";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import WithdrawFiatConfirmModal from "./withdraw-fiat-confirm-modal";
import { WithdrawFiatGuide } from "./withdraw-fiat-guide";
import { WithdrawFiatInitForm } from "./withdraw-fiat-init-form";
import { WithdrawFiatTableHistory } from "./withdraw-fiat-table-history";
import {
  useMutationWithdrawFiatConfirm,
  useMutationWithdrawFiatInit,
  useQueryWalletBalance,
} from "@/services/hooks/use-wallet";
import type { FiatWithdrawFormData } from "./withdraw-fiat-init-form";
import { FiatWithdrawResponse } from "@/services/service/wallet-service";

export default function FiatWithdrawPage() {
  const { modal } = App.useApp();
  const { message } = App.useApp();
  const router = useRouter();
  const { data: userInfo } = useUserInfo();
  const { data: bankAccountsRes } = useUserBankAccounts();
  const { data: walletBalance } = useQueryWalletBalance({
    walletType: "funding",
    assetSymbol: "VND",
  });
  const [isOpenConfirmModal, setIsOpenConfirmModal] = useState(false);
  const { mutateAsync: withdrawInit, isPending: isWithdrawing } = useMutationWithdrawFiatInit();
  const { mutateAsync: withdrawConfirm, isPending: isConfirming } = useMutationWithdrawFiatConfirm();
  const methods = useForm({ mode: "onChange", reValidateMode: "onChange" });
  const [transaction, setTransaction] = useState<FiatWithdrawResponse>();

  const handleWithdrawInit = async (values: FiatWithdrawFormData) => {
    const transaction = await withdrawInit({
      amount: String(values.amount ?? 0),
      currency: values.currency,
      fee: String((values.amount ?? 0) * 0.001),
      bankId: Number(values.bankName),
    });
    setTransaction(transaction.data);
    setIsOpenConfirmModal(true);
  };

  const handleConfirmWithdraw = () => {
    modal.confirm({
      title: "Verify OTP để hoàn tất giao dịch",
      content: (
        <FormProvider {...methods}>
          <InputOTPField
            name="otp"
            label="Mã xác thực OTP"
            length={6}
            disabled={false}
          />
        </FormProvider>
      ),
      icon: null,
      onOk: async () => {
        const values = methods.getValues();
        const code = values?.otp;
        if (!code || !transaction?.transactionId) return;
        await withdrawConfirm({ withdrawId: transaction.transactionId, code: String(code) });
        message.success("Xác nhận rút tiền thành công");
        router.push("/history?tab=withdraw&type=fiat");
      },
      onCancel: () => {
        methods.reset();
      },
      okText: "Xác nhận",
      cancelText: "Hủy bỏ",
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        <div className="order-1 xl:order-2 xl:col-span-4">
          <WithdrawFiatGuide />
        </div>

        <div className="order-2 xl:order-1 xl:col-span-8">
          <WithdrawFiatInitForm
            isLoading={isWithdrawing}
            availableBalance={walletBalance?.balanceFree}
            dailyUsed={0}
            dailyLimit={userInfo?.data?.dailyWithdrawLimit ?? 0}
            withdrawalFee={userInfo?.data?.withdrawalFee ?? 0}
            onNext={handleWithdrawInit}
            maxWithdraw={userInfo?.data?.maxWithdraw ?? 0}
            minWithdraw={userInfo?.data?.minWithdraw ?? 0}
            bankAccounts={bankAccountsRes?.data ?? []}
          />
        </div>
      </div>

      <div className="order-3">
        <WithdrawFiatTableHistory />
      </div>

      <WithdrawFiatConfirmModal
        isOpen={isOpenConfirmModal}
        setIsOpen={setIsOpenConfirmModal}
        transactionData={transaction}
        bankAccounts={bankAccountsRes?.data ?? []}
        onConfirm={handleConfirmWithdraw}
      />
    </div>
  );
}
