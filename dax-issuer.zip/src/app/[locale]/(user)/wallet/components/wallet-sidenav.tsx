"use client";

import * as React from "react";
import { usePathname, useRouter } from "@/i18n/navigation";
import { BankOutlined, CreditCardOutlined, WalletOutlined, SendOutlined } from "@ant-design/icons";
import { Menu, type MenuProps } from "antd";
import { useTranslations } from "next-intl";
import { ROUTERS } from "@/libs/constants/routers";

type WalletNavItem = {
  key: string;
  label: string;
  href: string;
  icon: React.ComponentType<any>;
};

const NAV: WalletNavItem[] = [
  { key: "deposit-fiat", label: "Nạp tiền ký quỹ", href: ROUTERS.WALLET.DEPOSIT_FIAT, icon: BankOutlined },
  {
    key: "withdraw-fiat",
    label: "Rút tiền ký quỹ",
    href: ROUTERS.WALLET.WITHDRAW_FIAT,
    icon: CreditCardOutlined,
  },
  { key: "deposit-crypto", label: "Nạp tài sản", href: ROUTERS.WALLET.DEPOSIT_CRYPTO, icon: WalletOutlined },
  { key: "withdraw-crypto", label: "Rút tài sản", href: ROUTERS.WALLET.WITHDRAW_CRYPTO, icon: SendOutlined },
];

export function WalletSidenav() {
  const t = useTranslations("WalletPage");

  const pathname = usePathname();
  const router = useRouter();

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + "/");
  const go = (href: string) => router.push(href);

  const menuItems: MenuProps["items"] = NAV.map((item) => {
    const Icon = item.icon as any;
    return {
      key: item.href,
      icon: <Icon />,
      label: item.label,
      title: item.label,
      onClick: () => go(item.href),
    };
  });

  const selectedKeys: string[] = React.useMemo(() => {
    for (const item of NAV) {
      if (isActive(item.href)) return [item.href];
    }
    return [];
  }, [pathname, isActive]);

  return (
    <div className="pt-8">
      <div className="overflow-hidden bg-white p-0">
        <Menu
          mode="inline"
          items={menuItems}
          selectedKeys={selectedKeys}
          className="!border-none"
        />
      </div>
    </div>
  );
}
