"use client";

import { useRouter } from "@/i18n/navigation";
import { useTranslations } from "next-intl";

import { useProfile } from "./use-profile";
import { ProfileAvatar } from "./profile-avatar";
import { ProfileSkeleton } from "./profile-skeleton";
import { ProfileField, ProfileSection } from "./profile-section";
import { useQueryIssuerProfile } from "@/services/hooks/use-issuer";

export default function ProfilePage() {
  const router = useRouter();
  const t = useTranslations("ProfilePage");
  const { data: profile, isLoading, error } = useQueryIssuerProfile();
  if (isLoading) {
    return <ProfileSkeleton />;
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-neutral-50 py-8 dark:bg-neutral-900">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="py-12 text-center">
            <div className="mb-4 text-red-600 dark:text-red-400">{!!error || "Profile not found"}</div>
            <button
              onClick={() => router.back()}
              className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
            >
              Go back
            </button>
          </div>
        </div>
      </div>
    );
  }

  const generalInfoFields: ProfileField[] = [
    {
      key: "name",
      label: t("fields.name"),
      value: profile.companyName,
    },
    {
      key: "accountType",
      label: t("fields.accountType"),
      value: profile.companyType,
    },
  ];

  const contactInfoFields: ProfileField[] = [
    {
      key: "representative",
      label: t("fields.representative"),
      value: profile.partnerName,
    },
    {
      key: "phone",
      label: t("fields.phone"),
      value: profile.phone,
    },
    {
      key: "email",
      label: t("fields.email"),
      value: (
        <a
          href={`mailto:${profile.email}`}
          className="text-blue-600 transition-colors hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
        >
          {profile.email}
        </a>
      ),
    },
  ];

  const activityInfoFields: ProfileField[] = [
    {
      key: "role",
      label: t("fields.role"),
      value: profile.position,
    },
    {
      key: "accountStatus",
      label: t("fields.accountStatus"),
      value: (
        <span
          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
            profile.status === "active"
              ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
              : "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100"
          }`}
        >
          {profile.status}
        </span>
      ),
    },
    {
      key: "transactionStatus",
      label: t("fields.transactionStatus"),
      value: (
        <span
          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
            profile.transactionStatus === "operating"
              ? "bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100"
              : "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100"
          }`}
        >
          {profile.transactionStatus}
        </span>
      ),
    },
  ];

  return (
    <div className="bg-neutral-50 py-8 dark:bg-neutral-900">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-neutral-900 sm:text-3xl dark:text-neutral-100">{t("title")}</h1>
        </div>

        <div className="overflow-hidden rounded-lg bg-white shadow-sm dark:bg-neutral-800">
          <div className="px-6 py-8">
            <div className="flex flex-col lg:flex-row lg:space-x-8">
              <div className="mb-8 flex flex-col items-center lg:mb-0 lg:flex-shrink-0 lg:items-start">
                <ProfileAvatar
                  src={profile.avatar ?? "/images/default-avatar.svg"}
                  alt={`${profile.companyName} avatar`}
                  size="xl"
                  className="mb-4"
                />
                <h2 className="text-center text-xl font-semibold text-neutral-900 lg:text-left dark:text-neutral-100">
                  {profile.companyName}
                </h2>
              </div>

              <div className="flex-1 space-y-8">
                <ProfileSection
                  title={t("generalInfo")}
                  fields={generalInfoFields}
                />

                <hr className="border-neutral-200 dark:border-neutral-700" />

                <ProfileSection
                  title={t("contactInfo")}
                  fields={contactInfoFields}
                />

                <hr className="border-neutral-200 dark:border-neutral-700" />

                <ProfileSection
                  title={t("activityInfo")}
                  fields={activityInfoFields}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
