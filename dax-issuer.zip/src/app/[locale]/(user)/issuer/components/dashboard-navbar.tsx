"use client";

import { usePathname, useRouter } from "@/i18n/navigation";
import { ROUTERS } from "@/libs/constants/routers";
import { clearUserInfo } from "@/redux/slice/user.slice";
import { useAppDispatch } from "@/redux/store";
import { FileTextOutlined, FolderOpenOutlined, LogoutOutlined, UserOutlined } from "@ant-design/icons";
import { Button } from "antd";

interface NavItem {
  key: string;
  label: string;
  href: string;
  icon?: React.ReactNode;
}

const navigationItems: NavItem[] = [
  {
    key: "profile",
    label: "Thông Tin Tổ Chức",
    href: ROUTERS.ISSUER.PROFILE,
    icon: <UserOutlined />,
  },
  {
    key: "manager-asset",
    label: "Quản Lý Tài Sản",
    href: ROUTERS.ISSUER.MANAGER_ASSET,
    icon: <FolderOpenOutlined />,
  },
  {
    key: "report",
    label: "Báo Cáo Tài Sản",
    href: ROUTERS.ISSUER.REPORT,
    icon: <FileTextOutlined />,
  },
];

export default function DashboardNavbar() {
  const pathname = usePathname();
  const router = useRouter();
  const dispatch = useAppDispatch();

  const handleNavigation = (href: string) => {
    router.push(href);
  };

  const handleLogout = async () => {
    dispatch(clearUserInfo());
    router.push(ROUTERS.AUTH.LOGIN);
  };

  const isActive = (href: string) => {
    return pathname === href || pathname.startsWith(href + "/");
  };

  return (
    <div className="flex h-full w-64 flex-col border-r border-gray-200 bg-white shadow-sm">
      {/* Header/Logo Section */}
      <div className="border-b border-gray-100 p-6">
        <div className="flex items-center space-x-3">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{ backgroundColor: "#8249DD" }}
          >
            <span className="text-sm font-bold text-white">D</span>
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">Dashboard</h2>
            <p className="text-xs text-gray-500">DAX Issuer</p>
          </div>
        </div>
      </div>

      {/* Navigation Section */}
      <div className="flex-1 p-6">
        <nav className="space-y-2">
          {navigationItems.map((item) => (
            <button
              key={item.key}
              onClick={() => handleNavigation(item.href)}
              className={`w-full cursor-pointer rounded-xl px-4 py-3 text-left font-medium shadow-sm transition-all duration-200 ${
                isActive(item.href)
                  ? "scale-[1.02] transform text-white shadow-md"
                  : "hover:text-primary text-gray-700 hover:scale-[1.01] hover:transform hover:bg-purple-50 hover:shadow-md"
              }`}
              style={
                isActive(item.href)
                  ? {
                      backgroundColor: "#8249DD",
                      boxShadow: "0 4px 20px rgba(130, 73, 221, 0.3)",
                    }
                  : {}
              }
            >
              <div className="flex items-center space-x-3">
                {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                <span>{item.label}</span>
              </div>
            </button>
          ))}
        </nav>
      </div>

      {/* Logout Section */}
      <div className="mb-4 border-t border-gray-100 p-6">
        <Button
          onClick={handleLogout}
          className="w-full"
        >
          <div className="flex items-center space-x-3">
            <span className="flex-shrink-0">
              <LogoutOutlined />
            </span>
            <span>Đăng Xuất</span>
          </div>
        </Button>
      </div>
    </div>
  );
}
