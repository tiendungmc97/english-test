"use client";

import { Button, Table, Input, Checkbox, Pagination } from "antd";
import { SearchOutlined, PlusOutlined } from "@ant-design/icons";
import { useState } from "react";
import { useRouter } from "@/i18n/navigation";
import type { Key } from "react";
import { ROUTERS } from "@/libs/constants/routers";
import { useQueryIssuerAssets } from "@/services/hooks/use-issuer";
import { AmountDisplay } from "@/components/ui/number-component";
import { CommonTable } from "@/components/ui/form/common-table";

interface AssetData {
  key: string;
  assetId: string;
  assetName: string;
  silverQuantity: number;
  weightKg: number;
  tokenValueOwned: number;
  tokenValueCirculating: number;
}

function ManagerAssetPage() {
  const [searchText, setSearchText] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState<Key[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const router = useRouter();
  const { data: assetsRes, isLoading } = useQueryIssuerAssets();

  const columns = [
    {
      title: "Mã Tài Sản",
      dataIndex: "assetId",
      key: "assetId",
      width: 120,
    },
    {
      title: "Tên Tài Sản",
      dataIndex: "assetName",
      key: "assetName",
      width: 200,
    },
    {
      title: "Số Lượng Bạc",
      dataIndex: "silverQuantity",
      key: "silverQuantity",
      width: 140,
      align: "center" as const,
      render: (value: number) => <AmountDisplay value={value} />,
    },
    {
      title: "Khối Lượng (Kg)",
      dataIndex: "weightKg",
      key: "weightKg",
      width: 140,
      align: "center" as const,
      render: (value: number) => <AmountDisplay value={value} />,
    },
    {
      title: "Số Lượng Token Sở Hữu",
      dataIndex: "tokenValueOwned",
      key: "tokenValueOwned",
      width: 180,
      align: "center" as const,
      render: (value: number) => <AmountDisplay value={value} />,
    },
    {
      title: "Số Lượng Token Đang Lưu Hành",
      dataIndex: "tokenValueCirculating",
      key: "tokenValueCirculating",
      width: 200,
      align: "center" as const,
      render: (value: number) => <AmountDisplay value={value} />,
    },
  ];

  // Sample data matching the UI
  const assetData: AssetData[] =
    assetsRes?.responses.map((asset, index) => ({
      key: asset.assetCode,
      assetId: asset.assetCode,
      assetName: asset.assetName,
      silverQuantity: asset.silverQuantity,
      weightKg: asset.weightKg,
      tokenValueOwned: asset.tokenHold,
      tokenValueCirculating: Number(asset.totalCirculatingTokens),
    })) || [];
  // Calculate totals
  const totalQuantityBac = assetData.reduce((sum, item) => sum + item.silverQuantity, 0);
  const totalWeightKg = assetData.reduce((sum, item) => sum + item.weightKg, 0);
  const totalTokenOwned = assetData.reduce((sum, item) => sum + item.tokenValueOwned, 0);
  const totalTokenCirculating = assetData.reduce((sum, item) => sum + item.tokenValueCirculating, 0);

  // Summary row data
  const summaryData = {
    key: "summary",
    assetId: "TỔNG",
    assetName: "",
    silverQuantity: totalQuantityBac,
    weightKg: totalWeightKg,
    tokenValueOwned: totalTokenOwned,
    tokenValueCirculating: totalTokenCirculating,
  };

  const onSelectChange = (newSelectedRowKeys: Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    getCheckboxProps: (record: AssetData) => ({
      disabled: record.key === "summary",
    }),
  };

  const handlePageChange = (page: number, size?: number) => {
    setCurrentPage(page);
    if (size) {
      setPageSize(size);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6 flex w-full items-center justify-between">
        <div>
          <p className="text-bold text-2xl">Tổng tài sản ước tính</p>
          <p className="text-bold text-xl">
            <AmountDisplay value={totalTokenOwned} />
          </p>
        </div>
      </div>

      <div className="rounded-lg bg-white shadow-sm">
        {/* Search and Add Button */}
        <div className="flex items-center justify-between border-b p-4">
          <div className="flex items-center gap-4">
            <Input
              placeholder="Nhập tên tài sản"
              prefix={<SearchOutlined />}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              className="w-64"
            />
            <Button type="default">Tìm kiếm</Button>
          </div>
        </div>

        <CommonTable
          rowSelection={rowSelection}
          columns={columns}
          dataSource={[summaryData, ...assetData]}
          pagination={false}
          scroll={{ x: 1000 }}
          rowClassName={(record) => (record.key === "summary" ? "bg-orange-200 font-bold" : "")}
          onRow={(record) => ({
            onClick: () => {
              // Only navigate if it's not the summary row
              if (record.key !== "summary") {
                router.push(`${ROUTERS.ISSUER.MANAGER_ASSET}/${record.assetId}`);
              }
            },
            style: {
              cursor: record.key !== "summary" ? "pointer" : "default",
            },
          })}
        />

        {/* Pagination */}
        {/* <div className="flex items-center justify-between border-t p-4">
          <div className="flex items-center gap-2">
            <span>Show</span>
            <select className="rounded border px-2 py-1">
              <option>All</option>
              <option>10</option>
              <option>20</option>
              <option>50</option>
            </select>
          </div>
          <Pagination
            current={currentPage}
            total={3}
            pageSize={pageSize}
            showSizeChanger={false}
            showQuickJumper
            onChange={handlePageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div> */}
      </div>
    </div>
  );
}

export default ManagerAssetPage;
