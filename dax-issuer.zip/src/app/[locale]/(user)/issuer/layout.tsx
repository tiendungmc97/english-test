import { ReactNode } from "react";
import Footer from "@/components/footer";
import Breadcrumb from "./components/breadcrumb";
import DashboardNavbar from "./components/dashboard-navbar";

function IssuerLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex bg-gradient-to-br from-gray-50 to-purple-50">
      <div className="fixed inset-y-0 left-0 z-50 w-64 border-r-2 border-purple-100 bg-white shadow-lg">
        <DashboardNavbar />
      </div>
      <div className="ml-64 flex-1">
        <main className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <Breadcrumb />
          {children}
        </main>
      </div>
    </div>
  );
}

export default IssuerLayout;
