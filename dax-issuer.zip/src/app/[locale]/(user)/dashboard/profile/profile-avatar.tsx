"use client";

import Image from "next/image";
import * as React from "react";

export interface ProfileAvatarProps {
  src?: string;
  alt?: string;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const sizeClasses = {
  sm: "h-12 w-12",
  md: "h-16 w-16",
  lg: "h-24 w-24",
  xl: "h-32 w-32",
};

export function ProfileAvatar({
  src = "/images/vindas.svg",
  alt = "User Avatar",
  size = "lg",
  className = "",
}: ProfileAvatarProps) {
  return (
    <div
      className={`relative overflow-hidden rounded-full bg-neutral-100 dark:bg-neutral-800 ${sizeClasses[size]} ${className}`}
    >
      <Image
        src={src}
        alt={alt}
        fill
        className="object-cover"
        onError={(e) => {
          // Fallback to default avatar on error
          const target = e.target as HTMLImageElement;
          target.src = "/images/default-avatar.png";
        }}
      />
    </div>
  );
}
