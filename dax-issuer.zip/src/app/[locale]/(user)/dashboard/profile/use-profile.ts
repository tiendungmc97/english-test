"use client";

import { useState, useEffect } from "react";

export interface UserProfile {
  id: string;
  name: string;
  accountType: string;
  representative: string;
  phone: string;
  email: string;
  role: string;
  accountStatus: string;
  transactionStatus: string;
  avatar?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface UseProfileResult {
  profile: UserProfile | null;
  loading: boolean;
  error: string | null;
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

// Mock data - replace with actual API calls
const mockProfile: UserProfile = {
  id: "1",
  name: "Công ty A",
  accountType: "silverProvider",
  representative: "Tạ Thị B",
  phone: "0123456789",
  email: "ta.thi.b@example.com",
  role: "supervisor",
  accountStatus: "active",
  transactionStatus: "operating",
  avatar: "/images/vindas.svg",
  createdAt: new Date("2024-01-01"),
  updatedAt: new Date(),
};

export function useProfile(): UseProfileResult {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async (): Promise<void> => {
    try {
      setLoading(true);
      setError(null);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // In a real app, this would be an API call:
      // const response = await fetch('/api/profile');
      // const profile = await response.json();

      setProfile(mockProfile);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch profile");
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>): Promise<void> => {
    try {
      setError(null);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));

      // In a real app, this would be an API call:
      // const response = await fetch('/api/profile', {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(updates)
      // });
      // const updatedProfile = await response.json();

      setProfile((prev) =>
        prev
          ? {
              ...prev,
              ...updates,
              updatedAt: new Date(),
            }
          : null,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update profile");
      throw err;
    }
  };

  const refreshProfile = async (): Promise<void> => {
    await fetchProfile();
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  return {
    profile,
    loading,
    error,
    updateProfile,
    refreshProfile,
  };
}
