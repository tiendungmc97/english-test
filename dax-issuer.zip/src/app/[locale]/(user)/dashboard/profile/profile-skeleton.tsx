"use client";

import * as React from "react";

export interface ProfileSkeletonProps {
  className?: string;
}

export function ProfileSkeleton({ className = "" }: ProfileSkeletonProps) {
  return (
    <div className={`min-h-screen bg-neutral-50 py-8 dark:bg-neutral-900 ${className}`}>
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Header Skeleton */}
        <div className="mb-8">
          <div className="h-8 w-64 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
        </div>

        {/* Profile Content Skeleton */}
        <div className="overflow-hidden rounded-lg bg-white shadow-sm dark:bg-neutral-800">
          <div className="px-6 py-8">
            <div className="flex flex-col lg:flex-row lg:space-x-8">
              {/* Avatar Section Skeleton */}
              <div className="mb-8 flex flex-col items-center lg:mb-0 lg:flex-shrink-0 lg:items-start">
                <div className="mb-4 h-32 w-32 animate-pulse rounded-full bg-neutral-200 dark:bg-neutral-700"></div>
                <div className="mb-2 h-6 w-32 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                <div className="h-4 w-24 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
              </div>

              {/* Profile Information Skeleton */}
              <div className="flex-1 space-y-8">
                {/* Section 1 */}
                <div className="space-y-4">
                  <div className="h-6 w-40 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                  <div className="space-y-3">
                    {[...Array(2)].map((_, index) => (
                      <div
                        key={index}
                        className="flex flex-col sm:flex-row sm:items-center"
                      >
                        <div className="h-4 w-28 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                        <div className="mt-2 h-4 w-48 animate-pulse rounded-md bg-neutral-200 sm:mt-0 sm:ml-4 dark:bg-neutral-700"></div>
                      </div>
                    ))}
                  </div>
                </div>

                <hr className="border-neutral-200 dark:border-neutral-700" />

                {/* Section 2 */}
                <div className="space-y-4">
                  <div className="h-6 w-40 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, index) => (
                      <div
                        key={index}
                        className="flex flex-col sm:flex-row sm:items-center"
                      >
                        <div className="h-4 w-28 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                        <div className="mt-2 h-4 w-48 animate-pulse rounded-md bg-neutral-200 sm:mt-0 sm:ml-4 dark:bg-neutral-700"></div>
                      </div>
                    ))}
                  </div>
                </div>

                <hr className="border-neutral-200 dark:border-neutral-700" />

                {/* Section 3 */}
                <div className="space-y-4">
                  <div className="h-6 w-40 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, index) => (
                      <div
                        key={index}
                        className="flex flex-col sm:flex-row sm:items-center"
                      >
                        <div className="h-4 w-28 animate-pulse rounded-md bg-neutral-200 dark:bg-neutral-700"></div>
                        <div className="mt-2 h-6 w-20 animate-pulse rounded-full bg-neutral-200 sm:mt-0 sm:ml-4 dark:bg-neutral-700"></div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
