"use client";

import * as React from "react";

export interface ProfileField {
  key: string;
  label: React.ReactNode;
  value: React.ReactNode;
}

export interface ProfileSectionProps {
  title: React.ReactNode;
  fields: ProfileField[];
  className?: string;
}

export function ProfileSection({ title, fields, className = "" }: ProfileSectionProps) {
  return (
    <div className={`space-y-4 ${className}`}>
      <h3 className="text-lg font-semibold text-neutral-900 dark:text-neutral-100">{title}</h3>
      <div className="space-y-3">
        {fields.map((field) => (
          <div
            key={field.key}
            className="flex flex-col sm:flex-row sm:items-center"
          >
            <dt className="text-sm font-medium text-neutral-600 sm:w-40 sm:flex-shrink-0 dark:text-neutral-400">
              {field.label}
            </dt>
            <dd className="mt-1 text-sm text-neutral-900 sm:mt-0 sm:ml-4 dark:text-neutral-100">
              {field.value || "-"}
            </dd>
          </div>
        ))}
      </div>
    </div>
  );
}
