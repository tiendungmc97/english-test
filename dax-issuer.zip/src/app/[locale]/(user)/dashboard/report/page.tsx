"use client";

import { Button, Table, DatePicker, Select, Pagination } from "antd";
import { SearchOutlined, FilePdfOutlined, FileExcelOutlined } from "@ant-design/icons";
import { useState } from "react";
import type { Dayjs } from "dayjs";

const { RangePicker } = DatePicker;
const { Option } = Select;

interface ReportData {
  key: string;
  reportName: string;
  reportType: string;
  reportDate: string;
  fileType: "PDF" | "Excel";
}

function ReportPage() {
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null] | null>(null);
  const [reportType, setReportType] = useState<string>("All");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Sample report data
  const reportData: ReportData[] = [
    {
      key: "1",
      reportName: "10239032_BaoCaoHangNgay_03042025",
      reportType: "Hàng Ngày",
      reportDate: "3/4/2025",
      fileType: "PDF",
    },
    {
      key: "2",
      reportName: "10271032_BaoCaoHangTuan_05052025",
      reportType: "Hàng Tuần",
      reportDate: "11/5/2025",
      fileType: "Excel",
    },
  ];

  const columns = [
    {
      title: "Tên Báo Cáo",
      dataIndex: "reportName",
      key: "reportName",
      width: 300,
    },
    {
      title: "Loại Báo Cáo",
      dataIndex: "reportType",
      key: "reportType",
      width: 150,
      align: "center" as const,
    },
    {
      title: "Ngày Báo Cáo",
      dataIndex: "reportDate",
      key: "reportDate",
      width: 150,
      align: "center" as const,
    },
    {
      title: "Loại File",
      dataIndex: "fileType",
      key: "fileType",
      width: 120,
      align: "center" as const,
      render: (fileType: string) => (
        <div className="flex justify-center">
          {fileType === "PDF" ? (
            <FilePdfOutlined className="text-lg text-red-500" />
          ) : (
            <FileExcelOutlined className="text-lg text-green-500" />
          )}
        </div>
      ),
    },
    {
      title: "Tải Xuống",
      key: "download",
      width: 120,
      align: "center" as const,
      render: (record: ReportData) => (
        <Button
          type="primary"
          size="small"
          onClick={() => handleDownload(record)}
          className="border-green-500 bg-green-500 hover:bg-green-600"
        >
          ↓
        </Button>
      ),
    },
  ];

  const handleSearch = () => {
    // Implement search functionality
    console.log("Search clicked with:", { dateRange, reportType });
  };

  const handleDownload = (report: ReportData) => {
    // Implement download functionality
    console.log("Download clicked for:", report.reportName);
  };

  const handlePageChange = (page: number, size?: number) => {
    setCurrentPage(page);
    if (size) {
      setPageSize(size);
    }
  };

  return (
    <div className="p-6">
      <h1 className="mb-6 text-2xl font-bold">Báo Cáo</h1>

      <div className="mb-6 rounded-lg bg-white p-6 shadow-sm">
        {/* Filter Section */}
        <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">Ngày Báo Cáo</label>
            <RangePicker
              placeholder={["MM/DD/YYYY", "MM/DD/YYYY"]}
              format="MM/DD/YYYY"
              value={dateRange}
              onChange={setDateRange}
              className="w-full"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">Loại Báo Cáo</label>
            <Select
              value={reportType}
              onChange={setReportType}
              className="w-full"
            >
              <Option value="All">All</Option>
              <Option value="Hàng Ngày">Hàng Ngày</Option>
              <Option value="Hàng Tuần">Hàng Tuần</Option>
              <Option value="Hàng Tháng">Hàng Tháng</Option>
            </Select>
          </div>

          <div className="flex items-end">
            <Button
              type="primary"
              icon={<SearchOutlined />}
              onClick={handleSearch}
              className="h-8"
            >
              Search
            </Button>
          </div>
        </div>

        {/* Table */}
        <Table
          columns={columns}
          dataSource={reportData}
          pagination={false}
          scroll={{ x: 800 }}
          className="mb-4"
        />

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>Show</span>
            <select className="rounded border px-2 py-1">
              <option>All</option>
              <option>10</option>
              <option>20</option>
              <option>50</option>
            </select>
          </div>
          <Pagination
            current={currentPage}
            total={2}
            pageSize={pageSize}
            showSizeChanger={false}
            showQuickJumper
            onChange={handlePageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div>
      </div>
    </div>
  );
}

export default ReportPage;
