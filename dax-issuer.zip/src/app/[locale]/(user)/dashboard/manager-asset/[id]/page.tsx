"use client";

import { Tabs, Table, Pagination } from "antd";
import { useState, use } from "react";

interface AssetDetailData {
  assetId: string;
  assetName: string;
  standardUnit: string;
  quantityBac: number;
  weightKg: number;
  tokenValueOwned: number;
  tokenValueCirculating: number;
}

interface HistoryData {
  key: string;
  quantityBac: number;
  weightKg: number;
  date: string;
  warehouse: string;
  code: string;
  status: string;
}

interface Props {
  params: Promise<{
    id: string;
  }>;
}

function ManagerAssetDetailPage({ params }: Props) {
  const { id } = use(params);
  const [activeTab, setActiveTab] = useState("entry");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Sample asset data - in a real app, this would come from an API
  const assetDataMap: Record<string, AssetDetailData> = {
    B001: {
      assetId: "B001",
      assetName: "Bạc Miếng 999 1 Lượng",
      standardUnit: "37,5 gram",
      quantityBac: 100,
      weightKg: 10,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 10000000,
    },
    B002: {
      assetId: "B002",
      assetName: "Bạc Thỏi 999 10 Lượng",
      standardUnit: "375 gram",
      quantityBac: 21,
      weightKg: 21,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 1000000,
    },
    B003: {
      assetId: "B003",
      assetName: "Bạc Thỏi 999 1 Kg",
      standardUnit: "1000 gram",
      quantityBac: 35,
      weightKg: 35,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 4000000,
    },
  };

  // Sample warehouse entry history
  const entryHistoryData: HistoryData[] = [
    {
      key: "1",
      quantityBac: 100,
      weightKg: 100,
      date: "24/10/2024 15:00",
      warehouse: "Kho Hà Nội",
      code: "PGB001",
      status: "Nguyên vẹn, có chứng nhận kiểm định từ PNJ.",
    },
  ];

  // Sample warehouse exit history
  const exitHistoryData: HistoryData[] = [
    {
      key: "1",
      quantityBac: 100,
      weightKg: 100,
      date: "24/10/2024 15:00",
      warehouse: "Kho Hà Nội",
      code: "PGB001",
      status: "Đã mở niêm phong, kiểm định lại",
    },
  ];

  const historyColumns = [
    {
      title: "Số Lượng Bạc",
      dataIndex: "quantityBac",
      key: "quantityBac",
      width: 120,
      align: "center" as const,
    },
    {
      title: "Khối Lượng (kg)",
      dataIndex: "weightKg",
      key: "weightKg",
      width: 140,
      align: "center" as const,
    },
    {
      title: activeTab === "entry" ? "Ngày Lưu Kho" : "Ngày Xuất Kho",
      dataIndex: "date",
      key: "date",
      width: 160,
      align: "center" as const,
    },
    {
      title: "Kho",
      dataIndex: "warehouse",
      key: "warehouse",
      width: 120,
      align: "center" as const,
    },
    {
      title: activeTab === "entry" ? "Mã Lưu Ký" : "Mã Xuất Kho",
      dataIndex: "code",
      key: "code",
      width: 120,
      align: "center" as const,
    },
    {
      title: "Tình Trạng",
      dataIndex: "status",
      key: "status",
      width: 200,
      render: (text: string) => <div className="text-left">{text}</div>,
    },
  ];

  const handlePageChange = (page: number, size?: number) => {
    setCurrentPage(page);
    if (size) {
      setPageSize(size);
    }
  };

  const assetData = assetDataMap[id];

  // If asset not found, show error message
  if (!assetData) {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold text-red-600">Không tìm thấy tài sản với mã: {id}</h2>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 rounded-lg bg-white p-6 shadow-sm">
        <h2 className="mb-6 text-2xl font-bold">Quản lý tài sản / {assetData.assetName}</h2>

        <div className="grid gap-4">
          <div className="flex">
            <p className="w-40 text-gray-600">Mã tài sản</p>
            <p className="font-bold">{assetData.assetId}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Tên tài sản</p>
            <p className="font-bold">{assetData.assetName}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Đơn vị chuẩn</p>
            <p className="font-bold">{assetData.standardUnit}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Số lượng bạc</p>
            <p className="font-bold">{assetData.quantityBac.toLocaleString("vi-VN")}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Khối lượng (Kg)</p>
            <p className="font-bold">{assetData.weightKg.toLocaleString("vi-VN")}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Số lượng token sở hữu</p>
            <p className="font-bold">{assetData.tokenValueOwned.toLocaleString("vi-VN")}</p>
          </div>
          <div className="flex">
            <p className="w-40 text-gray-600">Số lượng token đang lưu hành</p>
            <p className="font-bold">{assetData.tokenValueCirculating.toLocaleString("vi-VN")}</p>
          </div>
        </div>
      </div>

      <div className="rounded-lg bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-xl font-bold">Lịch sử lưu / xuất kho</h2>

        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          items={[
            {
              key: "entry",
              label: "Lịch sử lưu kho",
              children: (
                <div>
                  <Table
                    columns={historyColumns}
                    dataSource={entryHistoryData}
                    pagination={false}
                    scroll={{ x: 800 }}
                    className="mb-4"
                  />

                  {/* Pagination */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>Show</span>
                      <select className="rounded border px-2 py-1">
                        <option>All</option>
                        <option>10</option>
                        <option>20</option>
                        <option>50</option>
                      </select>
                    </div>
                    <Pagination
                      current={currentPage}
                      total={1}
                      pageSize={pageSize}
                      showSizeChanger={false}
                      showQuickJumper
                      onChange={handlePageChange}
                      showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
                    />
                  </div>
                </div>
              ),
            },
            {
              key: "exit",
              label: "Lịch sử xuất kho",
              children: (
                <div>
                  <Table
                    columns={historyColumns}
                    dataSource={exitHistoryData}
                    pagination={false}
                    scroll={{ x: 800 }}
                    className="mb-4"
                  />

                  {/* Pagination */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>Show</span>
                      <select className="rounded border px-2 py-1">
                        <option>All</option>
                        <option>10</option>
                        <option>20</option>
                        <option>50</option>
                      </select>
                    </div>
                    <Pagination
                      current={currentPage}
                      total={1}
                      pageSize={pageSize}
                      showSizeChanger={false}
                      showQuickJumper
                      onChange={handlePageChange}
                      showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
                    />
                  </div>
                </div>
              ),
            },
          ]}
        />
      </div>
    </div>
  );
}

export default ManagerAssetDetailPage;
