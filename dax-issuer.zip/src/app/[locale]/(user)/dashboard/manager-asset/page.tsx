"use client";

import { Button, Table, Input, Checkbox, Pagination } from "antd";
import { SearchOutlined, PlusOutlined } from "@ant-design/icons";
import { useState } from "react";
import { useRouter } from "@/i18n/navigation";
import type { Key } from "react";

interface AssetData {
  key: string;
  assetId: string;
  assetName: string;
  quantityBac: number;
  weightKg: number;
  tokenValueOwned: number;
  tokenValueCirculating: number;
}

function ManagerAssetPage() {
  const [searchText, setSearchText] = useState("");
  const [selectedRowKeys, setSelectedRowKeys] = useState<Key[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const router = useRouter();

  // Sample data matching the UI
  const assetData: AssetData[] = [
    {
      key: "1",
      assetId: "B001",
      assetName: "Bạc Miếng 999 1 Lượng",
      quantityBac: 100,
      weightKg: 10,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 10000000,
    },
    {
      key: "2",
      assetId: "B002",
      assetName: "Bạc Thỏi 999 10 Lượng",
      quantityBac: 21,
      weightKg: 21,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 1000000,
    },
    {
      key: "3",
      assetId: "B003",
      assetName: "Bạc Thỏi 999 1 Kg",
      quantityBac: 35,
      weightKg: 35,
      tokenValueOwned: 10000000,
      tokenValueCirculating: 4000000,
    },
  ];

  const columns = [
    {
      title: "Mã Tài Sản",
      dataIndex: "assetId",
      key: "assetId",
      width: 120,
    },
    {
      title: "Tên Tài Sản",
      dataIndex: "assetName",
      key: "assetName",
      width: 200,
    },
    {
      title: "Số Lượng Bạc",
      dataIndex: "quantityBac",
      key: "quantityBac",
      width: 140,
      align: "center" as const,
    },
    {
      title: "Khối Lượng (Kg)",
      dataIndex: "weightKg",
      key: "weightKg",
      width: 140,
      align: "center" as const,
    },
    {
      title: "Số Lượng Token Sở Hữu",
      dataIndex: "tokenValueOwned",
      key: "tokenValueOwned",
      width: 180,
      align: "center" as const,
      render: (value: number) => value.toLocaleString("vi-VN"),
    },
    {
      title: "Số Lượng Token Đang Lưu Hành",
      dataIndex: "tokenValueCirculating",
      key: "tokenValueCirculating",
      width: 200,
      align: "center" as const,
      render: (value: number) => value.toLocaleString("vi-VN"),
    },
  ];

  // Calculate totals
  const totalQuantityBac = assetData.reduce((sum, item) => sum + item.quantityBac, 0);
  const totalWeightKg = assetData.reduce((sum, item) => sum + item.weightKg, 0);
  const totalTokenOwned = assetData.reduce((sum, item) => sum + item.tokenValueOwned, 0);
  const totalTokenCirculating = assetData.reduce((sum, item) => sum + item.tokenValueCirculating, 0);

  // Summary row data
  const summaryData = {
    key: "summary",
    assetId: "TỔNG",
    assetName: "",
    quantityBac: totalQuantityBac,
    weightKg: totalWeightKg,
    tokenValueOwned: totalTokenOwned,
    tokenValueCirculating: totalTokenCirculating,
  };

  const onSelectChange = (newSelectedRowKeys: Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    getCheckboxProps: (record: AssetData) => ({
      disabled: record.key === "summary",
    }),
  };

  const handlePageChange = (page: number, size?: number) => {
    setCurrentPage(page);
    if (size) {
      setPageSize(size);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6 flex w-full items-center justify-between">
        <div>
          <p className="text-bold text-2xl">Tổng tài sản ước tính</p>
          <p className="text-bold text-xl">500,000,000 VND</p>
        </div>
        <div className="flex gap-4">
          <Button>Gửi Bạc</Button>
          <Button>Rút Bạc</Button>
        </div>
      </div>

      <div className="rounded-lg bg-white shadow-sm">
        {/* Search and Add Button */}
        <div className="flex items-center justify-between border-b p-4">
          <div className="flex items-center gap-4">
            <Input
              placeholder="Nhập tên tài sản"
              prefix={<SearchOutlined />}
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              className="w-64"
            />
            <Button type="default">Tìm kiếm</Button>
          </div>
          <Button
            type="primary"
            icon={<PlusOutlined />}
          >
            Thêm tài sản
          </Button>
        </div>

        {/* Table */}
        <Table
          rowSelection={rowSelection}
          columns={columns}
          dataSource={[summaryData, ...assetData]}
          pagination={false}
          scroll={{ x: 1000 }}
          rowClassName={(record) => (record.key === "summary" ? "bg-orange-200 font-bold" : "")}
          onRow={(record) => ({
            onClick: () => {
              // Only navigate if it's not the summary row
              if (record.key !== "summary") {
                router.push(`/dashboard/manager-asset/${record.assetId}`);
              }
            },
            style: {
              cursor: record.key !== "summary" ? "pointer" : "default",
            },
          })}
        />

        {/* Pagination */}
        <div className="flex items-center justify-between border-t p-4">
          <div className="flex items-center gap-2">
            <span>Show</span>
            <select className="rounded border px-2 py-1">
              <option>All</option>
              <option>10</option>
              <option>20</option>
              <option>50</option>
            </select>
          </div>
          <Pagination
            current={currentPage}
            total={3}
            pageSize={pageSize}
            showSizeChanger={false}
            showQuickJumper
            onChange={handlePageChange}
            showTotal={(total, range) => `${range[0]}-${range[1]} of ${total} items`}
          />
        </div>
      </div>
    </div>
  );
}

export default ManagerAssetPage;
