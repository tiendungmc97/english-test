"use client";

import * as React from "react";
import { Card, Table, Typography } from "antd";
import type { ColumnsType } from "antd/es/table";
import { useRouter } from "@/i18n/navigation";
import Summary from "../../summary-card";
import { CommonTable } from "@/components/ui/form/common-table";
const { Title } = Typography;

type TokenRow = {
  key: string;
  name: string;
  qty: number | null;
  costVND: number | null;
  profitTodayVND: number | null;
};

const fmtVND = (n: number | null) => (typeof n === "number" ? n.toLocaleString("vi-VN") + " VND" : "-");

const Money: React.FC<{ show: boolean; children: React.ReactNode }> = ({ show, children }) => (
  <>{show ? children : "********"}</>
);

// mock data
const MOCK_TOKEN_ROWS: TokenRow[] = [
  { key: "VND", name: "VND", qty: 10501, costVND: 500_000, profitTodayVND: 2 },
  { key: "FSV", name: "FSV", qty: 1_023_123, costVND: 50_000_000, profitTodayVND: 2 },
  { key: "PNJ", name: "PNJ", qty: 1_234_123_123, costVND: 52_123_000, profitTodayVND: 2 },
];

export default function FundingPage() {
  const router = useRouter();
  const [showBalance, setShowBalance] = React.useState(true);

  const totalValue = 100_000;
  const currency = "VND";
  const todayProfitValue = 20_000;
  const todayProfitPercent = 20;

  const tokenColumns: ColumnsType<TokenRow> = [
    {
      title: <span className="text-textSecondary text-[12px] uppercase">Tiền ký quỹ</span>,
      dataIndex: "name",
      key: "name",
      render: (v) => <span className="font-medium">{v}</span>,
      ellipsis: true,
    },
    {
      title: <span className="text-textSecondary text-[12px] uppercase">Chờ xử lý</span>,
      dataIndex: "costVND",
      key: "costVND",
      align: "right",
      render: (v) => <Money show={showBalance}>{fmtVND(v)}</Money>,
    },
    {
      title: <span className="text-textSecondary text-[12px] uppercase">Khả dụng</span>,
      dataIndex: "costVND",
      key: "costVND",
      align: "right",
      render: (v) => <Money show={showBalance}>{fmtVND(v)}</Money>,
    },
    {
      title: <span className="text-textSecondary text-[12px] uppercase">Tổng số dư</span>,
      dataIndex: "costVND",
      key: "costVND",
      align: "right",
      render: (v) => <Money show={showBalance}>{fmtVND(v)}</Money>,
    },
  ];

  return (
    <div className="space-y-6">
      <Summary
        title="Tổng tiền ký quỹ"
        className="!border-border !mb-4 !bg-white !shadow-none"
        showBalance={showBalance}
        onToggle={() => setShowBalance((v) => !v)}
        totalValue={totalValue}
        unitLabel={currency}
        subLabel="Lợi nhuận hôm nay"
        subValue={todayProfitValue}
        subPercent={todayProfitPercent}
        actions={[
          { label: "Nạp", onClick: () => router.push("/wallet/deposit/crypto") },
          { label: "Rút", onClick: () => router.push("/wallet/withdraw/crypto") },
        ]}
      />

      <Card className="!border-border">
        <CommonTable<TokenRow>
          columns={tokenColumns}
          dataSource={MOCK_TOKEN_ROWS}
          rowKey="key"
          scroll={{ x: 720 }}
        />
      </Card>
    </div>
  );
}
