"use client";

import * as React from "react";
import { Card, Button, Typography } from "antd";
import { EyeOutlined, EyeInvisibleOutlined, DownOutlined } from "@ant-design/icons";
const { Title } = Typography;

type SummaryAction = {
  label: string;
  onClick: () => void;
  /** thêm class nếu cần */
  className?: string;
};

type SummaryProps = {
  /** Tiêu đề góc trái (vd: "Tổng tài sản") */
  title: string;

  /** Hiện/ẩn số dư (controlled) */
  showBalance: boolean;
  onToggle: () => void;

  /** Giá trị chính (số lớn ở giữa) */
  totalValue?: number | string;

  /** Đơn vị/currency hiển thị kế bên (vd: "VND") */
  unitLabel?: string;

  /** Có hiển thị mũi tên ▼ cạnh đơn vị không */
  showUnitDropdown?: boolean;

  /** Nhãn dòng phụ (vd: "Lợi nhuận hôm nay") */
  subLabel?: string;

  /** Giá trị dòng phụ (số/txt), ví dụ +20.000 */
  subValue?: number | string;

  /** Phần trăm dòng phụ, ví dụ 20 */
  subPercent?: number;

  /** SubValue dương/âm để tô màu (auto infer nếu là number; có thể ép qua prop) */
  subPositive?: boolean;

  /** Nút bên phải (vd: Nạp, Rút). Mặc định không có nút nào */
  actions?: SummaryAction[];

  /** Override class */
  className?: string;

  /** Custom formatters nếu muốn giữ format trong app */
  formatMainValue?: (v: number | string | undefined) => React.ReactNode;
  formatSubValue?: (v: number | string | undefined) => React.ReactNode;
  formatPercent?: (v: number | undefined) => React.ReactNode;
};

const Money: React.FC<{ show: boolean; children: React.ReactNode }> = ({ show, children }) => (
  <>{show ? children : "************"}</>
);

const defaultFormatMain = (v: number | string | undefined) => {
  if (v == null) return "-";
  if (typeof v === "number") return v.toLocaleString("vi-VN");
  return v;
};

const defaultFormatSub = (v: number | string | undefined) => {
  if (v == null) return "-";
  if (typeof v === "number") return v.toLocaleString("vi-VN");
  return v;
};

const defaultFormatPercent = (v: number | undefined) => (typeof v === "number" ? `${v}%` : "(0%)");

export default function Summary({
  title,
  showBalance,
  onToggle,
  totalValue,
  unitLabel = "VND",
  showUnitDropdown = true,
  subLabel = "Lợi nhuận hôm nay",
  subValue,
  subPercent,
  subPositive,
  actions = [],
  className = "",
  formatMainValue = defaultFormatMain,
  formatSubValue = defaultFormatSub,
  formatPercent = defaultFormatPercent,
}: SummaryProps) {
  const inferredPositive =
    typeof subValue === "number" ? subValue >= 0 : typeof subPercent === "number" ? subPercent >= 0 : true;
  const positive = typeof subPositive === "boolean" ? subPositive : inferredPositive;

  return (
    <Card className={`${className}`}>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <div className="mb-3 flex items-center gap-2">
            <Title
              level={4}
              className="font-bold text-gray-900 uppercase dark:text-white"
            >
              {title}
            </Title>
            <Button
              type="text"
              size="small"
              aria-label={showBalance ? "Ẩn số dư" : "Hiển thị số dư"}
              icon={showBalance ? <EyeOutlined /> : <EyeInvisibleOutlined />}
              onClick={onToggle}
              className="!flex !items-center !justify-center"
            />
          </div>

          <div className="flex flex-wrap items-baseline gap-x-3 gap-y-2">
            <div className="text-2xl leading-none font-bold sm:text-3xl">
              <Money show={showBalance}>{formatMainValue(totalValue)}</Money>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-semibold sm:text-sm">{unitLabel}</span>
              {showUnitDropdown && <DownOutlined className="text-[10px] text-gray-500" />}
            </div>
          </div>

          <div className="mt-2 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-start sm:gap-2">
            <span className="text-xs text-gray-500 sm:text-sm">{subLabel}</span>
            <span className={`text-xs font-semibold sm:text-sm ${positive ? "text-green-600" : "text-red-600"}`}>
              <Money show={showBalance}>
                {typeof subValue === "number" && subValue >= 0 ? "+" : ""}
                {formatPercent(subPercent as number)}
              </Money>
            </span>
          </div>
        </div>

        {actions?.length ? (
          <div className="flex w-full shrink-0 flex-col gap-2 sm:w-auto sm:flex-row sm:items-start sm:gap-3">
            {actions.map(({ label, onClick, className: btnClass }, idx) => (
              <Button
                key={idx}
                className={`!h-9 !w-full !px-4 !font-semibold sm:!w-auto ${btnClass ?? ""}`}
                onClick={onClick}
              >
                {label}
              </Button>
            ))}
          </div>
        ) : null}
      </div>
    </Card>
  );
}
