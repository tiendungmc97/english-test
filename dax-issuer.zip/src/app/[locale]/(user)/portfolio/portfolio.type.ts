export type AssetRow = {
  key: string;
  name: string;
  icon?: string;
  qty?: number;
  totalVND?: number;
  costPriceVND?: number | null;
  profitTodayVND?: number | null;
};

export type AccountRow = {
  key: string;
  name: string;
  icon?: string;
  balanceVND: number;
};

export interface TokenHoldingItem {
  tokenName: string;
  quantity: number;
  avgCost: number;
  profitToday: number;
}

export interface TodayProfit {
  value: number;
  percentage: number;
}

export interface PortfolioBreakdown {
  walletType: "Spot" | "Funding" | string;
  balance: number;
  percentage: number;
}

export interface PortfolioOverviewResponse {
  totalValue: number;
  currency: string;
  todayProfit: TodayProfit;
  wallet: PortfolioBreakdown[] | null;
  tokenHolding: TokenHoldingItem[] | null;
}

export interface WalletResponse {
  walletType: string;
  currency: string;
  estimatedBalance: number;

  todayProfit: {
    value: number;
    percentage: number;
  };

  tokenHolding: SpotTokenHolding[];
}

export interface SpotTokenHolding {
  tokenName: string;
  quantity: number;
  availableQuantity: number;
  value: number;
  todayProfit: number;
}

export interface SpotTokenHolding {
  tokenName: string;
  quantity: number;
  availableQuantity: number;
  value: number;
  todayProfit: number;
}
