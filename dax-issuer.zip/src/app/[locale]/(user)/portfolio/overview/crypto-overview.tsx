"use client";

import * as React from "react";
import type { ColumnsType } from "antd/es/table";
import { ArrowUpOutlined, ArrowDownOutlined } from "@ant-design/icons";
import { CommonTable } from "@/components/ui/form/common-table";
import { AssetRow } from "../portfolio.type";

const fmtVND = (n: number) => n.toLocaleString("vi-VN");
const tone = (n: number) => (n > 0 ? "text-green-600" : n < 0 ? "text-red-600" : "text-gray-500");
const caret = (n: number | null | undefined) =>
  n && n !== 0 ? n > 0 ? <ArrowUpOutlined /> : <ArrowDownOutlined /> : null;

const Money: React.FC<{ show: boolean; children: React.ReactNode }> = ({ show, children }) => (
  <>{show ? children : "********"}</>
);

type Props = { rows: AssetRow[]; showBalance: boolean; isLoading: boolean };

export const CryptoOverview: React.FC<Props> = ({ rows, showBalance, isLoading }) => {
  const data: AssetRow[] =
    rows.length > 0
      ? rows
      : [
          {
            key: "placeholder",
            name: "-",
            qty: undefined,
            totalVND: undefined,
            costPriceVND: null,
            profitTodayVND: null,
          } as AssetRow,
        ];

  const columns: ColumnsType<AssetRow> = React.useMemo(
    () => [
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Tên tài sản</span>,
        dataIndex: "name",
        key: "name",
        render: (_: unknown, r) => (
          <div className="flex items-start gap-3">
            {r.icon ? <span className="mt-[2px] inline-flex w-4 justify-center">{r.icon}</span> : null}
            <span className="font-medium">{r.name ?? "-"}</span>
          </div>
        ),
        ellipsis: true,
      },
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Khối lượng</span>,
        dataIndex: "qty",
        key: "qty",
        render: (_: unknown, r) => (
          <div>
            <div className="font-semibold tabular-nums">
              <Money show={showBalance}>{r.qty != null ? fmtVND(r.qty) : "-"}</Money>
            </div>
            <div className="text-sm text-gray-500 tabular-nums">
              <Money show={showBalance}>{r.totalVND != null ? `${fmtVND(r.totalVND)} VND` : "-"}</Money>
            </div>
          </div>
        ),
        ellipsis: true,
      },
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Giá mua</span>,
        dataIndex: "costPriceVND",
        key: "costPriceVND",
        render: (v: number | null | undefined) =>
          v != null ? <Money show={showBalance}>{`${fmtVND(v)} VND`}</Money> : "-",
        ellipsis: true,
      },
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Lợi nhuận hôm nay</span>,
        dataIndex: "profitTodayVND",
        key: "profitTodayVND",
        render: (v: number | null | undefined) =>
          v != null ? (
            showBalance ? (
              <span className={`inline-flex items-center gap-1 tabular-nums ${tone(v)}`}>
                {caret(v)}
                {v > 0 ? "+" : ""}
                {fmtVND(Math.abs(v))} VND
              </span>
            ) : (
              "********"
            )
          ) : (
            <span className="text-gray-400">-</span>
          ),
        ellipsis: true,
      },
    ],
    [showBalance],
  );

  return (
    <CommonTable<AssetRow>
      rowKey={(r) => String(r.key)}
      columns={columns}
      dataSource={data}
      loading={isLoading}
      scroll={{ x: 720 }}
    />
  );
};
