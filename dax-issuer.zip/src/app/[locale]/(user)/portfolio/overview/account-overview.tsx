"use client";

import * as React from "react";
import type { ColumnsType } from "antd/es/table";
import { CommonTable } from "@/components/ui/form/common-table";
import { AccountRow } from "../portfolio.type";

/* utils */
const fmtVND = (n: number) => n.toLocaleString("vi-VN");
const Money: React.FC<{ show: boolean; children: React.ReactNode }> = ({ show, children }) => (
  <>{show ? children : "******"}</>
);

type Props = { rows: AccountRow[]; showBalance: boolean; isLoading: boolean };

export const AccountOverview: React.FC<Props> = ({ rows, showBalance, isLoading }) => {
  const total = React.useMemo(() => rows.reduce((s, r) => s + (r.balanceVND || 0), 0), [rows]);

  const data: AccountRow[] =
    rows.length > 0
      ? rows
      : [
          {
            key: "placeholder",
            name: "-",
            icon: "",
            balanceVND: 0,
          } as AccountRow,
        ];

  const columns: ColumnsType<AccountRow> = React.useMemo(
    () => [
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Tài khoản</span>,
        dataIndex: "name",
        key: "name",
        render: (_: unknown, r) => (
          <div className="flex items-center gap-3">
            {r.icon ? <span className="text-lg">{r.icon}</span> : null}
            <span className="font-medium">{r.name ?? "-"}</span>
          </div>
        ),
        ellipsis: true,
      },
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Giá trị quy đổi</span>,
        dataIndex: "balanceVND",
        key: "balanceVND",
        render: (v: number | undefined) => (
          <span className="font-semibold tabular-nums">
            <Money show={showBalance}>{v != null ? `${fmtVND(v)} VND` : "-"}</Money>
          </span>
        ),
        ellipsis: true,
      },
      {
        title: <span className="text-textSecondary text-[12px] uppercase">Tỷ lệ phân bổ</span>,
        key: "percentage",
        render: (_: unknown, r) =>
          rows.length === 0 ? (
            <span className="text-gray-400">-</span>
          ) : showBalance ? (
            <span className="text-gray-700 tabular-nums">
              {total > 0 ? ((r.balanceVND / total) * 100).toFixed(2) : "0.00"}%
            </span>
          ) : (
            "******"
          ),
        ellipsis: true,
      },
    ],
    [showBalance, total, rows.length],
  );

  return (
    <CommonTable<AccountRow>
      rowKey={(r) => String(r.key)}
      columns={columns}
      dataSource={data}
      loading={isLoading}
      scroll={{ x: 640 }}
    />
  );
};
