"use client";

import * as React from "react";
import { Card, Tabs, Typography } from "antd";
import { useRouter } from "@/i18n/navigation";
import { AccountRow, AssetRow } from "../portfolio.type";
import { CryptoOverview } from "./crypto-overview";
import { AccountOverview } from "./account-overview";
import { usePortfolio } from "@/services/hooks/use-portfolio";
import Summary from "../summary-card";
const { Title } = Typography;

function AssetsCard({
  showBalance,
  tokenRows,
  accountRows,
  onTabChange,
  isLoading,
}: {
  showBalance: boolean;
  tokenRows: AssetRow[];
  accountRows: AccountRow[];
  onTabChange: (k: string) => void;
  isLoading: boolean;
}) {
  const items = React.useMemo(
    () => [
      {
        key: "wallet",
        label: "Tài khoản",
        children: (
          <AccountOverview
            rows={accountRows}
            showBalance={showBalance}
            isLoading={isLoading}
          />
        ),
      },
      {
        key: "token",
        label: "Tài sản thực",
        children: (
          <CryptoOverview
            rows={tokenRows}
            showBalance={showBalance}
            isLoading={isLoading}
          />
        ),
      },
    ],
    [showBalance, tokenRows, accountRows, isLoading],
  );

  const [activeKey, setActiveKey] = React.useState<string>("token");

  return (
    <Card className="!border-border">
      <Tabs
        activeKey={activeKey}
        onChange={(k) => {
          setActiveKey(k);
          onTabChange(k);
        }}
        items={items}
      />
    </Card>
  );
}

function mapTokenHoldingToAssetRows(
  tokenHolding?: Array<{
    tokenName: string;
    quantity: number;
    avgCost: number | null;
    profitToday: number | null;
  }> | null,
): AssetRow[] {
  if (!tokenHolding) return [];
  return tokenHolding.map((t, idx) => ({
    key: `${t.tokenName}-${idx}`,
    name: t.tokenName,
    qty: t.quantity,
    totalVND: undefined,
    costPriceVND: t.avgCost ?? null,
    profitTodayVND: typeof t.profitToday === "number" ? t.profitToday : null,
  }));
}

function mapWalletToAccountRows(
  wallet?: Array<{ walletType: string; balance: number; percentage: number }> | null,
): AccountRow[] {
  if (!wallet) return [];
  return wallet.map((w, idx) => ({
    key: `${w.walletType}-${idx}`,
    name: w.walletType,
    balanceVND: w.balance,
  }));
}

export default function PortfolioOverviewPage() {
  const router = useRouter();
  const [showBalance, setShowBalance] = React.useState(true);
  const [viewMode, setViewMode] = React.useState<"token" | "wallet">("token");

  const { data: portfolio, isLoading } = usePortfolio(viewMode);

  const tokenRows = React.useMemo(
    () => mapTokenHoldingToAssetRows(portfolio?.data?.tokenHolding),
    [portfolio?.data?.tokenHolding],
  );
  const accountRows = React.useMemo(() => mapWalletToAccountRows(portfolio?.data?.wallet), [portfolio?.data?.wallet]);

  const go = (href: string) => router.push(href);

  return (
    <div className="space-y-6">
      <Summary
        title="Tổng tài sản"
        className="!border-border !mb-4 !bg-white !shadow-none"
        showBalance={showBalance}
        onToggle={() => setShowBalance((v) => !v)}
        totalValue={portfolio?.data?.totalValue}
        unitLabel={portfolio?.data?.currency ?? "VND"}
        subLabel="Lợi nhuận hôm nay"
        subValue={portfolio?.data?.todayProfit?.value}
        subPercent={portfolio?.data?.todayProfit?.percentage}
        actions={[
          { label: "Nạp", onClick: () => go("/wallet/deposit/fiat") },
          { label: "Rút", onClick: () => go("/wallet/withdraw/fiat") },
        ]}
      />

      <AssetsCard
        isLoading={isLoading}
        onTabChange={(k) => setViewMode(k as "token" | "wallet")}
        showBalance={showBalance}
        tokenRows={tokenRows}
        accountRows={accountRows}
      />
    </div>
  );
}
