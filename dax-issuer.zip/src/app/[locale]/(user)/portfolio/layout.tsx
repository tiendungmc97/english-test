import * as React from "react";

type Props = { children: React.ReactNode };

export default function PortfolioLayout({ children }: Props) {
  return (
    <div className="flex min-h-screen bg-white">
      <main
        role="main"
        className="min-w-0 flex-1 overflow-auto"
      >
        <div className="border-none bg-white p-10">{children}</div>
      </main>
    </div>
  );
}
