"use client";

import { CheckBoxField } from "@/components/ui/form/checkbox";
import { RadioField } from "@/components/ui/form/radio";
import { SwitchField } from "@/components/ui/form/switch";
import { usePathname, useRouter } from "@/i18n/navigation";
import { SessionStorageKeys } from "@/libs/constants/keys";
import { getLanguageLabel, LanguageOptions } from "@/libs/options/language";
import { NotificationContentTypeOptions } from "@/libs/options/notification-content-type";
import { NotificationMethodOptions } from "@/libs/options/notification-method";
import { getTimezoneLabel, TimezoneOptions } from "@/libs/options/timezone";
import { Language } from "@/libs/types/language";
import {
  setCurrency,
  setMethodsNotification,
  setTimezone,
  setToggleGoogleAuthenticator,
  setTypeContentNotification,
} from "@/redux/slice/setting.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { useUserInfo } from "@/services/hooks/use-auth";
import { useUpdateSettings } from "@/services/hooks/use-user";
import { Theme } from "@/theme/types";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  GlobalOutlined,
  MoonOutlined,
  SaveOutlined,
  SunOutlined,
} from "@ant-design/icons";
import { App, Button, Card, Select, Typography } from "antd";
import useApp from "antd/es/app/useApp";
import { useLocale, useTranslations } from "next-intl";
import { useTheme } from "next-themes";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { ElementEditSetting } from "./components/element-edit-setting";
import { ModalChangePassword } from "./security/modal-change-password";

const { Title, Text } = Typography;

const languagesList = (tLanguage: any) => [
  { code: Language.EN, name: tLanguage("english") },
  { code: Language.VI, name: tLanguage("vietnamese") },
];

const themesList = (t: any) => [
  { code: Theme.LIGHT, name: t("theme.light") },
  { code: Theme.DARK, name: t("theme.dark") },
];

const LanguageSelect: React.FC<{
  value: Language;
  onChange: (value: Language) => void;
  languages: { code: Language; name: string }[];
  locale: string;
}> = ({ value, onChange, languages, locale }) => (
  <Select
    value={value}
    onChange={onChange}
    className="w-full lg:w-56"
    size="large"
    suffixIcon={<GlobalOutlined />}
  >
    {languages.map((language) => (
      <Select.Option
        key={language.code}
        value={language.code}
      >
        <div className="flex items-center gap-2">
          <span className={`fi fi-${language.code === "en" ? "us" : "vn"} text-sm`} />
          {language.name}
          {language.code === locale && <CheckCircleOutlined className="ml-auto text-green-500" />}
        </div>
      </Select.Option>
    ))}
  </Select>
);

const ThemeSelect: React.FC<{
  value: Theme;
  onChange: (value: Theme) => void;
  themes: { code: Theme; name: string }[];
  currentTheme: Theme;
}> = ({ value, onChange, themes, currentTheme }) => (
  <Select
    value={value}
    onChange={onChange}
    className="w-full lg:w-56"
    size="large"
    suffixIcon={value === "dark" ? <MoonOutlined /> : <SunOutlined />}
  >
    {themes.map((themeOption) => (
      <Select.Option
        key={themeOption.code}
        value={themeOption.code}
      >
        <div className="flex items-center gap-2">
          {themeOption.code === "light" ? (
            <SunOutlined className="text-yellow-500" />
          ) : (
            <MoonOutlined className="text-blue-500" />
          )}
          {themeOption.name}
          {themeOption.code === currentTheme && <CheckCircleOutlined className="ml-auto text-green-500" />}
        </div>
      </Select.Option>
    ))}
  </Select>
);

const SettingsPage: React.FC = () => {
  const t = useTranslations("SettingsPage");
  const tLanguage = useTranslations("LanguageSwitcher");
  const tGeneral = useTranslations("SettingsPage.general");
  const tNotification = useTranslations("SettingsPage.notification");
  const tSecurity = useTranslations("SettingsPage.security");
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const { theme: initTheme, setTheme } = useTheme();
  const { message } = useApp();
  const dispatch = useAppDispatch();
  const { modal } = App.useApp();

  // Redux state
  const currency = useAppSelector((state) => state.setting.currency);
  const timezone = useAppSelector((state) => state.setting.timezone);
  const listCurrencyInfo = useAppSelector((state) => state.setting.listCurrencyInfo);
  const currencyInfo = useAppSelector((state) => state.setting.currencyInfo);
  const methodsNotificationValues = useAppSelector((state) => state.setting.methodsNotification);
  const typeContentNotificationValues = useAppSelector((state) => state.setting.typeContentNotification);
  const isEnableVerifyGoogle = useAppSelector((state) => state.setting.isEnableVerifyGoogle);

  // Local state
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(locale as Language);
  const [selectedTheme, setSelectedTheme] = useState<Theme>(initTheme as Theme);
  const [hasChanges, setHasChanges] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [isOpenModalChangePassword, setIsOpenModalChangePassword] = useState(false);

  // API hooks
  const { mutate: updateSettings } = useUpdateSettings();
  const { data: userData } = useUserInfo();

  const languages = languagesList(tLanguage);
  const themes = themesList(t);

  // Form methods
  const methodsLanguage = useForm({
    defaultValues: { language: locale },
  });

  const methodsCurrency = useForm({
    defaultValues: { currency: currency },
  });

  const methodsTimezone = useForm({
    defaultValues: { timezone: timezone },
  });

  const methodsNotification = useForm({
    defaultValues: {
      email: methodsNotificationValues.email,
      sms: methodsNotificationValues.sms,
    },
  });

  const methodsTypeContentNotification = useForm({
    defaultValues: {
      transaction: typeContentNotificationValues.transaction,
      balance: typeContentNotificationValues.balance,
      order: typeContentNotificationValues.order,
    },
  });

  const methodsGoogleAuth = useForm({
    defaultValues: { googleAuthenticator: isEnableVerifyGoogle },
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    setSelectedTheme(initTheme as Theme);
  }, [initTheme]);

  const handleLanguageChange = (value: Language) => {
    setSelectedLanguage(value);
    setHasChanges(value !== locale || selectedTheme !== initTheme);
  };

  const handleThemeChange = (value: Theme) => {
    setSelectedTheme(value);
    setHasChanges(selectedLanguage !== locale || value !== initTheme);
  };

  const handleSaveChanges = () => {
    if (selectedLanguage !== locale) {
      router.replace(pathname, { locale: selectedLanguage });
    }
    if (selectedTheme !== initTheme) {
      setTheme(selectedTheme);
      document.cookie = `${SessionStorageKeys.THEME}=${selectedTheme}; path=/;`;
      window.location.reload();
    }
    setHasChanges(false);
    message.success(t("settingsSaved"));
  };

  // General settings handlers
  const handleChangeLanguage = () => {
    modal.info({
      title: <span className="font-bold">{tGeneral("language.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsLanguage}>
          <form className="mt-2">
            <RadioField
              name="language"
              label=""
              options={LanguageOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedLanguage = methodsLanguage.getValues("language") as Language;
        if (selectedLanguage !== locale) {
          router.replace(pathname, { locale: selectedLanguage });
          updateSettings({ lang: selectedLanguage === Language.VI ? "vi_VN" : "en_US" });
        }
      },
      onCancel: () => {
        methodsLanguage.reset({ language: locale });
      },
      okText: tGeneral("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeCurrency = () => {
    const currencyOptions = listCurrencyInfo.map((item) => ({
      label: item.currencyUnitLabel,
      value: item.currencyName,
    }));

    modal.info({
      title: <span className="font-bold">{tGeneral("currency.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsCurrency}>
          <form className="mt-2">
            <RadioField
              name="currency"
              label=""
              options={currencyOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedCurrency = methodsCurrency.getValues("currency");
        if (selectedCurrency !== currency && selectedCurrency) {
          const selectedCurrencyInfo = listCurrencyInfo.find((item) => item.currencyName === selectedCurrency);
          updateSettings({ currencyId: selectedCurrencyInfo?.currencyId });
          dispatch(setCurrency(selectedCurrency));
        }
      },
      onCancel: () => {
        methodsCurrency.reset({ currency: currency });
      },
      okText: tGeneral("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeTimezone = () => {
    modal.info({
      title: <span className="font-bold">{tGeneral("timezone.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsTimezone}>
          <form className="mt-2">
            <RadioField
              name="timezone"
              label=""
              options={TimezoneOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedTimezone = methodsTimezone.getValues("timezone");
        const timezoneLabel = getTimezoneLabel(selectedTimezone);
        if (selectedTimezone !== timezone && selectedTimezone) {
          dispatch(setTimezone(selectedTimezone));
          updateSettings({ timezone: timezoneLabel });
        }
      },
      onCancel: () => {
        methodsTimezone.reset({ timezone });
      },
      okText: tGeneral("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  // Notification settings handlers
  const handleChangeMethodNotification = () => {
    modal.info({
      title: <span className="font-bold">{tNotification("methods.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsNotification}>
          <form className="mt-2">
            {NotificationMethodOptions.map((method) => (
              <CheckBoxField
                key={method.value}
                name={method.value}
                label=""
              >
                {tNotification(method.labelKey as any)}
              </CheckBoxField>
            ))}
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const emailNotification = methodsNotification.getValues("email");
        const smsNotification = methodsNotification.getValues("sms");
        dispatch(setMethodsNotification({ email: emailNotification, sms: smsNotification }));
      },
      onCancel: () => {
        methodsNotification.reset({
          email: methodsNotificationValues.email,
          sms: methodsNotificationValues.sms,
        });
      },
      okText: tGeneral("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeTypeContentNotification = () => {
    modal.info({
      title: <span className="font-bold">{tNotification("content.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsTypeContentNotification}>
          <form className="mt-2">
            {NotificationContentTypeOptions.map((method) => (
              <CheckBoxField
                key={method.value}
                name={method.value}
                label={tNotification(method.labelKey as any)}
              >
                {tNotification(method.labelKey as any)}
              </CheckBoxField>
            ))}
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const transactionNotification = methodsTypeContentNotification.getValues("transaction");
        const balanceNotification = methodsTypeContentNotification.getValues("balance");
        const orderNotification = methodsTypeContentNotification.getValues("order");
        dispatch(
          setTypeContentNotification({
            transaction: transactionNotification,
            balance: balanceNotification,
            order: orderNotification,
          }),
        );
      },
      onCancel: () => {
        methodsTypeContentNotification.reset({
          transaction: typeContentNotificationValues.transaction,
          balance: typeContentNotificationValues.balance,
          order: typeContentNotificationValues.order,
        });
      },
      okText: tGeneral("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  // Security settings handlers
  const toggleGoogleAuthenticator = () => {
    modal.info({
      title: <span className="font-bold">{tSecurity("authenticatorApp.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsGoogleAuth}>
          <form className="mt-2">
            <div className="flex h-full items-center border-y-[1px] border-gray-100 py-2">
              <SwitchField
                name="googleAuthenticator"
                label=""
              />
              <p className="max-w-96 ps-4 font-semibold text-gray-600 xl:ps-8">
                {tSecurity("authenticatorApp.switchLabel")}
              </p>
            </div>
            <div className="flex flex-col gap-2 pt-2">
              <p className="font-semibold">{tSecurity("authenticatorApp.noteTitle")}</p>
              <p className="text-gray-500">{tSecurity("authenticatorApp.note1")}</p>
              <p className="text-gray-500">{tSecurity("authenticatorApp.note2")}</p>
            </div>
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const googleAuthenticator = methodsGoogleAuth.getValues("googleAuthenticator");
        dispatch(setToggleGoogleAuthenticator(googleAuthenticator));
      },
      onCancel: () => {
        methodsGoogleAuth.reset({ googleAuthenticator: isEnableVerifyGoogle });
      },
      okText: tSecurity("authenticatorApp.save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const languageLabel = getLanguageLabel(methodsLanguage.getValues("language"));

  return (
    <div className="min-h-screen bg-white">
      <div className="px-4 py-5 md:px-6 md:py-6">
        <div className="flex flex-col gap-6 space-y-6">
          {/* General Settings Card */}
          <Card className="!border-border">
            <div className="mb-4 flex items-center gap-3">
              <Title
                level={4}
                className="font-bold text-gray-900 uppercase dark:text-white"
              >
                {tGeneral("title")}
              </Title>
            </div>
            <div className="space-y-4">
              <ElementEditSetting
                title={tGeneral("language.title")}
                description={tGeneral("language.description")}
                value={
                  <div className="flex items-center gap-3">
                    <Image
                      alt="language"
                      src={`/icons/languages/${methodsLanguage.getValues("language")}.svg`}
                      width={24}
                      height={24}
                    />
                    <span>{languageLabel}</span>
                  </div>
                }
                onEdit={handleChangeLanguage}
              />
              <ElementEditSetting
                title={tGeneral("currency.title")}
                description={tGeneral("currency.description")}
                value={
                  <div className="flex items-center gap-3">
                    <span>{currencyInfo?.symbol}</span>
                    <span>{currencyInfo?.currencyName}</span>
                  </div>
                }
                onEdit={handleChangeCurrency}
              />
              <ElementEditSetting
                title={tGeneral("timezone.title")}
                description={tGeneral("timezone.description")}
                value={
                  <div className="flex items-center gap-3">
                    <ClockCircleOutlined className="!text-[24px]" />
                    <span>{getTimezoneLabel(timezone)}</span>
                  </div>
                }
                onEdit={handleChangeTimezone}
              />
            </div>
          </Card>

          {/* Notification Settings Card */}
          <Card className="!border-border">
            <div className="mb-4 flex items-center gap-3">
              <Title
                level={4}
                className="font-bold text-gray-900 uppercase dark:text-white"
              >
                {tNotification("title")}
              </Title>
            </div>
            <div className="space-y-4">
              <ElementEditSetting
                title={tNotification("methods.title")}
                description={tNotification("methods.description")}
                value={
                  <div className="flex items-center gap-3">
                    {NotificationMethodOptions.filter((method) => methodsNotificationValues?.[method.value]).map(
                      (method, idx, arr) => (
                        <span key={method.value}>
                          {tNotification(method.labelKey as any)}
                          {idx < arr.length - 1 ? ", " : ""}
                        </span>
                      ),
                    )}
                  </div>
                }
                onEdit={handleChangeMethodNotification}
              />
              <ElementEditSetting
                title={tNotification("content.title")}
                description={tNotification("content.description")}
                value={
                  <div className="flex flex-col">
                    {NotificationContentTypeOptions.filter(
                      (method, idx) => typeContentNotificationValues?.[method.value],
                    ).map((method, idx) => (
                      <p
                        key={method.value}
                        className="text-center"
                      >
                        {tNotification(method.labelKey as any)}
                      </p>
                    ))}
                  </div>
                }
                onEdit={handleChangeTypeContentNotification}
              />
            </div>
          </Card>

          {/* Security Settings Card */}
          <Card className="!border-border">
            <div className="mb-4 flex items-center gap-3">
              <Title
                level={4}
                className="font-bold text-gray-900 uppercase dark:text-white"
              >
                {tSecurity("title")}
              </Title>
            </div>
            <div className="space-y-4">
              <ElementEditSetting
                title={tSecurity("authenticatorApp.title")}
                description={tSecurity("authenticatorApp.description")}
                value={<span className="text-green-500 uppercase">{tSecurity("authenticatorApp.enabled")}</span>}
                onEdit={toggleGoogleAuthenticator}
              />
              <ElementEditSetting
                title={tSecurity("email.title")}
                description={tSecurity("email.description")}
                value={<span>{userData?.data?.email}</span>}
              />
              <ElementEditSetting
                title={tSecurity("phone.title")}
                description={tSecurity("phone.description")}
                value={<span>{userData?.data?.phone}</span>}
              />
              <ElementEditSetting
                title={tSecurity("changePassword.title")}
                description={tSecurity("changePassword.description")}
                value="********"
                onEdit={() => setIsOpenModalChangePassword(true)}
              />
            </div>
          </Card>
        </div>

        {/* Save Changes Button */}
        {hasChanges && (
          <div className="mt-6 flex justify-center">
            <Button
              type="primary"
              size="large"
              onClick={handleSaveChanges}
              className="bg-purple-600 hover:bg-purple-700"
              icon={<SaveOutlined />}
            >
              {t("saveChanges")}
            </Button>
          </div>
        )}

        {/* Change Password Modal */}
        {isOpenModalChangePassword && (
          <ModalChangePassword
            isOpen={isOpenModalChangePassword}
            setIsOpen={setIsOpenModalChangePassword}
          />
        )}
      </div>
    </div>
  );
};

export default SettingsPage;
