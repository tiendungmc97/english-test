"use client";
import { RadioField } from "@/components/ui/form/radio";
import { usePathname, useRouter } from "@/i18n/navigation";
import { getLanguageLabel, LanguageOptions } from "@/libs/options/language";
import { getTimezoneLabel, TimezoneOptions } from "@/libs/options/timezone";
import { Language } from "@/libs/types/language";
import { setCurrency, setTimezone } from "@/redux/slice/setting.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { useUpdateSettings } from "@/services/hooks/use-user";
import { ClockCircleOutlined } from "@ant-design/icons";
import { App, Image } from "antd";
import { useLocale, useTranslations } from "next-intl";
import { FormProvider, useForm } from "react-hook-form";
import { ElementEditSetting } from "../components/element-edit-setting";

function SettingGeneralPage() {
  const dispatch = useAppDispatch();
  const { modal } = App.useApp();
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const currency = useAppSelector((state) => state.setting.currency);
  const timezone = useAppSelector((state) => state.setting.timezone);
  const listCurrencyInfo = useAppSelector((state) => state.setting.listCurrencyInfo);
  const currencyInfo = useAppSelector((state) => state.setting.currencyInfo);
  const { mutate: updateSettings } = useUpdateSettings();
  const t = useTranslations("SettingsPage.general");

  const methodsLanguage = useForm({
    defaultValues: {
      language: locale,
    },
  });

  const methodsCurrency = useForm({
    defaultValues: {
      currency: currency,
    },
  });
  const methodsTimezone = useForm({
    defaultValues: {
      timezone: timezone,
    },
  });
  const currencyOptions = listCurrencyInfo.map((item) => {
    return {
      label: item.currencyUnitLabel,
      value: item.currencyName,
    };
  });

  const handleChangeLanguage = () => {
    modal.info({
      title: <span className="font-bold">{t("language.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsLanguage}>
          <form className="mt-2">
            <RadioField
              name="language"
              label=""
              options={LanguageOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedLanguage = methodsLanguage.getValues("language") as Language;
        if (selectedLanguage !== locale) {
          router.replace(pathname, { locale: selectedLanguage });
          updateSettings({ lang: selectedLanguage === Language.VI ? "vi_VN" : "en_US" });
        }
      },
      onCancel: () => {
        methodsLanguage.reset({
          language: locale,
        });
      },
      okText: t("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeCurrency = () => {
    modal.info({
      title: <span className="font-bold">{t("currency.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsCurrency}>
          <form className="mt-2">
            <RadioField
              name="currency"
              label=""
              options={currencyOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedCurrency = methodsCurrency.getValues("currency");
        if (selectedCurrency !== currency && selectedCurrency) {
          const selectedCurrencyInfo = listCurrencyInfo.find((item) => item.currencyName === selectedCurrency);
          updateSettings({ currencyId: selectedCurrencyInfo?.currencyId });
          dispatch(setCurrency(selectedCurrency));
        }
      },
      onCancel: () => {
        methodsCurrency.reset({ currency: currency });
      },
      okText: t("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeTimezone = () => {
    modal.info({
      title: <span className="font-bold">{t("timezone.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsTimezone}>
          <form className="mt-2">
            <RadioField
              name="timezone"
              label=""
              options={TimezoneOptions}
              className="!flex !flex-col"
            />
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const selectedTimezone = methodsTimezone.getValues("timezone");
        const timezoneLabel = getTimezoneLabel(selectedTimezone);
        if (selectedTimezone !== timezone && selectedTimezone) {
          dispatch(setTimezone(selectedTimezone));
          updateSettings({ timezone: timezoneLabel });
        }
      },
      onCancel: () => {
        methodsTimezone.reset({ timezone });
      },
      okText: t("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };
  const languageLabel = getLanguageLabel(methodsLanguage.getValues("language"));

  return (
    <div className="">
      <div className="border-gray-200 pb-2 md:border-b-1 md:pb-6">
        <h1 className="text-2xl font-bold">{t("title")}</h1>
      </div>
      <div className="flex flex-col gap-2">
        <ElementEditSetting
          title={t("language.title")}
          description={t("language.description")}
          value={
            <div className="flex items-center gap-3">
              <Image
                alt="language"
                src={`/icons/languages/${methodsLanguage.getValues("language")}.svg`}
                width={24}
                height={24}
              />
              <span>{languageLabel}</span>
            </div>
          }
          onEdit={handleChangeLanguage}
        />
        <ElementEditSetting
          title={t("currency.title")}
          description={t("currency.description")}
          value={
            <div className="flex items-center gap-3">
              <span>{currencyInfo?.symbol}</span>
              <span>{currencyInfo?.currencyName}</span>
            </div>
          }
          onEdit={handleChangeCurrency}
        />
        <ElementEditSetting
          title={t("timezone.title")}
          description={t("timezone.description")}
          value={
            <div className="flex items-center gap-3">
              <ClockCircleOutlined className="!text-[24px]" />
              <span>{getTimezoneLabel(timezone)}</span>
            </div>
          }
          onEdit={handleChangeTimezone}
        />
      </div>
    </div>
  );
}

export default SettingGeneralPage;
