import React from "react";

interface SettingsLayoutProps {
  children: React.ReactNode;
}

const SettingsLayout: React.FC<SettingsLayoutProps> = ({ children }) => {
  return <main className="mx-auto max-w-6xl px-4 pt-4">{children}</main>;
};

export default SettingsLayout;
