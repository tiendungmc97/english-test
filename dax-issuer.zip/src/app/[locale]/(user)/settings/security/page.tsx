"use client";
import { SwitchField } from "@/components/ui/form/switch";
import { setToggleGoogleAuthenticator } from "@/redux/slice/setting.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { useUserInfo } from "@/services/hooks/use-auth";
import { App } from "antd";
import { useTranslations } from "next-intl";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { ElementEditSetting } from "../components/element-edit-setting";
import { ModalChangePassword } from "./modal-change-password";

function SettingSecurityPage() {
  const t = useTranslations("SettingsPage.security");
  const dispatch = useAppDispatch();
  const { modal } = App.useApp();
  const isEnableVerifyGoogle = useAppSelector((state) => state.setting.isEnableVerifyGoogle);
  const [isOpenModalChangePassword, setIsOpenModalChangePassword] = useState(false);

  const { data: userData, isLoading, error } = useUserInfo();
  const methodsGoogleAuthValuesDefault = {
    googleAuthenticator: isEnableVerifyGoogle,
  };
  const methodsGoogleAuth = useForm({
    defaultValues: methodsGoogleAuthValuesDefault,
  });

  const toggleGoogleAuthenticator = () => {
    modal.info({
      title: <span className="font-bold">{t("authenticatorApp.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsGoogleAuth}>
          <form className="mt-2">
            <div className="flex h-full items-center border-y-[1px] border-gray-100 py-2">
              <SwitchField
                name="googleAuthenticator"
                label=""
              />
              <p className="max-w-96 ps-4 font-semibold text-gray-600 xl:ps-8">{t("authenticatorApp.switchLabel")}</p>
            </div>
            <div className="flex flex-col gap-2 pt-2">
              <p className="font-semibold">{t("authenticatorApp.noteTitle")}</p>
              <p className="text-gray-500">{t("authenticatorApp.note1")}</p>
              <p className="text-gray-500">{t("authenticatorApp.note2")}</p>
            </div>
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const googleAuthenticator = methodsGoogleAuth.getValues("googleAuthenticator");
        dispatch(setToggleGoogleAuthenticator(googleAuthenticator));
      },
      onCancel: () => {
        methodsGoogleAuth.reset(methodsGoogleAuthValuesDefault);
      },
      okText: t("authenticatorApp.save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  return (
    <div className="">
      <div className="border-b-1 border-gray-200 pb-2">
        <h1 className="mb-4 text-3xl font-bold">{t("title")}</h1>
      </div>
      <div className="flex flex-col gap-2">
        <ElementEditSetting
          title={t("authenticatorApp.title")}
          description={t("authenticatorApp.description")}
          // value={
          //   <span className={`${isEnableVerifyGoogle ? "text-green-500" : "text-red-500"} uppercase`}>
          //     {isEnableVerifyGoogle ? t("authenticatorApp.enabled") : t("authenticatorApp.disabled")}
          //   </span>
          // }
          // onEdit={toggleGoogleAuthenticator}
          value={<span className="text-green-500 uppercase">{t("authenticatorApp.enabled")}</span>}
        />
        <ElementEditSetting
          title={t("email.title")}
          description={t("email.description")}
          value={<span>{userData?.data?.email}</span>}
        />
        <ElementEditSetting
          title={t("phone.title")}
          description={t("phone.description")}
          value={<span>{userData?.data?.phone}</span>}
        />
        <ElementEditSetting
          title={t("changePassword.title")}
          description={t("changePassword.description")}
          value="********"
          onEdit={() => setIsOpenModalChangePassword(true)}
        />
        {isOpenModalChangePassword && (
          <ModalChangePassword
            isOpen={isOpenModalChangePassword}
            setIsOpen={setIsOpenModalChangePassword}
          />
        )}
      </div>
    </div>
  );
}

export default SettingSecurityPage;
