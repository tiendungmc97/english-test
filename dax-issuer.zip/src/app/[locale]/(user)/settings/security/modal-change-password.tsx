"use client";

import { InputOTPField } from "@/components/ui/form/input-otp";
import { InputPasswordField } from "@/components/ui/form/input-password";
import { passwordSchema } from "@/libs/validations";
import { useUpdatePassword } from "@/services/hooks/use-user";
import { ValueChangePassword } from "@/services/service/user-service";
import { zodResolver } from "@hookform/resolvers/zod";
import { App, Form, Image, Modal } from "antd";
import { useTranslations } from "next-intl";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { z } from "zod";

interface ModalChangePasswordProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}
const valueChangePasswordDefault = {
  oldPassword: "",
  newPassword: "",
  confirmPassword: "",
  otp: "",
};
const forgetPasswordSchema = (t: any) =>
  z
    .object({
      oldPassword: passwordSchema(t),
      newPassword: passwordSchema(t),
      confirmPassword: z.string().nonempty({ message: t("confirmPassword.required") }),
      otp: z.string().length(6, { message: t("otp.required") }),
    })
    .refine((data) => data.newPassword === data.confirmPassword, {
      message: t("confirmPassword.match"),
      path: ["confirmPassword"],
    });

export function ModalChangePassword({ isOpen, setIsOpen }: ModalChangePasswordProps) {
  const { modal } = App.useApp();
  const t = useTranslations("AuthPage");
  const tValidate = useTranslations("Validation");
  const [errorMessage, setErrorMessage] = useState("");
  const { mutate: changePassword, isPending: isChangingPassword } = useUpdatePassword();

  const methods = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    defaultValues: valueChangePasswordDefault,
    resolver: zodResolver(forgetPasswordSchema(tValidate)),
  });
  const handleChangePassword = (data: ValueChangePassword) => {
    const dataUpdatePassword = {
      oldPassword: data.oldPassword,
      newPassword: data.newPassword,
      code: data.otp,
    };
    changePassword(dataUpdatePassword, {
      onSuccess: () => {
        setIsOpen(false);
        modal.info({
          title: t("changePasswordSuccessTitle"),
          content: t("changePasswordSuccessDescription"),
          closable: true,
          icon: null,
          cancelText: null,
        });
      },
      onError: (error: any) => {
        setErrorMessage(error.data.meta.message);
      },
    });
  };
  return (
    <Modal
      centered
      closeIcon
      closable={false}
      okText={t("confirm")}
      cancelText={t("cancel")}
      onOk={() => {
        methods.handleSubmit((data) => {
          handleChangePassword(data);
        })();
      }}
      onCancel={() => {
        setIsOpen(false);
      }}
      open={isOpen}
    >
      <div className="flex w-full flex-col items-center justify-center">
        <Image
          src="/images/vindas.svg"
          alt="vindas-icon"
          width={50}
          height={30}
        />
        <Image
          src="/images/vindas-text.svg"
          alt="vindas-icon"
          width={80}
          height={40}
        />
      </div>
      <div className="pb-4 text-center">
        <h2 className="text-lg font-semibold">{t("updatePasswordTitle")}</h2>
        {errorMessage && (
          <div className="mt-2 inline-block rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-600">
            {errorMessage}
          </div>
        )}
      </div>
      <FormProvider {...methods}>
        <Form
          disabled={isChangingPassword}
          className="space-y-2"
          layout="vertical"
        >
          <InputPasswordField
            name="oldPassword"
            label={t("oldPassword")}
            type="password"
            autoFocus
          />
          <InputPasswordField
            name="newPassword"
            label={t("newPassword")}
            type="password"
          />
          <InputPasswordField
            name="confirmPassword"
            label={t("confirmPassword")}
            type="password"
          />
          <InputOTPField
            name="otp"
            label={t("otp")}
            length={6}
          />
        </Form>
      </FormProvider>
    </Modal>
  );
}
