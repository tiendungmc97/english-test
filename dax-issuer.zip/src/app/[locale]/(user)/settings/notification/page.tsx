"use client";
import { CheckBoxField } from "@/components/ui/form/checkbox";
import { NotificationContentTypeOptions } from "@/libs/options/notification-content-type";
import { NotificationMethodOptions } from "@/libs/options/notification-method";
import { setMethodsNotification, setTypeContentNotification } from "@/redux/slice/setting.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { App } from "antd";
import { useTranslations } from "next-intl";
import { FormProvider, useForm } from "react-hook-form";
import { ElementEditSetting } from "../components/element-edit-setting";

function SettingsNotificationPage() {
  const dispatch = useAppDispatch();
  const { modal } = App.useApp();
  const t = useTranslations("SettingsPage.general");
  const tNotification = useTranslations("SettingsPage.notification");
  const methodsNotificationValues = useAppSelector((state) => state.setting.methodsNotification);
  const typeContentNotificationValues = useAppSelector((state) => state.setting.typeContentNotification);

  const methodsNotificationValuesDefault = {
    email: methodsNotificationValues.email,
    sms: methodsNotificationValues.sms,
  };
  const contentTypeValuesDefault = {
    transaction: typeContentNotificationValues.transaction,
    balance: typeContentNotificationValues.balance,
    order: typeContentNotificationValues.order,
  };

  const methodsNotification = useForm({
    defaultValues: methodsNotificationValuesDefault,
  });
  const methodsTypeContentNotification = useForm({
    defaultValues: contentTypeValuesDefault,
  });

  const handleChangeMethodNotification = () => {
    modal.info({
      title: <span className="font-bold">{tNotification("methods.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsNotification}>
          <form className="mt-2">
            {NotificationMethodOptions.map((method) => (
              <CheckBoxField
                key={method.value}
                name={method.value}
                label=""
              >
                {tNotification(method.labelKey as any)}
              </CheckBoxField>
            ))}
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const emailNotification = methodsNotification.getValues("email");
        const smsNotification = methodsNotification.getValues("sms");
        dispatch(setMethodsNotification({ email: emailNotification, sms: smsNotification }));
      },
      onCancel: () => {
        methodsNotification.reset(methodsNotificationValuesDefault);
      },
      okText: t("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  const handleChangeTypeContentNotification = () => {
    modal.info({
      title: <span className="font-bold">{tNotification("content.modalTitle")}</span>,
      content: (
        <FormProvider {...methodsTypeContentNotification}>
          <form className="mt-2">
            {NotificationContentTypeOptions.map((method) => (
              <CheckBoxField
                key={method.value}
                name={method.value}
                label={tNotification(method.labelKey as any)}
              >
                {tNotification(method.labelKey as any)}
              </CheckBoxField>
            ))}
          </form>
        </FormProvider>
      ),
      onOk: () => {
        const transactionNotification = methodsTypeContentNotification.getValues("transaction");
        const balanceNotification = methodsTypeContentNotification.getValues("balance");
        const orderNotification = methodsTypeContentNotification.getValues("order");
        dispatch(
          setTypeContentNotification({
            transaction: transactionNotification,
            balance: balanceNotification,
            order: orderNotification,
          }),
        );
      },
      onCancel: () => {
        methodsTypeContentNotification.reset(contentTypeValuesDefault);
      },
      okText: t("save"),
      width: 420,
      closable: true,
      icon: null,
      cancelText: null,
    });
  };

  return (
    <div className="">
      <div className="border-b-1 border-gray-200 pb-2">
        <h1 className="mb-4 text-3xl font-bold">{tNotification("title")}</h1>
      </div>
      <div className="flex flex-col gap-2">
        <ElementEditSetting
          title={tNotification("methods.title")}
          description={tNotification("methods.description")}
          value={
            <div className="flex items-center gap-3">
              {NotificationMethodOptions.filter((method) => methodsNotificationValues?.[method.value]).map(
                (method, idx, arr) => (
                  <span key={method.value}>
                    {tNotification(method.labelKey as any)}
                    {idx < arr.length - 1 ? ", " : ""}
                  </span>
                ),
              )}
            </div>
          }
          onEdit={handleChangeMethodNotification}
        />
        <ElementEditSetting
          title={tNotification("content.title")}
          description={tNotification("content.description")}
          value={
            <div className="flex flex-col">
              {NotificationContentTypeOptions.filter(
                (method, idx) => typeContentNotificationValues?.[method.value],
              ).map((method, idx) => (
                <p
                  key={method.value}
                  className="text-center"
                >
                  {tNotification(method.labelKey as any)}
                </p>
              ))}
            </div>
          }
          onEdit={handleChangeTypeContentNotification}
        />
      </div>
    </div>
  );
}

export default SettingsNotificationPage;
