import { Button } from "antd";
import Image from "next/image";
import React from "react";

interface ElementEditSettingProps {
  title: string;
  description: string;
  value?: React.ReactNode;
  onEdit?: () => void;
}

export function ElementEditSetting({ title, description, value, onEdit }: ElementEditSettingProps) {
  return (
    <div className="flex w-full flex-col justify-between bg-white px-4 py-2 shadow-2xs md:flex-row md:rounded-none md:bg-white md:px-0 md:py-4 md:shadow-none">
      <div>
        <p className="pb-1 font-bold">{title}</p>
        <p className="max-w-[550px]">{description}</p>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex w-full justify-between md:justify-end">
          <div className="flex items-center pe-2 font-bold">{value}</div>
          {onEdit && (
            <div className="border-gray-200 md:border-s-[1px] md:px-4">
              <Button
                icon={
                  <Image
                    src="/icons/pencil.svg"
                    width={16}
                    height={16}
                    alt="edit"
                  />
                }
                type="link"
                onClick={onEdit}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
