import { Chart } from "../components/chart";
import { History } from "../components/history";
import { OrderBook } from "../components/order-book";
import { OrderPanel } from "../components/order-panel";

function TradingPage() {
  return (
    <div className="h-full bg-white">
      <div className="grid h-full grid-cols-1 gap-2 px-4 pt-10 lg:grid-cols-2 xl:grid-cols-12 xl:grid-rows-6">
        <div className="order-2 lg:order-3 lg:col-span-1 lg:row-span-1 xl:order-1 xl:col-span-3 xl:row-span-6">
          <OrderBook />
        </div>
        <div className="order-1 lg:order-1 lg:col-span-2 lg:row-span-1 xl:order-2 xl:col-span-6 xl:row-span-3">
          <Chart />
        </div>

        <div className="order-3 lg:order-4 lg:col-span-1 lg:row-span-1 xl:order-3 xl:col-span-3 xl:row-span-3">
          <OrderPanel />
        </div>

        <div className="order-4 lg:order-5 lg:col-span-2 lg:row-span-1 xl:order-4 xl:col-span-9 xl:row-span-3">
          <History />
        </div>
      </div>
    </div>
  );
}

export default TradingPage;
