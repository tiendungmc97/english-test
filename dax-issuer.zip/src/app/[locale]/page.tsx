"use client";

export default function HomePage() {
  return (
    <div className="space-y-8 pt-20 text-center">
      <h1 className="text-2xl font-bold">Chào mừng đến với Vindas</h1>
    </div>
  );
}
