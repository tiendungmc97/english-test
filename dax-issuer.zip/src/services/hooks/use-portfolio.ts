import { QueryOptions, useQuery } from "@tanstack/react-query";
import { portfolioService } from "../service/portfolio-service";

export function usePortfolio(viewMode: "token" | "wallet", options?: QueryOptions<any>) {
  return useQuery({
    queryKey: ["portfolio", viewMode],
    queryFn: () => portfolioService.overview(viewMode).then((res) => res.data),
    ...options,
  });
}
