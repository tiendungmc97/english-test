import { useQuery } from "@tanstack/react-query";
import { issuerService } from "../service/issuer-service";

export const useQueryIssuerProfile = () => {
  return useQuery({
    queryKey: ["issuer-profile"],
    queryFn: () => issuerService.profile().then((res) => res.data.data),
  });
};

export const useQueryIssuerAssets = () => {
  return useQuery({
    queryKey: ["issuer-assets"],
    queryFn: () => issuerService.getIssuerAssets().then((res) => res.data.data),
  });
};

export const useQueryIssuerAssetsDetail = (assetCode: string) => {
  return useQuery({
    queryKey: ["issuer-assets-detail", assetCode],
    queryFn: () => issuerService.getIssuerAssetsDetail(assetCode).then((res) => res.data.data),
    enabled: !!assetCode,
  });
};
