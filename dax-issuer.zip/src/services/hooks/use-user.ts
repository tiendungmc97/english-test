import { QueryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { userService, UserSettings } from "../service/user-service";
import { ApiResponse } from "../api/types";

export const useQuerySettings = (options?: QueryOptions<ApiResponse<UserSettings>>) => {
  return useQuery({
    queryKey: ["settings"],
    queryFn: () => userService.settings().then((res) => res.data),
    ...options,
  });
};

export const useUpdateSettings = (options?: QueryOptions) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: Partial<UserSettings>) => userService.updateSettings(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["settings"] });
    },
    ...options,
  });
};

export const useQueryListCurrency = (options?: QueryOptions<any>) => {
  return useQuery({
    queryKey: ["general"],
    queryFn: () => userService.getListCurrency().then((res) => res.data),
    ...options,
  });
};

export const useUpdatePassword = (options?: QueryOptions) => {
  return useMutation({
    mutationFn: (data: any) => userService.updatePassword(data),
    ...options,
  });
};
