import { QueryOptions, useMutation, UseMutationOptions, useQuery, useQueryClient } from "@tanstack/react-query";
import { portfolioService } from "../service/portfolio-service";
import {
  FiatCurrencyItem,
  FiatDepositInitData,
  FiatHistoryParams,
  WalletBalanceParams,
  WalletBalanceResponse,
  walletService,
  FiatWithdrawInitData,
  FiatWithdrawConfirmData,
} from "../service/wallet-service";

export function useWallet(walletType: "spot" | "funding", options?: QueryOptions<any>) {
  return useQuery({
    queryKey: ["wallet", walletType],
    queryFn: () => portfolioService.overview(walletType).then((res) => res.data),
    ...options,
  });
}

export function useMutationDepositFiatInit(options?: UseMutationOptions<any, Error, FiatDepositInitData>) {
  return useMutation({
    mutationFn: (data: FiatDepositInitData) => walletService.fiatDepositInit(data).then((res) => res.data),
    ...options,
  });
}

export function useMutationDepositFiatConfirm(options?: UseMutationOptions<any, Error, string>) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (depositId: string) => walletService.fiatDepositConfirm(depositId).then((res) => res.data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fiat-history"] });
    },
    ...options,
  });
}

export function useMutationWithdrawFiatInit(options?: UseMutationOptions<any, Error, FiatWithdrawInitData>) {
  return useMutation({
    mutationFn: (data: FiatWithdrawInitData) => walletService.withdrawFiatInit(data).then((res) => res.data),
    ...options,
  });
}

export function useMutationWithdrawFiatConfirm(options?: UseMutationOptions<any, Error, FiatWithdrawConfirmData>) {
  return useMutation({
    mutationFn: (data: FiatWithdrawConfirmData) => walletService.withdrawFiatConfirm(data).then((res) => res.data),
    ...options,
  });
}

export function useQueryFiatHistory(params: FiatHistoryParams, options?: QueryOptions<any>) {
  return useQuery({
    queryKey: ["fiat-history", params],
    queryFn: () => walletService.fiatHistory(params).then((res) => res.data),
    staleTime: 0,
    gcTime: 0,
    ...options,
  });
}

export function useQueryFiatCurrency(options?: QueryOptions<FiatCurrencyItem[]>) {
  return useQuery({
    queryKey: ["fiat-currency"],
    queryFn: async () => await walletService.fiatCurrency().then((res) => res.data?.data),
    ...options,
  });
}

export function useQueryWalletBalance(params: WalletBalanceParams, options?: QueryOptions<WalletBalanceResponse>) {
  return useQuery({
    queryKey: ["fiat-currency", params],
    queryFn: async () => await walletService.balance(params).then((res) => res.data?.data),
    ...options,
  });
}
