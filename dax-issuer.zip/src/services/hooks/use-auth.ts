import { QueryOptions, useMutation, useQuery } from "@tanstack/react-query";
import { authService, LoginParams, RegisterParams, ResetPasswordData, UserProfile } from "../service/auth-service";
import { userService, UserProfile as UserInfo, UserBankAccount } from "../service/user-service";
import { usePathname } from "next/navigation";
import { ApiResponse } from "../api/types";

// Get user profile (with additional data)
export function useUserProfile(options?: QueryOptions<UserProfile>) {
  return useQuery({
    queryKey: ["profile"],
    queryFn: () => authService.getUserProfile().then((res) => res.data),
    ...options,
  });
}

// Get user info using access token
export function useUserInfo(options?: QueryOptions<ApiResponse<UserInfo>>) {
  return useQuery({
    queryKey: ["userInfo", options],
    queryFn: () => userService.userInfo().then((res) => res.data),
    ...options,
  });
}

export function useMutationLogin(options?: QueryOptions) {
  return useMutation({
    mutationFn: (data: LoginParams) => authService.login(data).then((res) => res.data),
    ...options,
  });
}

// Get user bank accounts
export function useUserBankAccounts(options?: QueryOptions<ApiResponse<UserBankAccount[]>>) {
  return useQuery({
    queryKey: ["userBankAccounts", options],
    queryFn: () => userService.bankAccounts().then((res) => res.data),
    ...options,
  });
}

// Get user referral
export function useUserReferral(options?: QueryOptions<any>) {
  const pathname = usePathname();

  return useQuery({
    queryKey: ["useUserReferral", options, pathname],
    queryFn: () => userService.referral().then((res) => res.data),
    ...options,
  });
}

// Get referral histories with paging
export function useReferralHistories(page: number = 0, size: number = 10, options?: QueryOptions<any>) {
  const pathname = usePathname();
  return useQuery({
    queryKey: ["referralHistories", page, size, pathname],
    queryFn: () => userService.referralHistories(page, size).then((res) => res.data),
    ...options,
  });
}

export function useLogin(options?: QueryOptions<LoginParams>) {
  return useMutation({
    mutationFn: (data: LoginParams) => authService.login(data),
    ...options,
  });
}
export function useMutationLogout(options?: QueryOptions<string>) {
  return useMutation({
    mutationFn: () => authService.logout(),
    ...options,
  });
}
export function useMutateVerify2FA(options?: QueryOptions) {
  return useMutation({
    mutationFn: (data: { code: string; validate2FaKey: string }) => authService.verify2FA(data).then((res) => res.data),
    ...options,
  });
}
export function useRegisterValidate(options?: QueryOptions<RegisterParams>) {
  return useMutation({
    mutationFn: (data: RegisterParams) => authService.registerValidate(data),
    ...options,
  });
}
export function useRegister(options?: QueryOptions<string>) {
  return useMutation({
    mutationFn: (registerKey: string) => authService.register(registerKey),
    ...options,
  });
}
export function useRegisterComplete(options?: QueryOptions<string>) {
  return useMutation({
    mutationFn: (registerKey: string) => authService.registerComplete(registerKey),
    ...options,
  });
}
export function useForgotPassword(options?: QueryOptions<string>) {
  return useMutation({
    mutationFn: (email: string) => authService.forgotPassword(email),
    ...options,
  });
}
export function useResetPassword(options?: QueryOptions<ResetPasswordData>) {
  return useMutation({
    mutationFn: (data: ResetPasswordData) => authService.resetPassword(data),
    ...options,
  });
}
