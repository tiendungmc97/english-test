import { apiClient } from "../api/config";
import { ApiResponse } from "../api/types";

export interface IssuerProfile {
  companyName: string | null;
  companyType: string | null;
  partnerName: string;
  phone: string;
  email: string;
  position: string | null;
  status: string;
  isActive: boolean;
  transactionStatus: string;
  avatar: string | null;
}
export interface IssuerAsset {
  assetCode: string;
  assetName: string;
  silverQuantity: number;
  weightKg: number;
  tokenHold: number;
  totalCirculatingTokens: number;
}
export interface IssuerAssetDetail {
  assetCode: string;
  assetId: string;
  assetName: string;
  assetStorageHistories: any[];
  standardUnit: string;
  totalCirculatingTokens: number;
  totalPhysicalSilverGrams: number;
  totalPhysicalWeightKg: number;
  totalTokensIssued: number;
}

export interface AssetResponse {
  responses: IssuerAsset[];
  totalPages: number;
  totalRecords: number;
}

export const issuerService = {
  profile() {
    const url = "/users/user-info";
    return apiClient.get<ApiResponse<IssuerProfile>>(url);
  },
  getIssuerAssets() {
    const url = "/issuer/assets";
    return apiClient.get<ApiResponse<AssetResponse>>(url);
  },
  getIssuerAssetsDetail(assetCode: string) {
    const url = `/issuer/assets/${assetCode}`;
    return apiClient.get<ApiResponse<IssuerAssetDetail>>(url);
  },
};
