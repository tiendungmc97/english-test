import { apiClient } from "../api/config";
import { API_ENDPOINTS } from "../api/endpoints";
import { ApiResponse } from "../api/types";
export interface LoginParams {
  login: string;
  password: string;
  recaptchaToken?: string;
}
export interface LoginData {
  provisioningUri: string;
  validate2FaKey: string;
}

export interface UserProfile {
  id: number;
  email: string;
  password: string;
  name: string;
  role: string;
  avatar: string;
  creationAt: string;
  updatedAt: string;
}
export interface RefreshTokenData {
  accessToken: string;
  refreshToken: string;
  accessTokenExpires: number;
  name: string;
  email: string;
}

export interface RefreshTokenResponse {
  code: number;
  message: string;
  data: RefreshTokenData;
  timestamp: string;
  path: string;
}

export interface RegisterParams {
  email: string;
  fullName: string;
  pwd: string;
  referralCode?: string;
  agreeFlag: boolean;
  captcha: string;
}

export interface ResetPasswordData {
  resetKey?: string;
  newPassword?: string;
}

export const authService = {
  login(data: LoginParams) {
    const url = API_ENDPOINTS.AUTH.LOGIN;
    return apiClient.post<ApiResponse<LoginData>>(url, data);
  },
  logout() {
    const url = API_ENDPOINTS.AUTH.LOGOUT;
    return apiClient.post(url);
  },
  registerValidate(data: RegisterParams) {
    const url = API_ENDPOINTS.AUTH.REGISTER_VALIDATE;
    return apiClient.post(url, data);
  },
  register(validateKey: string) {
    const url = API_ENDPOINTS.AUTH.REGISTER;
    const config = {
      headers: {
        validateKey: validateKey,
      },
    };
    return apiClient.post(url, undefined, config);
  },
  registerComplete(registerKey: string) {
    const url = API_ENDPOINTS.AUTH.REGISTER_COMPLETE;
    return apiClient.get(url, { params: { registerKey } });
  },
  verify2FA(data: { code: string; validate2FaKey: string }) {
    const url = API_ENDPOINTS.AUTH.VERIFY_2FA;
    return apiClient.post<ApiResponse<{ access_token: string }>>(url, data);
  },
  refreshToken(token: string) {
    const data = {
      refresh_token: token,
    };
    const url = API_ENDPOINTS.AUTH.REFRESH_TOKEN;
    return apiClient.post<RefreshTokenData>(url, data);
  },
  forgotPassword(email: string) {
    const url = API_ENDPOINTS.AUTH.FORGOT_PASSWORD;
    return apiClient.post(url, { email });
  },
  getUserProfile() {
    const url = API_ENDPOINTS.AUTH.PROFILE;
    return apiClient.get(url);
  },
  resetPassword(data: ResetPasswordData) {
    const url = API_ENDPOINTS.AUTH.RESET_PASSWORD;
    return apiClient.post<ResetPasswordData>(url, data);
  },
};
