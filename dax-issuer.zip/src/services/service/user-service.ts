import { Referral } from "@/app/[locale]/(user)/profile/referral/referral-history";
import { apiClient } from "../api/config";
import { API_ENDPOINTS } from "../api/endpoints";
import { ApiResponse, PagedApiResponse } from "../api/types";
import { Currency } from "@/libs/types/settings";

export interface UserProfile {
  id: number;
  accountId: string;
  name: string;
  email: string;
  phone: string | null;
  status: string;
  isKycCompleted: boolean;
  lastLoginTime: string;
  timeZone: string;
  avatarUrl: string | null;
  referralCode: string;
  minDeposit: number;
  maxDeposit: number;
  maxWithdraw: number;
  minWithdraw: number;
  levelName: string;
  dailyWithdrawLimit: number;
  withdrawalFee: number;
}

export interface UserBankAccount {
  key?: string;
  id: number;
  bankName: string;
  accNumber: string;
  sanitizedAccNumber: string;
  accHolderName: string;
  currency: string;
  sequence?: number;
  writeDate?: string;
}

export interface UserSettings {
  partnerId: number;
  lang: any;
  timezone: string;
  currencyName: Currency;
  currencyId: number;
  symbol: string;
  currencyUnitLabel: string;
}

export interface ValueChangePassword {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
  otp: string;
}

export const userService = {
  userInfo(accessToken?: string) {
    const url = API_ENDPOINTS.GENERAL.PROFILE;
    let config = {};
    if (!!accessToken) {
      config = {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      };
    }
    return apiClient.get<ApiResponse<UserProfile>>(url, config);
  },

  bankAccounts() {
    const url = API_ENDPOINTS.USER.BANK_ACCOUNTS;
    return apiClient.get<ApiResponse<UserBankAccount[]>>(url);
  },
  settings() {
    const url = API_ENDPOINTS.USER.SETTINGS;
    return apiClient.get<ApiResponse<UserSettings>>(url);
  },
  updateSettings(data: Partial<UserSettings>) {
    const url = API_ENDPOINTS.USER.SETTINGS;
    return apiClient.post<ApiResponse<any>>(url, data);
  },
  getListCurrency() {
    const url = API_ENDPOINTS.GENERAL.CURRENCY;
    return apiClient.get<ApiResponse<any>>(url);
  },
  updatePassword(data: ValueChangePassword) {
    const url = API_ENDPOINTS.USER.CHANGE_PASSWORD;
    return apiClient.post<ApiResponse<any>>(url, data);
  },

  referral() {
    const url = API_ENDPOINTS.REFERRAL.USER_REFERRAL;
    return apiClient.get<ApiResponse<Referral[]>>(url);
  },

  referralHistories(page: number = 0, size: number = 10) {
    const url = `${API_ENDPOINTS.REFERRAL.HISTORIES}?page=${page}&size=${size}`;
    return apiClient.get<PagedApiResponse<Referral[]>>(url);
  },
};
