import { WalletResponse } from "@/app/[locale]/(user)/portfolio/portfolio.type";
import { apiClient } from "../api/config";
import { API_ENDPOINTS } from "../api/endpoints";
import { ApiResponse } from "../api/types";

export const portfolioService = {
  overview(viewMode: string) {
    const url = API_ENDPOINTS.PORTFOLIO.OVERVIEW;
    return apiClient.get<ApiResponse<WalletResponse>>(url, {
      params: { viewMode },
    });
  },
};
