import { PortfolioOverviewResponse } from "@/app/[locale]/(user)/portfolio/portfolio.type";
import { apiClient } from "../api/config";
import { API_ENDPOINTS } from "../api/endpoints";
import { FundingType } from "@/libs/types/wallet";
import { ApiResponse } from "../api/types";

export interface FiatDepositInitRes {
  transactionId: string;
  beneficiaryBankName: string;
  beneficiaryAccountNumber: string;
  beneficiaryAccountName: string;
  transferAmount: number;
  currency: string;
  transferDescription: string;
  qrCode: string;
  expireAt: string;
}

export interface FiatDepositInitData {
  currency: string;
  amount: number;
}

export interface FiatDepositConfirmRes {
  transaction_proof: string;
  amount: number;
  note: string;
}

export interface FiatWithdrawInitData {
  amount: string;
  currency: string;
  fee: string;
  bankId: number;
}

export interface FiatWithdrawResponse {
  transactionId: string;
  transferAmount: number;
  fee: number;
  actualReceived: number;
  currency: string;
  transferAccountName: string;
  transferAccountNo: string;
  transferBank: string;
}

export interface FiatWithdrawConfirmData {
  withdrawId: string;
  code: string;
}

export interface FiatHistoryParams {
  fundingType?: FundingType;
  page: number;
  size: number;
}

export interface FiatCurrencyItem {
  id: number;
  currency: string;
  minWithdraw: number;
  maxWithdraw: number;
  dailyMaxWithdraw: number;
  minDeposit: number;
}

export interface WalletBalanceParams {
  walletType: "spot" | "funding";
  assetSymbol: "VND";
}

export interface WalletBalanceResponse {
  walletType: "spot" | "funding";
  assetSymbol: "VND";
  balanceFree: number;
  balanceLocked: number;
  realizedPnl: number;
  unrealizedPnl: number;
}

export const walletService = {
  holdings(walletType: "spot" | "funding") {
    const url = API_ENDPOINTS.WALLET.HOLDINGS;
    return apiClient.get<ApiResponse<PortfolioOverviewResponse>>(url, {
      params: { walletType },
    });
  },
  balance(params: WalletBalanceParams) {
    const url = API_ENDPOINTS.FIAT.FIAT_BALANCE;
    return apiClient.get<ApiResponse<WalletBalanceResponse>>(url, {
      params,
    });
  },
  fiatDepositInit(data: FiatDepositInitData) {
    const url = API_ENDPOINTS.WALLET.FIAT_DEPOSIT_INIT;
    return apiClient.post<ApiResponse<FiatDepositInitRes>>(url, data);
  },
  fiatDepositConfirm(depositId: string) {
    const url = API_ENDPOINTS.WALLET.FIAT_DEPOSIT_CONFIRM;
    return apiClient.post<ApiResponse<FiatDepositConfirmRes>>(url, null, {
      params: { depositId },
    });
  },
  fiatHistory(params: FiatHistoryParams) {
    const url = API_ENDPOINTS.WALLET.FIAT_TRANSACTION_HISTORY;
    return apiClient.get<ApiResponse<any>>(url, {
      params,
    });
  },
  fiatCurrency() {
    const url = API_ENDPOINTS.WALLET.FIAT_CURRENCY;
    return apiClient.get<{ meta: { code: number; message: string }; data: FiatCurrencyItem[] }>(url);
  },
  withdrawFiatInit(data: FiatWithdrawInitData) {
    const url = API_ENDPOINTS.WALLET.WITHDRAW_INIT;
    return apiClient.post<ApiResponse<FiatWithdrawResponse>>(url, data);
  },
  withdrawFiatConfirm(data: FiatWithdrawConfirmData) {
    const url = API_ENDPOINTS.WALLET.WITHDRAW_CONFIRM;
    return apiClient.post<ApiResponse<any>>(url, data);
  },
};
