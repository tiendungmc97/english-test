import { store } from "@/redux/store";
import { clearUserInfo } from "@/redux/slice/user.slice";
import { ROUTERS } from "@/libs/constants/routers";
import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse, InternalAxiosRequestConfig } from "axios";
import { ApiStatusCode } from "./types";
// Base API configuration
const API_CONFIG = {
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
} as const;

export const apiClient: AxiosInstance = axios.create(API_CONFIG);

// Request interceptor for adding auth tokens, logging, etc.
apiClient.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const accessToken = store.getState().user.user?.accessToken;
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    if (process.env.NEXT_PUBLIC_APP_ENV === "development") {
      console.log(`🚀 API Request: ${config.method?.toUpperCase()} ${config.url}`, {
        data: config.data,
        params: config.params,
      });
    }
    return config;
  },
  (error: any) => {
    console.error("❌ Request Error:", error);
    return Promise.reject(error);
  },
);

// Response interceptor for handling responses and errors
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    // Log response in development
    if (process.env.NEXT_PUBLIC_APP_ENV === "development") {
      console.log(`✅ API Response: ${response.config.method?.toUpperCase()} ${response.config.url}`, {
        status: response.status,
        data: response.data,
      });
    }

    return response;
  },
  (error: AxiosError) => {
    const apiError = handleApiError(error);

    // Handle 401 Unauthorized - redirect to login
    if (error.response?.status === ApiStatusCode.UNAUTHORIZED || error.response?.status === ApiStatusCode.FORBIDDEN) {
      // Clear user info from Redux store
      store.dispatch(clearUserInfo());

      // Redirect to login page (client-side only)
      if (typeof window !== "undefined") {
        // Use window.location for immediate redirect
        const currentPath = window.location.pathname;
        const locale = currentPath.startsWith("/en") ? "en" : "vi";
        window.location.href = `/${locale}${ROUTERS.AUTH.LOGIN}`;
      }
    }

    // Log error in development
    if (process.env.NEXT_PUBLIC_APP_ENV === "development") {
      console.error(`❌ API Error: ${error.config?.method?.toUpperCase()} ${error.config?.url}`, {
        status: error.response?.status,
        message: apiError.message,
        data: error.response?.data,
      });
    }
    return Promise.reject(apiError);
  },
);

function handleApiError(error: AxiosError) {
  const status = error.response?.status || 0;
  const data = error.response?.data as any;
  return {
    message: data?.message || error.message || "An unexpected error occurred",
    status,
    code: data?.code || error.code,
    data: data,
  };
}
// Create specialized API clients for different services
export const createServiceClient = (baseURL?: string, config?: AxiosRequestConfig): AxiosInstance => {
  return axios.create({
    ...API_CONFIG,
    ...config,
    baseURL: baseURL || API_CONFIG.baseURL,
  });
};

// Export configured clients for different services
export const userApiClient = createServiceClient();
export const postApiClient = createServiceClient();
export const commentApiClient = createServiceClient();
export const analyticsApiClient = createServiceClient(process.env.NEXT_PUBLIC_ANALYTICS_API_URL);
