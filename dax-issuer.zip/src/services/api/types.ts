export interface ApiResponse<T> {
  meta: {
    code: ApiStatusCode;
    message: string;
  };
  data: T;
}

export interface PagedApiResponse<T> extends ApiResponse<T> {
  meta: ApiResponse<T>["meta"] & {
    totalElements: number;
    totalPages: number;
    currentPage: number;
    pageSize: number;
  };
}

export enum ApiStatusCode {
  // --- Standard HTTP-like responses ---
  SUCCESS = 200,
  CREATED = 201,
  ACCEPTED = 202,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  PAYMENT_REQUIRED = 402,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  KYC_NOT_COMPLETED = 420,
  INTERNAL_SERVER_ERROR = 500,
  BAD_GATEWAY = 502,
  SERVICE_UNAVAILABLE = 503,
  GATEWAY_TIMEOUT = 504,

  // --- Registration / Authentication errors ---
  REGISTER_VALIDATE_KEY_EXPIRED = 600,
  REGISTER_CONFIRMATION_KEY_EXPIRED = 601,
  MAIL_INVALID = 602,
  FULL_NAME_INVALID = 603,
  EMAIL_INVALID = 604,
  OTP_INVALID = 605,
  INVALID_LOGIN_OR_PASSWORD = 606,
  INVESTOR_STATUS_INACTIVE = 607,
  PASSWORD_FORMAT_INCORRECT = 608,
  TWO_FACTOR_AUTH_NEED_SETUP = 609,
  TWO_FACTOR_AUTH_NEED_CONFIRMATION = 610,
  CAPTCHA_VERIFICATION_FAILED = 611,
  MAIL_ALREADY_EXISTS = 612,
  MAIL_NOT_VERIFIED = 613,
  PASSWORD_INVALID = 614,
  REFERRAL_CODE_INVALID = 615,

  // --- Wallet / Account issues ---
  WALLET_ADDRESS_BLACKLISTED = 700,
  ACCOUNT_LOCKED = 701,
  INVESTOR_INVALID = 702,
  PASSWORD_INCORRECT = 703,

  // --- Trading errors (duplicate codes with suffix) ---
  INVALID_SYMBOL = 800,
  TOO_MANY_REQUESTS = 801,
  EXCEED_LIMIT_QUOTA = 802,
  PRICE_DIFFERENCE_TOO_LARGE = 803,
  TOKEN_AMOUNT_MIN_LIMIT = 804,
  TOKEN_AMOUNT_MAX_LIMIT = 805,
  FIAT_AMOUNT_MIN_LIMIT = 806,
  FIAT_AMOUNT_MAX_LIMIT = 807,
  TOKEN_AMOUNT_AVAILABLE_BALANCE = 808,
  FIAT_AMOUNT_AVAILABLE_BALANCE = 809,
  ORDER_ALREADY_FILLED = 810,
}

export const ApiStatusMessage: Record<ApiStatusCode, string> = {
  [ApiStatusCode.SUCCESS]: "Thành công",
  [ApiStatusCode.CREATED]: "Đã tạo thành công",
  [ApiStatusCode.ACCEPTED]: "Đã chấp nhận",
  [ApiStatusCode.BAD_REQUEST]: "Yêu cầu không hợp lệ",
  [ApiStatusCode.UNAUTHORIZED]: "Không được phép",
  [ApiStatusCode.PAYMENT_REQUIRED]: "Yêu cầu thanh toán",
  [ApiStatusCode.FORBIDDEN]: "Bị cấm",
  [ApiStatusCode.NOT_FOUND]: "Không tìm thấy",
  [ApiStatusCode.KYC_NOT_COMPLETED]: "Chưa hoàn thành KYC",
  [ApiStatusCode.INTERNAL_SERVER_ERROR]: "Lỗi máy chủ nội bộ",
  [ApiStatusCode.BAD_GATEWAY]: "Cổng không hợp lệ",
  [ApiStatusCode.SERVICE_UNAVAILABLE]: "Dịch vụ không khả dụng",
  [ApiStatusCode.GATEWAY_TIMEOUT]: "Hết thời gian chờ cổng",

  [ApiStatusCode.REGISTER_VALIDATE_KEY_EXPIRED]: "Mã xác thực đăng ký đã hết hạn",
  [ApiStatusCode.REGISTER_CONFIRMATION_KEY_EXPIRED]: "Mã xác nhận đăng ký đã hết hạn",
  [ApiStatusCode.MAIL_INVALID]: "Email không hợp lệ",
  [ApiStatusCode.FULL_NAME_INVALID]: "Họ tên không hợp lệ",
  [ApiStatusCode.EMAIL_INVALID]: "Email không hợp lệ",
  [ApiStatusCode.OTP_INVALID]: "OTP không hợp lệ",
  [ApiStatusCode.INVALID_LOGIN_OR_PASSWORD]: "Tên đăng nhập hoặc mật khẩu không đúng",
  [ApiStatusCode.INVESTOR_STATUS_INACTIVE]: "Trạng thái nhà đầu tư không hoạt động",
  [ApiStatusCode.PASSWORD_FORMAT_INCORRECT]: "Định dạng mật khẩu không đúng",
  [ApiStatusCode.TWO_FACTOR_AUTH_NEED_SETUP]: "Cần thiết lập xác thực hai yếu tố",
  [ApiStatusCode.TWO_FACTOR_AUTH_NEED_CONFIRMATION]: "Cần xác nhận xác thực hai yếu tố",
  [ApiStatusCode.CAPTCHA_VERIFICATION_FAILED]: "Xác thực captcha thất bại",
  [ApiStatusCode.MAIL_ALREADY_EXISTS]: "Email đã tồn tại",
  [ApiStatusCode.MAIL_NOT_VERIFIED]: "Email chưa được xác minh",
  [ApiStatusCode.PASSWORD_INVALID]: "Mật khẩu không hợp lệ",
  [ApiStatusCode.REFERRAL_CODE_INVALID]: "Mã giới thiệu không hợp lệ",

  [ApiStatusCode.WALLET_ADDRESS_BLACKLISTED]: "Địa chỉ ví đã bị chặn",
  [ApiStatusCode.ACCOUNT_LOCKED]: "Tài khoản đã bị khóa",
  [ApiStatusCode.INVESTOR_INVALID]: "Tài khoản không hợp lệ",
  [ApiStatusCode.PASSWORD_INCORRECT]: "Mật khẩu không đúng",

  [ApiStatusCode.INVALID_SYMBOL]: "Cặp giao dịch không hợp lệ",
  [ApiStatusCode.TOO_MANY_REQUESTS]: "Quá nhiều yêu cầu trong thời gian ngắn",
  [ApiStatusCode.EXCEED_LIMIT_QUOTA]: "Vượt quá hạn mức",
  [ApiStatusCode.PRICE_DIFFERENCE_TOO_LARGE]: "Chênh lệch giá quá lớn",
  [ApiStatusCode.TOKEN_AMOUNT_MIN_LIMIT]: "Số lượng token nhỏ hơn giới hạn tối thiểu",
  [ApiStatusCode.TOKEN_AMOUNT_MAX_LIMIT]: "Số lượng token lớn hơn giới hạn tối đa",
  [ApiStatusCode.FIAT_AMOUNT_MIN_LIMIT]: "Số tiền fiat nhỏ hơn giới hạn tối thiểu",
  [ApiStatusCode.FIAT_AMOUNT_MAX_LIMIT]: "Số tiền fiat lớn hơn giới hạn tối đa",
  [ApiStatusCode.TOKEN_AMOUNT_AVAILABLE_BALANCE]: "Số lượng token vượt quá số dư khả dụng",
  [ApiStatusCode.FIAT_AMOUNT_AVAILABLE_BALANCE]: "Số tiền fiat vượt quá số dư khả dụng",
  [ApiStatusCode.ORDER_ALREADY_FILLED]: "Lệnh đã được thực hiện, hủy hoặc từ chối",
};
