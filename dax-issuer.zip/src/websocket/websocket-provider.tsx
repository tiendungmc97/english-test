"use client";
import { connect, disconnect } from "@/redux/slice/websocket.slice";
import { useAppDispatch, useAppSelector } from "@/redux/store";
import { useEffect } from "react";

export const WebSocketProvider = () => {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(connect()); // Replace with your WebSocket URL

    const handleOnline = () => {
      console.log("🌐 Network is back online, reconnecting...");
      dispatch(connect());
    };
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("online", handleOnline);
      dispatch(disconnect());
    };
  }, [dispatch]);

  return <></>;
};
