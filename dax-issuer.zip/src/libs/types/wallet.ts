export enum FundingPurpose {
  NORMAL = "nm",
  CASHBACK = "cb",
  PROFIT_OUT = "po",
  CREDIT_OUT = "co",
}

export enum FiatMethod {
  BANK_TRANSFER = "bt",
  CREDIT_DEBIT_CARD = "cc",
  INTERNAL_TRANSFER = "it",
  QUICK_DEPOSIT = "qd",
}

export enum FundingType {
  DEPOSIT = "d",
  WITHDRAW = "w",
}

export enum DwFiatState {
  COMPLETED = "completed",
  CANCEL = "cancel",
  IN_PROGRESS = "in-progress",
  NEW = "new",
}
