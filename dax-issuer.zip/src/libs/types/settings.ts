export enum Currency {
  USD = "USD",
  VND = "VND",
}

export interface CurrencyInfo {
  currencyId: number;
  currencyName: string;
  symbol: string;
  rounding: number;
  decimalPlaces: number;
  position: "before" | "after";
  currencyUnitLabel: string;
  currencySubunitLabel: string;
}

export enum WeightUnit {
  GRAM = "gram",
  OUNCE = "ounce",
}

export enum NotificationContentType {
  TRANSACTION = "transaction",
  BALANCE = "balance",
  ORDER = "order",
}
export type TypeContentNotification = {
  [K in NotificationContentType]: boolean;
};

export enum NotificationMethod {
  EMAIL = "email",
  SMS = "sms",
}
export type TypeNotificationMethods = {
  [K in NotificationMethod]: boolean;
};

export enum Timezone {
  UTC_7 = "UTC+07:00",
  UTC_8 = "UTC+08:00",
  UTC_9 = "UTC+09:00",
}
