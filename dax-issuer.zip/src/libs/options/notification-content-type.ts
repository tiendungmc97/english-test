import { NotificationContentType } from "../types/settings";

export const NotificationContentTypeOptions = [
  { labelKey: "content.transaction", value: NotificationContentType.TRANSACTION },
  { labelKey: "content.order", value: NotificationContentType.ORDER },
  { labelKey: "content.balance", value: NotificationContentType.BALANCE },
];

export function getNotificationContentTypeLabelKey(type: NotificationContentType): string {
  const found = NotificationContentTypeOptions.find((m) => m.value === type);
  return found ? found.labelKey : "";
}
