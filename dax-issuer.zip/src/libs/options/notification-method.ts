import { NotificationMethod } from "../types/settings";

export const NotificationMethodOptions = [
  { labelKey: "methods.email", value: NotificationMethod.EMAIL },
  { labelKey: "methods.sms", value: NotificationMethod.SMS },
];

export function getNotificationMethodLabelKey(method: NotificationMethod): string {
  const found = NotificationMethodOptions.find((m) => m.value === method);
  return found ? found.labelKey : "";
}
