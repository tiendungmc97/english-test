import { Currency } from "../types/settings";

export const CurrencyOptions: { label: string; value: Currency }[] = [
  {
    label: "VND",
    value: Currency.VND,
  },
  {
    label: "USD",
    value: Currency.USD,
  },
] as const;

export function getCurrencyLabel(value: Currency): string | undefined {
  const option = CurrencyOptions.find((opt) => opt.value === value);
  return option ? option.label : undefined;
}
