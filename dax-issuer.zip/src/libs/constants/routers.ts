export const ROUTERS = {
  HOME: "/",

  AUTH: {
    LOGIN: "/login",
    REGISTER: "/register",
    FORGOT_PASSWORD: "/forgot-password",
    RESET_PASSWORD: "/reset-password",
    VERIFY_EMAIL: "/verify-email",
    VERIFY_2FA: "/verify-2fa",
  },

  // User protected routes
  DASHBOARD: {
    INDEX: "/dashboard",
    PROFILE: "/dashboard/profile",
    MANAGER_ASSETS: "/dashboard/manager-assets",
    REPORTS: "/dashboard/reports",
  },
  PROFILE: {
    INDEX: "/profile",
    GENERAL: "/profile/general",
    KYC: "/profile/kyc",
    LEVEL: "/profile/level",
  },
  SETTINGS: {
    INDEX: "/settings",
    SECURITY: "/settings/security",
    NOTIFICATIONS: "/settings/notifications",
    GENERAL: "/settings/general",
  },
  HISTORY: {
    INDEX: "/history",
    FIAT: "/history/fiat",
    TOKEN: "/history/token",
  },
  PRODUCTS: {
    INDEX: "/products",
  },
  TRADING: {
    INDEX: "/trading",
  },
  WALLET: {
    INDEX: "/wallet",
    DEPOSIT_FIAT: "/wallet/deposit/fiat",
    WITHDRAW_FIAT: "/wallet/withdraw/fiat",
    DEPOSIT_CRYPTO: "/wallet/deposit/crypto",
    WITHDRAW_CRYPTO: "/wallet/withdraw/crypto",
    HISTORY: "/wallet/history",
  },
  PORTFOLIO: {
    INDEX: "/portfolio",
    OVERVIEW: "/portfolio/overview",
    ASSETS_SPOT: "/portfolio/assets/spot",
    ASSETS_FUNDING: "/portfolio/assets/funding",
    HISTORY_FIAT: "/portfolio/history/fiat",
    HISTORY_TOKEN: "/portfolio/history/token",
    HISTORY_TOKEN_TRANSFER: "/portfolio/history/token-transfer",
    HISTORY_FIAT_TRANSFER: "/portfolio/history/fiat-transfer",
  },
  NOTIFICATION: {
    INDEX: "/notifications",
  },
  ISSUER: {
    INDEX: "/issuer",
    PROFILE: "/issuer/profile",
    MANAGER_ASSET: "/issuer/manager-asset",
    REPORT: "/issuer/report",
  },
} as const;
