import { createHash, randomBytes, pbkdf2Sync } from "crypto";

/**
 * Simple password encryption utility using Node.js crypto
 */

/**
 * Encrypt a password using PBKDF2 with SHA-256
 * @param password - Plain text password to encrypt
 * @returns Encrypted password string in format "salt:hash"
 */
export const encryptPassword = (password: string): string => {
  // Generate random salt
  const salt = randomBytes(16).toString("hex");

  // Create hash using PBKDF2
  const hash = pbkdf2Sync(password, salt, 10000, 64, "sha256").toString("hex");

  // Return combined salt:hash
  return `${salt}:${hash}`;
};

/**
 * Verify a password against its encrypted version
 * @param password - Plain text password to verify
 * @param encrypted - Encrypted password from database
 * @returns True if password matches, false otherwise
 */
export const verifyPassword = (password: string, encrypted: string): boolean => {
  try {
    // Split the encrypted string to get salt and hash
    const [salt, storedHash] = encrypted.split(":");

    // Hash the input password with the same salt
    const hash = pbkdf2Sync(password, salt, 10000, 64, "sha256").toString("hex");

    // Compare hashes
    return hash === storedHash;
  } catch (error) {
    console.error("Password verification error:", error);
    return false;
  }
};

/**
 * Generate a simple hash (for non-password data)
 * @param data - Data to hash
 * @returns SHA-256 hash
 */
export const simpleHash = (data: string): string => {
  return createHash("sha256").update(data).digest("hex");
};

/**
 * Generate random salt
 * @param length - Length in bytes (default: 16)
 * @returns Hex string salt
 */
export const generateSalt = (length: number = 16): string => {
  return randomBytes(length).toString("hex");
};
