import { ParamsSendRpcMessage, ResponseWebsocket } from "@/websocket/libs/interface";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const websocketSlice = createSlice({
  name: "websocket",
  initialState: {
    isReady: false,
    messages: {} as ResponseWebsocket,
    error: null,
  },
  reducers: {
    connected: (state) => {
      state.isReady = true;
    },
    disconnected: (state) => {
      state.isReady = false;
    },
    messageReceived: (state, action: PayloadAction<ResponseWebsocket>) => {
      const messages = action.payload;
      state.messages = messages;
    },
    error: (state, action) => {
      state.error = action.payload;
    },
    resetData: (state) => {
      state.messages = {} as ResponseWebsocket;
      state.error = null;
    },
    connect: (state) => {}, // Handled by middleware
    disconnect: (state) => {}, // Handled by middleware
    sendRpcMessage: (state, action: PayloadAction<ParamsSendRpcMessage>) => {}, // Handled by middleware
  },
});

export const { connect, connected, disconnected, messageReceived, sendRpcMessage, disconnect, error, resetData } =
  websocketSlice.actions;

export default websocketSlice.reducer;
