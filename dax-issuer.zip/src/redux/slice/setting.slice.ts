import {
  Currency,
  CurrencyInfo,
  TypeContentNotification,
  TypeNotificationMethods,
  WeightUnit,
} from "@/libs/types/settings";
import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { clearUserInfo } from "./user.slice";
import { Timezone } from "@/libs/dayjs";

export interface SettingState {
  listCurrencyInfo: CurrencyInfo[];
  currency: Currency | undefined;
  currencyInfo: CurrencyInfo;
  timezone: Timezone | undefined;
  weightUnit: WeightUnit;
  methodsNotification: TypeNotificationMethods;
  typeContentNotification: TypeContentNotification;
  isEnableVerifyGoogle: boolean;
}

const initialState: SettingState = {
  listCurrencyInfo: [],
  currency: undefined,
  currencyInfo: {} as CurrencyInfo,
  timezone: undefined,
  weightUnit: WeightUnit.GRAM,
  methodsNotification: {
    email: true,
    sms: false,
  },
  typeContentNotification: {
    transaction: true,
    balance: true,
    order: false,
  },
  isEnableVerifyGoogle: false,
};

const settingSlice = createSlice({
  name: "setting",
  initialState,
  reducers: {
    setListCurrencyInfo: (state, action: PayloadAction<CurrencyInfo[]>) => {
      state.listCurrencyInfo = action.payload;
      state.currencyInfo =
        state.listCurrencyInfo.find((item) => item.currencyName === state.currency) || ({} as CurrencyInfo);
    },
    setCurrency: (state, action: PayloadAction<Currency>) => {
      state.currency = action.payload;
      state.currencyInfo =
        state.listCurrencyInfo.find((item) => item.currencyName === action.payload) || ({} as CurrencyInfo);
    },
    setWeightUnit: (state, action: PayloadAction<WeightUnit>) => {
      state.weightUnit = action.payload;
    },
    setTimezone: (state, action: PayloadAction<Timezone>) => {
      state.timezone = action.payload;
    },
    setMethodsNotification: (state, action: PayloadAction<TypeNotificationMethods>) => {
      state.methodsNotification = action.payload;
    },
    setTypeContentNotification: (state, action: PayloadAction<TypeContentNotification>) => {
      state.typeContentNotification = action.payload;
    },
    setToggleGoogleAuthenticator: (state, action: PayloadAction<boolean>) => {
      state.isEnableVerifyGoogle = action.payload;
    },
    updateSettings: (state, action: PayloadAction<Partial<SettingState>>) => {
      return { ...state, ...action.payload };
    },
    resetSettings: () => {
      return initialState;
    },
    loadPersistedSettingState: (state, action: PayloadAction<SettingState>) => {
      return action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(clearUserInfo, () => initialState);
  },
});

export const {
  setCurrency,
  setListCurrencyInfo,
  setWeightUnit,
  setTimezone,
  setMethodsNotification,
  setTypeContentNotification,
  setToggleGoogleAuthenticator,
  updateSettings,
  resetSettings,
  loadPersistedSettingState,
} = settingSlice.actions;

export default settingSlice.reducer;
