import { CookiesStorageKeys } from "@/libs/constants/keys";
import { deleteCookie } from "@/utils/cookies";
import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

interface User {
  id: string;
  name: string;
  email: string;
  provisioningUri: string;
  validate2FaKey: string;
  accessToken: string;
}

interface UserState {
  user: User;
}

const initialState: UserState = {
  user: {} as User,
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    updateUserInfo: (state, action: PayloadAction<Partial<User>>) => {
      state.user = { ...state.user, ...action.payload };
    },
    clearUserInfo: (state) => {
      state.user = {} as User;
      deleteCookie(CookiesStorageKeys.ACCESS_TOKEN);
    },
    loadPersistedUserState: (state, action: PayloadAction<UserState>) => {
      return action.payload;
    },
  },
});

export const { updateUserInfo, clearUserInfo, loadPersistedUserState } = userSlice.actions;
export default userSlice.reducer;
